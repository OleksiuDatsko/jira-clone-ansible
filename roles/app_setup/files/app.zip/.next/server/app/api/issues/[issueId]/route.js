"use strict";
(() => {
var exports = {};
exports.id = 792;
exports.ids = [792];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 97783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 28530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 14300:
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 72254:
/***/ ((module) => {

module.exports = require("node:buffer");

/***/ }),

/***/ 6005:
/***/ ((module) => {

module.exports = require("node:crypto");

/***/ }),

/***/ 87561:
/***/ ((module) => {

module.exports = require("node:fs");

/***/ }),

/***/ 88849:
/***/ ((module) => {

module.exports = require("node:http");

/***/ }),

/***/ 22286:
/***/ ((module) => {

module.exports = require("node:https");

/***/ }),

/***/ 87503:
/***/ ((module) => {

module.exports = require("node:net");

/***/ }),

/***/ 49411:
/***/ ((module) => {

module.exports = require("node:path");

/***/ }),

/***/ 97742:
/***/ ((module) => {

module.exports = require("node:process");

/***/ }),

/***/ 84492:
/***/ ((module) => {

module.exports = require("node:stream");

/***/ }),

/***/ 72477:
/***/ ((module) => {

module.exports = require("node:stream/web");

/***/ }),

/***/ 41041:
/***/ ((module) => {

module.exports = require("node:url");

/***/ }),

/***/ 47261:
/***/ ((module) => {

module.exports = require("node:util");

/***/ }),

/***/ 65628:
/***/ ((module) => {

module.exports = require("node:zlib");

/***/ }),

/***/ 77282:
/***/ ((module) => {

module.exports = require("process");

/***/ }),

/***/ 71267:
/***/ ((module) => {

module.exports = require("worker_threads");

/***/ }),

/***/ 90670:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  headerHooks: () => (/* binding */ headerHooks),
  originalPathname: () => (/* binding */ originalPathname),
  requestAsyncStorage: () => (/* binding */ requestAsyncStorage),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage),
  staticGenerationBailout: () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./app/api/issues/[issueId]/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  DELETE: () => (DELETE),
  GET: () => (GET),
  PATCH: () => (PATCH)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(35387);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(29267);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(32413);
// EXTERNAL MODULE: ./server/db.ts + 1 modules
var db = __webpack_require__(84952);
// EXTERNAL MODULE: external "@prisma/client"
var client_ = __webpack_require__(53524);
// EXTERNAL MODULE: ./node_modules/zod/lib/index.mjs
var lib = __webpack_require__(83445);
// EXTERNAL MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/createGetAuth.js
var createGetAuth = __webpack_require__(14669);
;// CONCATENATED MODULE: ./app/api/issues/[issueId]/route.ts





async function GET(req, { params }) {
    const { issueId } = params;
    const issue = await db/* prisma */._.issue.findUnique({
        where: {
            id: issueId
        }
    });
    if (!issue?.parentId) {
        return next_response/* default */.Z.json({
            issue: {
                ...issue,
                parent: null
            }
        });
    }
    const parent = await db/* prisma */._.issue.findUnique({
        where: {
            id: issue.parentId
        }
    });
    // return NextResponse.json<GetIssueDetailsResponse>({ issue });
    return next_response/* default */.Z.json({
        issue: {
            ...issue,
            parent
        }
    });
}
const patchIssueBodyValidator = lib.z.object({
    name: lib.z.string().optional(),
    description: lib.z.string().optional(),
    type: lib.z.nativeEnum(client_.IssueType).optional(),
    status: lib.z.nativeEnum(client_.IssueStatus).optional(),
    sprintPosition: lib.z.number().optional(),
    boardPosition: lib.z.number().optional(),
    assigneeId: lib.z.string().nullable().optional(),
    reporterId: lib.z.string().optional(),
    parentId: lib.z.string().nullable().optional(),
    sprintId: lib.z.string().nullable().optional(),
    isDeleted: lib.z.boolean().optional(),
    sprintColor: lib.z.string().optional()
});
async function PATCH(req, { params }) {
    const { userId } = (0,createGetAuth/* getAuth */.v0)(req);
    if (!userId) return new Response("Unauthenticated request", {
        status: 403
    });
    const { success } = await db/* ratelimit */.$.limit(userId);
    if (!success) return new Response("Too many requests", {
        status: 429
    });
    const { issueId } = params;
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    const body = await req.json();
    const validated = patchIssueBodyValidator.safeParse(body);
    if (!validated.success) {
        // eslint-disable-next-line
        const message = ("Invalid body. " + validated.error.errors[0]?.message) ?? "";
        return new Response(message, {
            status: 400
        });
    }
    const { data: valid } = validated;
    const currentIssue = await db/* prisma */._.issue.findUnique({
        where: {
            id: issueId
        }
    });
    if (!currentIssue) {
        return new Response("Issue not found", {
            status: 404
        });
    }
    const issue = await db/* prisma */._.issue.update({
        where: {
            id: issueId
        },
        data: {
            name: valid.name ?? undefined,
            description: valid.description ?? undefined,
            status: valid.status ?? undefined,
            type: valid.type ?? undefined,
            sprintPosition: valid.sprintPosition ?? undefined,
            assigneeId: valid.assigneeId === undefined ? undefined : valid.assigneeId,
            reporterId: valid.reporterId ?? undefined,
            isDeleted: valid.isDeleted ?? undefined,
            sprintId: valid.sprintId === undefined ? undefined : valid.sprintId,
            parentId: valid.parentId === undefined ? undefined : valid.parentId,
            sprintColor: valid.sprintColor ?? undefined,
            boardPosition: valid.boardPosition ?? undefined
        }
    });
    // if (issue.assigneeId) {
    //   const assignee = await clerkClient.users.getUser(issue.assigneeId);
    //   const assigneeForClient = filterUserForClient(assignee);
    //   return NextResponse.json({
    //     issue: { ...issue, assignee: assigneeForClient },
    //   });
    // }
    // return NextResponse.json<PostIssueResponse>({ issue });
    return next_response/* default */.Z.json({
        issue: {
            ...issue,
            assignee: null
        }
    });
}
async function DELETE(req, { params }) {
    const { userId } = (0,createGetAuth/* getAuth */.v0)(req);
    if (!userId) return new Response("Unauthenticated request", {
        status: 403
    });
    const { success } = await db/* ratelimit */.$.limit(userId);
    if (!success) return new Response("Too many requests", {
        status: 429
    });
    const { issueId } = params;
    const issue = await db/* prisma */._.issue.update({
        where: {
            id: issueId
        },
        data: {
            isDeleted: true,
            boardPosition: -1,
            sprintPosition: -1,
            sprintId: "DELETED-SPRINT-ID"
        }
    });
    // return NextResponse.json<PostIssueResponse>({ issue });
    return next_response/* default */.Z.json({
        issue
    });
}

;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fissues%2F%5BissueId%5D%2Froute&name=app%2Fapi%2Fissues%2F%5BissueId%5D%2Froute&pagePath=private-next-app-dir%2Fapi%2Fissues%2F%5BissueId%5D%2Froute.ts&appDir=%2Fhome%2Foleksii%2FDocuments%2FProjects%2FSoftServe%2Fvagrant-test%2Fapp%2Fapp&appPaths=%2Fapi%2Fissues%2F%5BissueId%5D%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&preferredRegion=&middlewareConfig=e30%3D!

    

    

    

    const options = {"definition":{"kind":"APP_ROUTE","page":"/api/issues/[issueId]/route","pathname":"/api/issues/[issueId]","filename":"route","bundlePath":"app/api/issues/[issueId]/route"},"resolvedPagePath":"/home/oleksii/Documents/Projects/SoftServe/vagrant-test/app/app/api/issues/[issueId]/route.ts","nextConfigOutput":"standalone"}
    const routeModule = new (module_default())({
      ...options,
      userland: route_namespaceObject,
    })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/issues/[issueId]/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [870,188,57,906,981,669,952], () => (__webpack_exec__(90670)));
module.exports = __webpack_exports__;

})();