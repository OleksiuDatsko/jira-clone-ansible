"use strict";
(() => {
var exports = {};
exports.id = 29;
exports.ids = [29];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 97783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 28530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 26682:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  headerHooks: () => (/* binding */ headerHooks),
  originalPathname: () => (/* binding */ originalPathname),
  requestAsyncStorage: () => (/* binding */ requestAsyncStorage),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage),
  staticGenerationBailout: () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./app/api/project/[project_id]/members/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  GET: () => (GET)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(35387);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(29267);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(32413);
// EXTERNAL MODULE: ./server/db.ts + 1 modules
var db = __webpack_require__(84952);
;// CONCATENATED MODULE: ./app/api/project/[project_id]/members/route.ts


async function GET(req, { params }) {
    const { project_id } = params;
    const members = await db/* prisma */._.member.findMany({
        where: {
            projectId: project_id
        }
    });
    // USE THIS IF RUNNING LOCALLY -----------------------
    const users = await db/* prisma */._.defaultUser.findMany({
        where: {
            id: {
                in: members.map((member)=>member.id)
            }
        }
    });
    // --------------------------------------------------
    // COMMENT THIS IF RUNNING LOCALLY ------------------
    // const users = (
    //   await clerkClient.users.getUserList({
    //     userId: members.map((member) => member.id),
    //     limit: 20,
    //   })
    // ).map(filterUserForClient);
    // --------------------------------------------------
    // return NextResponse.json<GetProjectMembersResponse>({ members:users });
    return next_response/* default */.Z.json({
        members: users
    });
}

;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fproject%2F%5Bproject_id%5D%2Fmembers%2Froute&name=app%2Fapi%2Fproject%2F%5Bproject_id%5D%2Fmembers%2Froute&pagePath=private-next-app-dir%2Fapi%2Fproject%2F%5Bproject_id%5D%2Fmembers%2Froute.ts&appDir=%2Fhome%2Foleksii%2FDocuments%2FProjects%2FSoftServe%2Fvagrant-test%2Fapp%2Fapp&appPaths=%2Fapi%2Fproject%2F%5Bproject_id%5D%2Fmembers%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&preferredRegion=&middlewareConfig=e30%3D!

    

    

    

    const options = {"definition":{"kind":"APP_ROUTE","page":"/api/project/[project_id]/members/route","pathname":"/api/project/[project_id]/members","filename":"route","bundlePath":"app/api/project/[project_id]/members/route"},"resolvedPagePath":"/home/oleksii/Documents/Projects/SoftServe/vagrant-test/app/app/api/project/[project_id]/members/route.ts","nextConfigOutput":"standalone"}
    const routeModule = new (module_default())({
      ...options,
      userland: route_namespaceObject,
    })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/project/[project_id]/members/route"

    

/***/ }),

/***/ 32413:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var __webpack_unused_export__;
// This file is for modularized imports for next/server to get fully-treeshaking.

__webpack_unused_export__ = ({
    value: true
});
Object.defineProperty(exports, "Z", ({
    enumerable: true,
    get: function() {
        return _response.NextResponse;
    }
}));
const _response = __webpack_require__(72917); //# sourceMappingURL=next-response.js.map


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [870,188,906,981,952], () => (__webpack_exec__(26682)));
module.exports = __webpack_exports__;

})();