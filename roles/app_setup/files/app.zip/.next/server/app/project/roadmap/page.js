(() => {
var exports = {};
exports.id = 211;
exports.ids = [211];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

"use strict";
module.exports = require("@prisma/client");

/***/ }),

/***/ 97783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 40252:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 97999:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 61090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 78652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 47244:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 21668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 72254:
/***/ ((module) => {

"use strict";
module.exports = require("node:buffer");

/***/ }),

/***/ 6005:
/***/ ((module) => {

"use strict";
module.exports = require("node:crypto");

/***/ }),

/***/ 87561:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ 88849:
/***/ ((module) => {

"use strict";
module.exports = require("node:http");

/***/ }),

/***/ 22286:
/***/ ((module) => {

"use strict";
module.exports = require("node:https");

/***/ }),

/***/ 87503:
/***/ ((module) => {

"use strict";
module.exports = require("node:net");

/***/ }),

/***/ 49411:
/***/ ((module) => {

"use strict";
module.exports = require("node:path");

/***/ }),

/***/ 97742:
/***/ ((module) => {

"use strict";
module.exports = require("node:process");

/***/ }),

/***/ 84492:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream");

/***/ }),

/***/ 72477:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream/web");

/***/ }),

/***/ 41041:
/***/ ((module) => {

"use strict";
module.exports = require("node:url");

/***/ }),

/***/ 47261:
/***/ ((module) => {

"use strict";
module.exports = require("node:util");

/***/ }),

/***/ 65628:
/***/ ((module) => {

"use strict";
module.exports = require("node:zlib");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 71267:
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 364:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppRouter: () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   LayoutRouter: () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   RenderFromTemplateContext: () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   StaticGenerationSearchParamsBailoutProvider: () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   __next_app_webpack_require__: () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   actionAsyncStorage: () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   createSearchParamsBailoutProxy: () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   decodeAction: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   decodeReply: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   preconnect: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   preloadFont: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   preloadStyle: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   renderToReadableStream: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   requestAsyncStorage: () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   serverHooks: () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   staticGenerationAsyncStorage: () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   staticGenerationBailout: () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(54592);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(76301);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57431);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(30094);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(24437);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(46127);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(45486);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(86404);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(95486);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(63332);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(27902);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(93099);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'project',
        {
        children: [
        'roadmap',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 33475)), "/home/oleksii/Documents/Projects/SoftServe/vagrant-test/app/app/project/roadmap/page.tsx"],
          
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1530)), "/home/oleksii/Documents/Projects/SoftServe/vagrant-test/app/app/project/roadmap/layout.tsx"],
'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 18185)), "/home/oleksii/Documents/Projects/SoftServe/vagrant-test/app/app/project/roadmap/loading.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 86484)), "/home/oleksii/Documents/Projects/SoftServe/vagrant-test/app/app/project/layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 21701))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76770)), "/home/oleksii/Documents/Projects/SoftServe/vagrant-test/app/app/layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 21701))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["/home/oleksii/Documents/Projects/SoftServe/vagrant-test/app/app/project/roadmap/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/project/roadmap/page"
  

/***/ }),

/***/ 36944:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 92557));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 25950));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 95525));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3280, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 69274, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3349, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 90701, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 38973));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 45008));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 15179));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 19329));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 98417));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 46158));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 15531));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 41757));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 38221));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 33369));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 90078));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3030));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 41380));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 50747))

/***/ }),

/***/ 50747:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Roadmap: () => (/* binding */ Roadmap)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./context/use-selected-issue-context.tsx
var use_selected_issue_context = __webpack_require__(90779);
// EXTERNAL MODULE: ./styles/split.css
var split = __webpack_require__(19746);
// EXTERNAL MODULE: ./context/use-filters-context.tsx
var use_filters_context = __webpack_require__(57165);
// EXTERNAL MODULE: ./components/filter-epic.tsx
var filter_epic = __webpack_require__(16077);
// EXTERNAL MODULE: ./components/filter-issue-type.tsx
var filter_issue_type = __webpack_require__(36665);
// EXTERNAL MODULE: ./components/filter-search-bar.tsx + 1 modules
var filter_search_bar = __webpack_require__(35608);
// EXTERNAL MODULE: ./components/members.tsx
var members = __webpack_require__(5801);
// EXTERNAL MODULE: ./components/filter-issue-clear.tsx
var filter_issue_clear = __webpack_require__(55403);
// EXTERNAL MODULE: ./components/filter-sprint.tsx
var filter_sprint = __webpack_require__(55370);
// EXTERNAL MODULE: ./components/not-implemented.tsx + 1 modules
var not_implemented = __webpack_require__(14782);
// EXTERNAL MODULE: ./node_modules/react-icons/bi/index.esm.js
var index_esm = __webpack_require__(85228);
// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(38546);
;// CONCATENATED MODULE: ./components/roadmap/header.tsx
/* __next_internal_client_entry_do_not_use__ RoadmapHeader auto */ 











const RoadmapHeader = ({ project })=>{
    const { search, setSearch } = (0,use_filters_context/* useFiltersContext */.P)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex h-fit flex-col",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "text-sm text-gray-500",
                children: [
                    "Projects / ",
                    project.name
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                children: "Roadmap "
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "my-3 flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center gap-x-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(filter_search_bar/* SearchBar */.E, {
                                search: search,
                                setSearch: setSearch
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(members/* Members */.i, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(filter_epic/* EpicFilter */.M, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(filter_issue_type/* IssueTypeFilter */.k, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(filter_sprint/* SprintFilter */.Y, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(filter_issue_clear/* ClearFilters */.B, {})
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(not_implemented/* NotImplemented */.r, {
                        feature: "insights",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                            className: "flex items-center gap-x-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BiLineChart */.ok1, {
                                    className: "text-gray-900"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-sm text-gray-900",
                                    children: "Insights"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};


// EXTERNAL MODULE: ./hooks/query-hooks/use-project.ts
var use_project = __webpack_require__(5663);
// EXTERNAL MODULE: ./node_modules/react-split/dist/react-split.js
var react_split = __webpack_require__(49641);
var react_split_default = /*#__PURE__*/__webpack_require__.n(react_split);
// EXTERNAL MODULE: ./components/issue/issue-details/index.tsx + 22 modules
var issue_details = __webpack_require__(37151);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
// EXTERNAL MODULE: ./components/ui/accordion.tsx
var accordion = __webpack_require__(74887);
// EXTERNAL MODULE: ./node_modules/react-icons/fa/index.esm.js
var fa_index_esm = __webpack_require__(16775);
// EXTERNAL MODULE: ./components/issue/issue-icon.tsx
var issue_icon = __webpack_require__(27603);
// EXTERNAL MODULE: ./hooks/query-hooks/use-issues/index.ts + 4 modules
var use_issues = __webpack_require__(14184);
// EXTERNAL MODULE: ./node_modules/clsx/dist/clsx.js
var clsx = __webpack_require__(14889);
var clsx_default = /*#__PURE__*/__webpack_require__.n(clsx);
// EXTERNAL MODULE: ./components/issue/issue-select-status.tsx
var issue_select_status = __webpack_require__(61803);
// EXTERNAL MODULE: ./components/issue/issue-select-assignee.tsx
var issue_select_assignee = __webpack_require__(64844);
// EXTERNAL MODULE: ./node_modules/react-icons/ai/index.esm.js
var ai_index_esm = __webpack_require__(19722);
// EXTERNAL MODULE: ./components/issue/issue-empty.tsx
var issue_empty = __webpack_require__(74349);
// EXTERNAL MODULE: ./node_modules/@clerk/clerk-react/dist/esm/index.js + 63 modules
var esm = __webpack_require__(48751);
// EXTERNAL MODULE: ./components/color-picker.tsx
var color_picker = __webpack_require__(14285);
// EXTERNAL MODULE: ./utils/helpers.ts
var helpers = __webpack_require__(89602);
// EXTERNAL MODULE: ./components/progress-bar.tsx
var progress_bar = __webpack_require__(40796);
// EXTERNAL MODULE: ./hooks/use-is-authed.ts
var use_is_authed = __webpack_require__(30660);
;// CONCATENATED MODULE: ./components/roadmap/epics-table.tsx



















const EpicsTable = ()=>{
    const { createIssue, isCreating } = (0,use_issues/* useIssues */.g)();
    const [isCreatingEpic, setIsCreatingEpic] = (0,react_.useState)(false);
    const renderContainerRef = (0,react_.useRef)(null);
    const [isAuthenticated, openAuthModal] = (0,use_is_authed/* useIsAuthenticated */.k)();
    const { user } = (0,esm/* useUser */.aF)();
    (0,react_.useLayoutEffect)(()=>{
        if (!renderContainerRef.current) return;
        const calculatedHeight = renderContainerRef.current.offsetTop + 15;
        renderContainerRef.current.style.height = `calc(100vh - ${calculatedHeight}px)`;
    }, []);
    function handleCreateIssue({ name, type, parentId = null, sprintColor = null }) {
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        if (!name) {
            return;
        }
        createIssue({
            name,
            type,
            parentId,
            sprintId: null,
            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            reporterId: user.id,
            sprintColor
        }, {
            onSuccess: ()=>{
                setIsCreatingEpic(false);
            }
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full overflow-y-auto rounded-[3px] border",
        ref: renderContainerRef,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "sticky top-0 z-10 h-10 bg-gray-100"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(EpicsAccordion, {
                handleCreateIssue: handleCreateIssue
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "sticky bottom-0 h-10 border-t bg-white",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                        onClick: ()=>setIsCreatingEpic(true),
                        "data-state": isCreatingEpic ? "closed" : "open",
                        customColors: true,
                        className: "flex w-full items-center gap-x-1.5 hover:bg-gray-100 [&[data-state=closed]]:hidden",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ai_index_esm/* AiOutlinePlus */.Lfi, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-[14px] font-medium",
                                children: "Create Epic"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(issue_empty/* EmtpyIssue */.z, {
                        "data-state": isCreatingEpic ? "open" : "closed",
                        className: "[&[data-state=closed]]:hidden",
                        onCreate: ({ name })=>handleCreateIssue({
                                name,
                                type: "EPIC",
                                sprintColor: color_picker/* LIGHT_COLORS */.yD[0]?.hex ?? null
                            }),
                        onCancel: ()=>setIsCreatingEpic(false),
                        isCreating: isCreating,
                        isEpic: true
                    })
                ]
            })
        ]
    });
};
const EpicsAccordion = ({ handleCreateIssue })=>{
    const [creationParent, setCreationParent] = (0,react_.useState)(null);
    const { setIssueKey } = (0,use_selected_issue_context.useSelectedIssueContext)();
    const { issues, isCreating } = (0,use_issues/* useIssues */.g)();
    const { search, assignees, issueTypes, epics, sprints } = (0,use_filters_context/* useFiltersContext */.P)();
    const [openAccordions, setOpenAccordions] = (0,react_.useState)([]);
    const filterIssues = (0,react_.useCallback)((issues)=>{
        if (!issues) return [];
        const filteredIssues = issues.filter((issue)=>{
            if (!(0,helpers/* isSubtask */.UU)(issue)) {
                if ((0,helpers/* issueNotInSearch */.Po)({
                    issue,
                    search
                })) return false;
                if ((0,helpers/* assigneeNotInFilters */.tf)({
                    issue,
                    assignees
                })) return false;
                if ((0,helpers/* epicNotInFilters */.rg)({
                    issue,
                    epics
                })) return false;
                if ((0,helpers/* issueTypeNotInFilters */.x2)({
                    issue,
                    issueTypes
                })) return false;
                if ((0,helpers/* issueSprintNotInFilters */.UH)({
                    issue,
                    sprintIds: sprints,
                    excludeBacklog: true
                })) {
                    return false;
                }
                return true;
            }
            return false;
        });
        return filteredIssues;
    }, [
        search,
        assignees,
        epics,
        issueTypes,
        sprints
    ]);
    function handleAddIssueToEpic(issueKey, index) {
        setCreationParent(index);
        setOpenAccordions((prev)=>[
                ...prev,
                issueKey
            ]);
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(accordion/* Accordion */.UQ, {
        value: openAccordions,
        onValueChange: setOpenAccordions,
        type: "multiple",
        className: "overflow-hidden",
        children: issues?.filter((issue)=>issue.type == "EPIC").map((issue, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(accordion/* AccordionItem */.Qd, {
                value: issue.key,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: clsx_default()(index % 2 == 0 ? "bg-white" : "bg-gray-100", "flex w-full items-center justify-between hover:bg-gray-200"),
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(accordion/* AccordionTrigger */.o4, {
                                className: "flex w-full items-center px-2 py-2.5 font-medium [&[data-state=open]>svg]:rotate-90",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(fa_index_esm/* FaChevronRight */.Dli, {
                                    "data-state": issue.children.length ? "show-arrow" : "hide-arrow",
                                    className: "mr-2 text-xs text-transparent transition-transform [&[data-state=show-arrow]]:text-black",
                                    "aria-hidden": true
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-grow items-center py-1.5",
                                role: "button",
                                onClick: ()=>setIssueKey(issue.key),
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(issue_icon/* IssueIcon */.u, {
                                        issueType: "EPIC"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex flex-col gap-y-1 py-1",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "flex items-center",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex items-center gap-x-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "ml-3 text-sm font-normal text-gray-500",
                                                            children: issue.key
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "text-sm font-normal",
                                                            children: issue.name
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "ml-3 w-64",
                                                children: issue.children.length ? /*#__PURE__*/ jsx_runtime_.jsx(progress_bar/* ProgressBar */.k, {
                                                    variant: "sm",
                                                    issues: issue.children
                                                }) : null
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                customColors: true,
                                className: "mr-2  hover:bg-gray-300",
                                onClick: ()=>handleAddIssueToEpic(issue.key, index),
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_index_esm/* AiOutlinePlus */.Lfi, {})
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(accordion/* AccordionContent */.vF, {
                        children: [
                            filterIssues(issue.children)?.map((child)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    role: "button",
                                    onClick: ()=>setIssueKey(child.key),
                                    className: "flex items-center justify-between p-1.5 pl-12 hover:bg-gray-100",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex items-center gap-x-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(issue_icon/* IssueIcon */.u, {
                                                    issueType: child.type
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    "data-state": child.status,
                                                    className: "whitespace-nowrap text-sm text-gray-500 [&[data-state=DONE]]:line-through",
                                                    children: child.key
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "text-sm",
                                                    children: child.name
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex items-center gap-x-2 pr-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(issue_select_status/* IssueSelectStatus */.ej, {
                                                    currentStatus: child.status,
                                                    issueId: child.id
                                                }, child.key + child.status),
                                                /*#__PURE__*/ jsx_runtime_.jsx(issue_select_assignee/* IssueAssigneeSelect */.G, {
                                                    issue: child,
                                                    avatarSize: 18,
                                                    avatarOnly: true
                                                })
                                            ]
                                        })
                                    ]
                                }, child.key)),
                            /*#__PURE__*/ jsx_runtime_.jsx(issue_empty/* EmtpyIssue */.z, {
                                "data-state": creationParent == index ? "open" : "closed",
                                className: "[&[data-state=closed]]:hidden",
                                onCreate: ({ name, type })=>handleCreateIssue({
                                        name,
                                        type,
                                        parentId: issue.id
                                    }),
                                onCancel: ()=>setCreationParent(null),
                                isCreating: isCreating
                            })
                        ]
                    })
                ]
            }, issue.id))
    });
};


;// CONCATENATED MODULE: ./components/roadmap/index.tsx
/* __next_internal_client_entry_do_not_use__ Roadmap auto */ 









const Roadmap = ()=>{
    const { issueKey, setIssueKey } = (0,use_selected_issue_context.useSelectedIssueContext)();
    const renderContainerRef = (0,react_.useRef)(null);
    const { project } = (0,use_project/* useProject */.P)();
    (0,react_.useLayoutEffect)(()=>{
        if (!renderContainerRef.current) return;
        const calculatedHeight = renderContainerRef.current.offsetTop;
        renderContainerRef.current.style.height = `calc(100vh - ${calculatedHeight}px)`;
    }, []);
    if (!project) {
        return (0,navigation.notFound)();
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(RoadmapHeader, {
                project: project
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                ref: renderContainerRef,
                className: "min-w-full max-w-max",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((react_split_default()), {
                    sizes: issueKey ? [
                        60,
                        40
                    ] : [
                        100,
                        0
                    ],
                    gutterSize: issueKey ? 2 : 0,
                    className: "flex max-h-full w-full",
                    minSize: issueKey ? 400 : 0,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(EpicsTable, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(issue_details/* IssueDetails */.G, {
                            setIssueKey: setIssueKey,
                            issueKey: issueKey
                        })
                    ]
                })
            })
        ]
    });
};



/***/ }),

/***/ 1530:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7431);
/* harmony import */ var _context_use_selected_issue_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(74960);



const RoadmapLayout = ({ children })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_container__WEBPACK_IMPORTED_MODULE_1__/* .Container */ .W, {
        className: "h-full",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
            className: "w-full",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context_use_selected_issue_context__WEBPACK_IMPORTED_MODULE_2__/* .SelectedIssueProvider */ .V, {
                children: children
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RoadmapLayout);


/***/ }),

/***/ 18185:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_skeletons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57042);


const RoadmapSkeleton = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        role: "status",
        className: "flex h-[calc(100vh_-_3rem)] animate-pulse flex-col",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_skeletons__WEBPACK_IMPORTED_MODULE_1__/* .BreadCrumbSkeleton */ .St, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_skeletons__WEBPACK_IMPORTED_MODULE_1__/* .TitleSkeleton */ .Li, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_skeletons__WEBPACK_IMPORTED_MODULE_1__/* .SprintSearchSkeleton */ .UL, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_skeletons__WEBPACK_IMPORTED_MODULE_1__/* .RoadmapTableSkeleton */ .jr, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "sr-only",
                children: "Loading..."
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RoadmapSkeleton);


/***/ }),

/***/ 33475:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./utils/get-query-client.tsx
var get_query_client = __webpack_require__(77615);
// EXTERNAL MODULE: ./utils/hydrate.tsx
var hydrate = __webpack_require__(85517);
// EXTERNAL MODULE: ./node_modules/@tanstack/query-core/build/lib/hydration.mjs
var hydration = __webpack_require__(12874);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./components/roadmap/index.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/home/oleksii/Documents/Projects/SoftServe/vagrant-test/app/components/roadmap/index.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["Roadmap"];

// EXTERNAL MODULE: ./server/functions.ts + 1 modules
var functions = __webpack_require__(84305);
// EXTERNAL MODULE: ./node_modules/@clerk/nextjs/dist/esm/index.js + 17 modules
var esm = __webpack_require__(36886);
;// CONCATENATED MODULE: ./app/project/roadmap/page.tsx







const metadata = {
    title: "Roadmap"
};
const RoadmapPage = async ()=>{
    const user = await (0,esm/* currentUser */.ar)();
    const queryClient = (0,get_query_client/* getQueryClient */.g)();
    await Promise.all([
        await queryClient.prefetchQuery([
            "issues"
        ], ()=>(0,functions/* getInitialIssuesFromServer */.Xp)(user?.id)),
        await queryClient.prefetchQuery([
            "sprints"
        ], ()=>(0,functions/* getInitialSprintsFromServer */.hq)(user?.id)),
        await queryClient.prefetchQuery([
            "project"
        ], functions/* getInitialProjectFromServer */.v1)
    ]);
    const dehydratedState = (0,hydration/* dehydrate */.D)(queryClient);
    return /*#__PURE__*/ jsx_runtime_.jsx(hydrate/* Hydrate */.p, {
        state: dehydratedState,
        children: /*#__PURE__*/ jsx_runtime_.jsx(e0, {})
    });
};
/* harmony default export */ const page = (RoadmapPage);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [870,188,57,906,669,569,210,950,886,518,952,846,688,390,661], () => (__webpack_exec__(364)));
module.exports = __webpack_exports__;

})();