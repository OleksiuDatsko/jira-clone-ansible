"use strict";
exports.id = 316;
exports.ids = [316];
exports.modules = {

/***/ 20645:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ Issue),
/* harmony export */   a: () => (/* binding */ EpicName)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(85926);
/* harmony import */ var _issue_issue_icon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(27603);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(38546);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(75484);
/* harmony import */ var _svgs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(16206);
/* harmony import */ var _ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(41772);
/* harmony import */ var _ui_context_menu__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(72463);
/* harmony import */ var _issue_issue_menu__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(38620);
/* harmony import */ var _issue_issue_select_status__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(61803);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(64348);
/* harmony import */ var _issue_issue_title__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(38698);
/* harmony import */ var _context_use_selected_issue_context__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(90779);
/* harmony import */ var _utils_helpers__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(89602);
/* harmony import */ var _issue_issue_select_assignee__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(64844);
/* harmony import */ var _color_picker__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(14285);
/* __next_internal_client_entry_do_not_use__ EpicName,Issue auto */ 

















const Issue = ({ index, issue })=>{
    const [isEditing, setIsEditing] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const { setIssueKey, issueKey } = (0,_context_use_selected_issue_context__WEBPACK_IMPORTED_MODULE_11__.useSelectedIssueContext)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_14__/* .Draggable */ ._l, {
        draggableId: issue.id,
        index: index,
        children: ({ innerRef, dragHandleProps, draggableProps }, { isDragging })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                role: "button",
                "data-state": issueKey == issue.key ? "selected" : "not-selected",
                onClick: ()=>setIssueKey(issue.key),
                ref: innerRef,
                ...draggableProps,
                ...dragHandleProps,
                className: clsx__WEBPACK_IMPORTED_MODULE_4___default()(isDragging ? "border-[0.3px] border-gray-300 bg-blue-100" : "bg-white", "group flex w-full max-w-full items-center justify-between  px-3 py-1.5 text-sm hover:bg-gray-50 [&[data-state=selected]]:bg-blue-100"),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        "data-state": isEditing ? "editing" : "not-editing",
                        className: "flex w-fit items-center gap-x-2 [&[data-state=editing]]:w-full [&[data-state=not-editing]]:overflow-x-hidden",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_issue_issue_icon__WEBPACK_IMPORTED_MODULE_2__/* .IssueIcon */ .u, {
                                issueType: issue.type
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                "data-state": issue.status,
                                className: "whitespace-nowrap text-gray-500 [&[data-state=DONE]]:line-through",
                                children: issue.key
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_issue_issue_title__WEBPACK_IMPORTED_MODULE_10__/* .IssueTitle */ .w, {
                                className: "truncate py-1.5 hover:cursor-pointer hover:underline",
                                isEditing: isEditing,
                                setIsEditing: setIsEditing,
                                issue: issue,
                                useTooltip: true,
                                ref: inputRef
                            }, issue.id + issue.name),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                "data-state": isEditing ? "editing" : "not-editing",
                                className: "flex items-center gap-x-1 [&[data-state=editing]]:hidden",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_3__/* .Button */ .z, {
                                        onClick: (e)=>{
                                            e.stopPropagation();
                                            setIsEditing(!isEditing);
                                        },
                                        className: "invisible w-0 px-0 group-hover:visible group-hover:w-fit group-hover:bg-transparent group-hover:px-1.5 group-hover:hover:bg-gray-200 ",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_15__/* .MdEdit */ .zmo, {
                                            className: "text-sm"
                                        })
                                    }),
                                    (0,_utils_helpers__WEBPACK_IMPORTED_MODULE_16__/* .isEpic */ .pQ)(issue.parent) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(EpicName, {
                                        issue: issue.parent
                                    }) : null
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_issue_issue_menu__WEBPACK_IMPORTED_MODULE_8__/* .IssueContextMenu */ .L, {
                        isEditing: isEditing,
                        className: "flex-auto",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_context_menu__WEBPACK_IMPORTED_MODULE_7__/* .ContextTrigger */ .ud, {
                            className: "h-8 w-full"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "relative ml-2 flex min-w-fit items-center justify-end gap-x-2",
                        children: [
                            (0,_utils_helpers__WEBPACK_IMPORTED_MODULE_16__/* .hasChildren */ .g8)(issue) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_svgs__WEBPACK_IMPORTED_MODULE_5__/* .ChildrenTreeIcon */ .eS, {
                                className: "p-0.5 text-gray-600"
                            }) : null,
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_issue_issue_select_status__WEBPACK_IMPORTED_MODULE_9__/* .IssueSelectStatus */ .ej, {
                                currentStatus: issue.status,
                                issueId: issue.id
                            }, issue.id + issue.status),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_issue_issue_select_assignee__WEBPACK_IMPORTED_MODULE_12__/* .IssueAssigneeSelect */ .G, {
                                issue: issue,
                                avatarOnly: true
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_issue_issue_menu__WEBPACK_IMPORTED_MODULE_8__/* .IssueDropdownMenu */ .U, {
                                issue: issue,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_6__/* .DropdownTrigger */ .WA, {
                                    asChild: true,
                                    className: "rounded-m flex items-center gap-x-2 bg-opacity-30 px-1.5 text-xs font-semibold focus:ring-2 ",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "invisible rounded-sm px-1.5 py-1.5 text-gray-700 group-hover:visible group-hover:bg-gray-200 group-hover:hover:bg-gray-300 [&[data-state=open]]:visible [&[data-state=open]]:bg-gray-700 [&[data-state=open]]:text-white",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_17__/* .BsThreeDots */ .evw, {
                                            className: "sm:text-xl"
                                        })
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
    });
};
const EpicName = ({ issue, className })=>{
    const lightColor = _color_picker__WEBPACK_IMPORTED_MODULE_13__/* .LIGHT_COLORS */ .yD.find((color)=>color.hex == issue.sprintColor);
    const bgColor = (0,_utils_helpers__WEBPACK_IMPORTED_MODULE_16__/* .hexToRgba */ .a7)(issue.sprintColor, !!lightColor ? 0.5 : 1);
    function calcTextColor() {
        if (lightColor) {
            return _color_picker__WEBPACK_IMPORTED_MODULE_13__/* .DARK_COLORS */ .Ro.find((color)=>color.label == lightColor.label)?.hex;
        } else {
            return "white";
        }
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        style: {
            backgroundColor: bgColor,
            color: calcTextColor()
        },
        className: clsx__WEBPACK_IMPORTED_MODULE_4___default()("whitespace-nowrap rounded-[3px] px-2 text-xs font-bold", className),
        children: issue.name.toUpperCase()
    });
};



/***/ }),

/***/ 83919:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   d: () => (/* binding */ useStrictModeDroppable)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* __next_internal_client_entry_do_not_use__ useStrictModeDroppable auto */ 
const useStrictModeDroppable = ()=>{
    // This is a hack to get around the fact that react-beautiful-dnd doesn't work very well in StrictMode.
    const [enabled, setEnabled] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const animation = requestAnimationFrame(()=>setEnabled(true));
        return ()=>{
            cancelAnimationFrame(animation);
            setEnabled(false);
        };
    }, []);
    return [
        enabled
    ];
};


/***/ })

};
;