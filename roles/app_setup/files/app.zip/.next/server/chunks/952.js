"use strict";
exports.id = 952;
exports.ids = [952];
exports.modules = {

/***/ 84952:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  _: () => (/* binding */ prisma),
  $: () => (/* binding */ ratelimit)
});

// EXTERNAL MODULE: external "@prisma/client"
var client_ = __webpack_require__(53524);
// EXTERNAL MODULE: ./node_modules/@upstash/ratelimit/dist/index.js
var dist = __webpack_require__(25192);
// EXTERNAL MODULE: ./node_modules/@upstash/redis/esm/platforms/nodejs.js + 154 modules
var nodejs = __webpack_require__(67889);
// EXTERNAL MODULE: ./node_modules/zod/lib/index.mjs
var lib = __webpack_require__(83445);
;// CONCATENATED MODULE: ./env.mjs

/**
 * Specify your server-side environment variables schema here. This way you can ensure the app isn't
 * built with invalid env vars.
 */ const server = lib.z.object({
    DATABASE_URL: lib.z.string().url(),
    NODE_ENV: lib.z.enum([
        "development",
        "test",
        "production"
    ])
});
/**
 * Specify your client-side environment variables schema here. This way you can ensure the app isn't
 * built with invalid env vars. To expose them to the client, prefix them with `NEXT_PUBLIC_`.
 */ const client = lib.z.object({
});
/**
 * You can't destruct `process.env` as a regular object in the Next.js edge runtimes (e.g.
 * middlewares) or client-side so we need to destruct manually.
 *
 * @type {Record<keyof z.infer<typeof server> | keyof z.infer<typeof client>, string | undefined>}
 */ const processEnv = {
    DATABASE_URL: process.env.DATABASE_URL,
    NODE_ENV: "production"
};
// Don't touch the part below
// --------------------------
const merged = server.merge(client);
/** @typedef {z.input<typeof merged>} MergedInput */ /** @typedef {z.infer<typeof merged>} MergedOutput */ /** @typedef {z.SafeParseReturnType<MergedInput, MergedOutput>} MergedSafeParseReturn */ let env = /** @type {MergedOutput} */ process.env;
if (!!process.env.SKIP_ENV_VALIDATION == false) {
    const isServer = "undefined" === "undefined";
    const parsed = /** @type {MergedSafeParseReturn} */ isServer ? merged.safeParse(processEnv) // on server we can validate all env vars
     : client.safeParse(processEnv) // on client we can only validate the ones that are exposed
    ;
    if (parsed.success === false) {
        console.error("❌ Invalid environment variables:", parsed.error.flatten().fieldErrors);
        throw new Error("Invalid environment variables");
    }
    env = new Proxy(parsed.data, {
        get (target, prop) {
            if (typeof prop !== "string") return undefined;
            // Throw a descriptive error if a server-side env var is accessed on the client
            // Otherwise it would just be returning `undefined` and be annoying to debug
            if (!isServer && !prop.startsWith("NEXT_PUBLIC_")) throw new Error( true ? "❌ Attempted to access a server-side environment variable on the client" : 0);
            return target[/** @type {keyof typeof target} */ prop];
        }
    });
}


;// CONCATENATED MODULE: ./server/db.ts




const globalForPrisma = globalThis;
const ratelimit = new dist.Ratelimit({
    redis: nodejs/* Redis */.s.fromEnv(),
    limiter: dist.Ratelimit.slidingWindow(15, "1 m"),
    analytics: true
});
const prisma = globalForPrisma.prisma ?? new client_.PrismaClient({
    log: env.NODE_ENV === "development" ? [
        "query",
        "error",
        "warn"
    ] : [
        "error"
    ]
});
if (env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;


/***/ })

};
;