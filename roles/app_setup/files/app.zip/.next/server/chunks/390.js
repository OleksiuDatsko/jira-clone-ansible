exports.id = 390;
exports.ids = [390];
exports.modules = {

/***/ 81152:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 85637))

/***/ }),

/***/ 32015:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 90779))

/***/ }),

/***/ 34914:
/***/ (() => {



/***/ }),

/***/ 85637:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ layout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/svgs.tsx
var svgs = __webpack_require__(16206);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-navigation-menu/dist/index.js
var dist = __webpack_require__(56832);
// EXTERNAL MODULE: ./node_modules/clsx/dist/clsx.js
var clsx = __webpack_require__(14889);
var clsx_default = /*#__PURE__*/__webpack_require__.n(clsx);
;// CONCATENATED MODULE: ./components/ui/navigation-menu.tsx




const NavigationMenu = dist.Root;
const NavigationMenuTrigger = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Trigger, {
        className: clsx_default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
NavigationMenuTrigger.displayName = "NavigationMenuTrigger";
const NavigationMenuList = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.List, {
        className: clsx_default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
NavigationMenuList.displayName = "NavigationMenuList";
const NavigationMenuItem = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Item, {
        className: clsx_default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
NavigationMenuItem.displayName = "NavigationMenuItem";
const NavigationMenuContent = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Content, {
        className: clsx_default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
NavigationMenuContent.displayName = "NavigationMenuContent";
const NavigationMenuLink = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Link, {
        className: clsx_default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
NavigationMenuLink.displayName = "NavigationMenuLink";
const NavigationMenuSub = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Sub, {
        className: clsx_default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
NavigationMenuSub.displayName = "NavigationMenuSub";
const NavigationMenuViewport = /*#__PURE__*/ react_default().forwardRef(({ className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Viewport, {
        className: clsx_default()("", className),
        ...props,
        ref: forwardedRef
    }));
NavigationMenuViewport.displayName = "NavigationMenuViewport";
const NavigationMenuIndicator = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Indicator, {
        className: clsx_default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
NavigationMenuIndicator.displayName = "NavigationMenuIndicator";


// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
// EXTERNAL MODULE: ./node_modules/react-icons/fa/index.esm.js
var index_esm = __webpack_require__(16775);
// EXTERNAL MODULE: ./hooks/query-hooks/use-project.ts
var use_project = __webpack_require__(5663);
;// CONCATENATED MODULE: ./components/sidebar.tsx
/* __next_internal_client_entry_do_not_use__ Sidebar auto */ 







const Sidebar = ()=>{
    const { project } = (0,use_project/* useProject */.P)();
    const planningItems = [
        {
            id: "roadmap",
            label: "Roadmap",
            icon: svgs/* RoadmapIcon */.Qe,
            href: `/project/roadmap`
        },
        {
            id: "backlog",
            label: "Backlog",
            icon: svgs/* BacklogIcon */.Mi,
            href: `/project/backlog`
        },
        {
            id: "board",
            label: "Board",
            icon: svgs/* BoardIcon */.Lq,
            href: `/project/board`
        }
    ];
    const developmentItems = [
        {
            id: "development",
            label: "Development",
            icon: svgs/* DevelopmentIcon */.JK,
            href: `/project/`
        }
    ];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex h-full w-64 flex-col gap-y-5 bg-gray-50 p-3 shadow-inner",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "my-5 flex items-center gap-x-2 px-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mt-1 flex items-center justify-center rounded-sm bg-[#FF5630] p-1 text-xs font-bold text-white",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* FaChessPawn */.ONS, {
                            className: "aspect-square text-2xl"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "-mb-[0.5px] text-sm font-semibold text-gray-600",
                                children: project?.name ?? "Project Name"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-xs text-gray-500",
                                children: "Software Project"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(NavList, {
                label: "PLANNING",
                items: planningItems
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(NavList, {
                label: "DEVELOPMENT",
                items: developmentItems
            })
        ]
    });
};
const NavList = ({ items, label })=>{
    const [isVisible, setIsVisible] = (0,react_.useState)(true);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col gap-y-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(NavListHeader, {
                label: label,
                isVisible: isVisible,
                setIsVisible: setIsVisible
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(NavigationMenu, {
                "data-state": isVisible ? "open" : "closed",
                className: "hidden [&[data-state=open]]:block",
                children: /*#__PURE__*/ jsx_runtime_.jsx(NavigationMenuList, {
                    children: items.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(NavItem, {
                            item: item,
                            disabled: label === "DEVELOPMENT"
                        }, item.id))
                })
            })
        ]
    });
};
const NavListHeader = ({ label, isVisible, setIsVisible })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "group flex items-center gap-x-1",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                "data-state": isVisible ? "open" : "closed",
                onClick: ()=>setIsVisible(!isVisible),
                className: "invisible group-hover:visible [&[data-state=open]>svg]:rotate-90",
                children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* FaChevronRight */.Dli, {
                    className: "text-xs transition-transform"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "text-xs font-bold text-gray-700",
                children: label
            })
        ]
    });
const NavItem = ({ item, disabled = false })=>{
    const currentPath = (0,navigation.usePathname)();
    if (disabled) {
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "w-full rounded-lg text-gray-600 hover:cursor-not-allowed",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex w-full items-center gap-x-3 border-l-4 border-transparent px-2 py-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(item.icon, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-sm",
                        children: item.label
                    })
                ]
            })
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: item.href,
        className: "w-full rounded-lg text-gray-600 ",
        passHref: true,
        legacyBehavior: true,
        children: /*#__PURE__*/ jsx_runtime_.jsx(NavigationMenuLink, {
            active: currentPath === item.href,
            className: "flex w-full rounded-sm border-transparent py-2 [&[data-active]]:border-l-blue-700 [&[data-active]]:bg-blue-100 [&[data-active]]:text-blue-700",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex w-full items-center gap-x-3 border-l-4 border-inherit bg-inherit px-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(item.icon, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-sm",
                        children: item.label
                    })
                ]
            })
        })
    });
};


// EXTERNAL MODULE: ./node_modules/@clerk/clerk-react/dist/esm/index.js + 63 modules
var esm = __webpack_require__(48751);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(38546);
// EXTERNAL MODULE: ./node_modules/react-icons/ai/index.esm.js
var ai_index_esm = __webpack_require__(19722);
;// CONCATENATED MODULE: ./hooks/use-full-url.ts
/* __next_internal_client_entry_do_not_use__ useFullURL auto */ 

const useFullURL = ()=>{
    const pathname = (0,navigation.usePathname)();
    const searchParams = (0,navigation.useSearchParams)();
    const [url, setUrl] = (0,react_.useState)("/");
    (0,react_.useEffect)(()=>{
        // eslint-disable-next-line
        setUrl(`${pathname}?${searchParams}`);
    }, [
        pathname,
        searchParams
    ]);
    return [
        url
    ];
};

;// CONCATENATED MODULE: ./components/top-navbar.tsx
/* __next_internal_client_entry_do_not_use__ TopNavbar auto */ 






const TopNavbar = ()=>{
    const { user } = (0,esm/* useUser */.aF)();
    const [url] = useFullURL();
    const [stars, setStars] = (0,react_.useState)(null);
    (0,react_.useEffect)(()=>{
        // eslint-disable-next-line @typescript-eslint/no-floating-promises
        fetchStars();
    }, []);
    async function fetchStars() {
        const response = await fetch("https://api.github.com/repos/sebastianfdz/jira_clone");
        if (!response.ok) {
            setStars(null);
            return;
        }
        const data = await response.json();
        setStars(data.stargazers_count ?? null);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex h-12 w-full items-center justify-between border-b px-4",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center gap-x-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "https://cdn.worldvectorlogo.com/logos/jira-3.svg",
                        alt: "Jira logo",
                        width: 25,
                        height: 25
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-sm font-medium text-gray-600",
                        children: "Jira Clone"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                        href: "https://github.com/sebastianfdz/jira_clone",
                        target: "_blank",
                        className: "ml-3 flex gap-x-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ai_index_esm/* AiFillGithub */.RrF, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-sm font-medium",
                                children: "Github Repo"
                            })
                        ]
                    }),
                    stars ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                        href: "https://github.com/sebastianfdz/jira_clone",
                        target: "_blank",
                        customColors: true,
                        className: "ml-3 flex gap-x-2 bg-black",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ai_index_esm/* AiFillGithub */.RrF, {
                                className: "text-white"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: " text-sm font-medium text-white",
                                children: "Star"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex items-center pr-1.5 text-sm font-medium text-white",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "pr-1",
                                        children: stars
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ai_index_esm/* AiFillStar */.pHD, {
                                        className: "text-yellow-300"
                                    })
                                ]
                            })
                        ]
                    }) : null
                ]
            }),
            user ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center gap-x-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-sm font-medium text-gray-600",
                        children: user?.fullName ?? user?.emailAddresses[0]?.emailAddress ?? "Guest"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(esm/* UserButton */.l8, {
                        afterSignOutUrl: "/"
                    })
                ]
            }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex items-center gap-x-3",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "rounded-sm bg-inprogress px-3 py-1.5 text-sm font-medium text-white hover:bg-blue-600",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(esm/* SignInButton */.$d, {
                        mode: "modal",
                        redirectUrl: url
                    })
                })
            })
        ]
    });
};


// EXTERNAL MODULE: ./context/use-filters-context.tsx
var use_filters_context = __webpack_require__(57165);
;// CONCATENATED MODULE: ./app/project/layout.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




const ProjectLayout = ({ children })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(TopNavbar, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                className: "flex h-[calc(100vh_-_3rem)] w-full",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Sidebar, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(use_filters_context/* FiltersProvider */.W, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full max-w-[calc(100vw_-_16rem)]",
                            children: children
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const layout = (ProjectLayout);


/***/ }),

/***/ 76628:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   q: () => (/* binding */ Avatar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ui_tooltip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45197);
/* harmony import */ var _components_svgs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16206);




const Avatar = ({ src, alt, size = 32, ...props })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_tooltip__WEBPACK_IMPORTED_MODULE_2__/* .TooltipWrapper */ .pf, {
        text: alt,
        children: src ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
            src: src,
            alt: alt,
            height: size,
            width: size,
            className: "h-8 w-8 rounded-full",
            ...props
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_svgs__WEBPACK_IMPORTED_MODULE_3__/* .UnassignedUser */ .lP, {
                size: size,
                className: "h-fit w-fit rounded-full bg-gray-200 text-gray-500"
            })
        })
    });
};



/***/ }),

/***/ 14285:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ro: () => (/* binding */ DARK_COLORS),
/* harmony export */   yD: () => (/* binding */ LIGHT_COLORS),
/* harmony export */   zH: () => (/* binding */ ColorPicker)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ui_select__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(13785);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks_query_hooks_use_issues__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(14184);
/* harmony import */ var _hooks_use_is_authed__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(30660);






const LIGHT_COLORS = [
    {
        hex: "#9f8fef",
        label: "purple"
    },
    {
        hex: "#579dff",
        label: "blue"
    },
    {
        hex: "#4cce97",
        label: "green"
    },
    {
        hex: "#61c6d2",
        label: "teal"
    },
    {
        hex: "#e1b205",
        label: "yellow"
    },
    {
        hex: "#f97463",
        label: "red"
    },
    {
        hex: "#8590a2",
        label: "gray"
    }
];
const DARK_COLORS = [
    {
        hex: "#6e5dc6",
        label: "purple"
    },
    {
        hex: "#0b66e4",
        label: "blue"
    },
    {
        hex: "#20845a",
        label: "green"
    },
    {
        hex: "#1e7f8c",
        label: "teal"
    },
    {
        hex: "#b65c01",
        label: "yellow"
    },
    {
        hex: "#ca3521",
        label: "red"
    },
    {
        hex: "#616f86",
        label: "gray"
    }
];
const ColorPicker = ({ issue })=>{
    const [selected, setSelected] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(issue.sprintColor ?? null);
    const { updateIssue } = (0,_hooks_query_hooks_use_issues__WEBPACK_IMPORTED_MODULE_4__/* .useIssues */ .g)();
    const [isAuthenticated, openAuthModal] = (0,_hooks_use_is_authed__WEBPACK_IMPORTED_MODULE_5__/* .useIsAuthenticated */ .k)();
    function handleSelectChange(value) {
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        setSelected(value);
        updateIssue({
            issueId: issue.id,
            sprintColor: value
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ui_select__WEBPACK_IMPORTED_MODULE_2__/* .Select */ .Ph, {
        onValueChange: handleSelectChange,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_select__WEBPACK_IMPORTED_MODULE_2__/* .SelectTrigger */ .i4, {
                onClick: (e)=>e.stopPropagation(),
                // disabled={isUpdating}
                className: clsx__WEBPACK_IMPORTED_MODULE_1___default()("flex w-fit items-center gap-x-1 whitespace-nowrap"),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_select__WEBPACK_IMPORTED_MODULE_2__/* .SelectValue */ .ki, {
                    asChild: true,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ColorSquare, {
                        color: selected ?? "#9f8fef"
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_select__WEBPACK_IMPORTED_MODULE_2__/* .SelectPortal */ .ue, {
                className: "z-50 w-full",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_select__WEBPACK_IMPORTED_MODULE_2__/* .SelectContent */ .Bw, {
                    position: "popper",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ui_select__WEBPACK_IMPORTED_MODULE_2__/* .SelectViewport */ .Q_, {
                        className: "flex w-full flex-col gap-y-2 rounded-md border border-gray-300 bg-white p-2 shadow-md",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_select__WEBPACK_IMPORTED_MODULE_2__/* .SelectGroup */ .DI, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "m-0 flex items-center gap-x-2 p-0",
                                    children: LIGHT_COLORS.map((color)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_select__WEBPACK_IMPORTED_MODULE_2__/* .SelectItem */ .Ql, {
                                            asChild: true,
                                            value: color.hex,
                                            "data-state": color.hex == selected ? "checked" : "unchecked",
                                            noBorder: true,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ColorSquare, {
                                                color: color.hex
                                            })
                                        }, color.hex))
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_select__WEBPACK_IMPORTED_MODULE_2__/* .SelectGroup */ .DI, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "m-0 flex items-center gap-x-2 p-0",
                                    children: DARK_COLORS.map((color)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_select__WEBPACK_IMPORTED_MODULE_2__/* .SelectItem */ .Ql, {
                                            asChild: true,
                                            value: color.hex,
                                            "data-state": color.hex == selected ? "checked" : "unchecked",
                                            noBorder: true,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ColorSquare, {
                                                color: color.hex
                                            })
                                        }, color.hex))
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};
const ColorSquare = ({ color })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        role: "button",
        className: "h-6 w-6 rounded-[3px] p-0",
        style: {
            backgroundColor: color
        }
    });
};



/***/ }),

/***/ 16077:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   M: () => (/* binding */ EpicFilter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(41772);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(16775);
/* harmony import */ var _hooks_query_hooks_use_issues__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14184);
/* harmony import */ var _utils_helpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(89602);
/* harmony import */ var _components_ui_tooltip__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45197);
/* harmony import */ var _context_use_filters_context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57165);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(38546);
/* harmony import */ var _filter_search_bar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(35608);
/* harmony import */ var _issue_issue_status_count__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(14389);











const EpicFilter = ()=>{
    const { epics, setEpics } = (0,_context_use_filters_context__WEBPACK_IMPORTED_MODULE_4__/* .useFiltersContext */ .P)();
    const { issues } = (0,_hooks_query_hooks_use_issues__WEBPACK_IMPORTED_MODULE_2__/* .useIssues */ .g)();
    const [search, setSearch] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("");
    function searchFilter(issue) {
        return (0,_utils_helpers__WEBPACK_IMPORTED_MODULE_9__/* .isEpic */ .pQ)(issue) && issue.name.toLowerCase().includes(search.toLowerCase());
    }
    function onSelectChange(e, issue) {
        if (e.target.checked) {
            setEpics((prev)=>[
                    ...prev,
                    issue.id
                ]);
        } else {
            setEpics((prev)=>prev.filter((id)=>id !== issue.id));
        }
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__/* .Dropdown */ .Lt, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__/* .DropdownTrigger */ .WA, {
                className: "rounded-[3px] [&[data-state=open]]:bg-gray-700 [&[data-state=open]]:text-white",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_button__WEBPACK_IMPORTED_MODULE_6__/* .Button */ .z, {
                    customColors: true,
                    className: "flex items-center gap-x-2 transition-all duration-200 hover:bg-gray-200",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-sm",
                            children: "Epic"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_issue_issue_status_count__WEBPACK_IMPORTED_MODULE_8__/* .CountBall */ .N, {
                            count: epics.length,
                            className: "bg-inprogress text-xs text-white",
                            hideOnZero: true
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_10__/* .FaChevronDown */ .RiI, {
                            className: "text-xs"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__/* .DropdownPortal */ .nI, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__/* .DropdownContent */ .Nv, {
                    side: "bottom",
                    align: "start",
                    className: "z-10 mt-2 w-64 rounded-[3px] border-[0.3px] bg-white pb-2 shadow-md",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full p-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_filter_search_bar__WEBPACK_IMPORTED_MODULE_7__/* .SearchBar */ .E, {
                                placeholder: "Search epics...",
                                fullWidth: true,
                                search: search,
                                setSearch: setSearch
                            })
                        }),
                        issues?.filter(searchFilter).map((issue)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__/* .DropdownItem */ .hP, {
                                onSelect: (e)=>e.preventDefault(),
                                className: "px-3 py-1.5 text-sm hover:bg-gray-100",
                                onChange: (e)=>onSelectChange(e, issue),
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center gap-x-2 hover:cursor-default",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            htmlFor: "epic-filter",
                                            className: "sr-only",
                                            children: "Epic filter checkbox"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "checkbox",
                                            id: "epic-filter",
                                            className: "form-checkbox h-3 w-3 rounded-sm text-inprogress",
                                            checked: epics.includes(issue.id)
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_tooltip__WEBPACK_IMPORTED_MODULE_3__/* .TooltipWrapper */ .pf, {
                                            text: issue.name,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-sm text-gray-700",
                                                children: issue.name
                                            })
                                        })
                                    ]
                                })
                            }, issue.id)),
                        issues?.filter(searchFilter).length === 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "py-4 text-center text-sm text-gray-500",
                            children: "No epics found"
                        })
                    ]
                })
            })
        ]
    });
};



/***/ }),

/***/ 55403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   B: () => (/* binding */ ClearFilters)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _context_use_filters_context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57165);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(38546);



const ClearFilters = ()=>{
    const { issueTypes, setIssueTypes, assignees, setAssignees, epics, setEpics, search, setSearch, sprints, setSprints } = (0,_context_use_filters_context__WEBPACK_IMPORTED_MODULE_1__/* .useFiltersContext */ .P)();
    function clearAllFilters() {
        setIssueTypes([]);
        setAssignees([]);
        setEpics([]);
        setSprints([]);
        setSearch("");
    }
    if (issueTypes.length === 0 && assignees.length === 0 && epics.length === 0 && sprints.length === 0 && search === "") {
        return null;
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .z, {
        customColors: true,
        onClick: clearAllFilters,
        className: "text-sm hover:bg-gray-200",
        children: "Clear Filters"
    });
};



/***/ }),

/***/ 36665:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   k: () => (/* binding */ IssueTypeFilter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(41772);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(16775);
/* harmony import */ var _utils_helpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(89602);
/* harmony import */ var _components_ui_tooltip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45197);
/* harmony import */ var _components_issue_issue_select_type__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8854);
/* harmony import */ var _components_issue_issue_icon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(27603);
/* harmony import */ var _context_use_filters_context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57165);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(38546);
/* harmony import */ var _issue_issue_status_count__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(14389);










const IssueTypeFilter = ()=>{
    const { issueTypes, setIssueTypes } = (0,_context_use_filters_context__WEBPACK_IMPORTED_MODULE_5__/* .useFiltersContext */ .P)();
    function onSelectChange(e, issueType) {
        if (e.target.checked) {
            setIssueTypes((prev)=>[
                    ...prev,
                    issueType
                ]);
        } else {
            setIssueTypes((prev)=>prev.filter((type)=>type !== issueType));
        }
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__/* .Dropdown */ .Lt, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__/* .DropdownTrigger */ .WA, {
                className: "rounded-[3px] [&[data-state=open]]:bg-gray-700 [&[data-state=open]]:text-white",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_button__WEBPACK_IMPORTED_MODULE_6__/* .Button */ .z, {
                    customColors: true,
                    className: "flex items-center  gap-x-2 transition-all duration-200 hover:bg-gray-200",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-sm",
                            children: "Type"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_issue_issue_status_count__WEBPACK_IMPORTED_MODULE_7__/* .CountBall */ .N, {
                            count: issueTypes.length,
                            className: "bg-inprogress text-xs text-white",
                            hideOnZero: true
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_8__/* .FaChevronDown */ .RiI, {
                            className: "text-xs"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__/* .DropdownPortal */ .nI, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__/* .DropdownContent */ .Nv, {
                    side: "bottom",
                    align: "start",
                    className: "z-10 mt-2 w-52 rounded-[3px] border-[0.3px] bg-white py-4 shadow-md",
                    children: _components_issue_issue_select_type__WEBPACK_IMPORTED_MODULE_3__/* .ISSUE_TYPES */ ._.map((type)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__/* .DropdownItem */ .hP, {
                            onSelect: (e)=>e.preventDefault(),
                            className: "px-3 py-1.5 text-sm hover:bg-gray-100",
                            onChange: (e)=>onSelectChange(e, type),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center gap-x-2 hover:cursor-default",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "issue-type-filter",
                                        className: "sr-only",
                                        children: "Issue type filter checkbox"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "checkbox",
                                        id: "issue-type-filter",
                                        className: "form-checkbox h-3 w-3 rounded-sm text-inprogress",
                                        checked: issueTypes.includes(type)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_issue_issue_icon__WEBPACK_IMPORTED_MODULE_4__/* .IssueIcon */ .u, {
                                        issueType: type
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_tooltip__WEBPACK_IMPORTED_MODULE_2__/* .TooltipWrapper */ .pf, {
                                        text: (0,_utils_helpers__WEBPACK_IMPORTED_MODULE_9__/* .capitalize */ .kC)(type),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "text-sm text-gray-700",
                                            children: (0,_utils_helpers__WEBPACK_IMPORTED_MODULE_9__/* .capitalize */ .kC)(type)
                                        })
                                    })
                                ]
                            })
                        }, type))
                })
            })
        ]
    });
};



/***/ }),

/***/ 35608:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  E: () => (/* binding */ SearchBar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
;// CONCATENATED MODULE: ./hooks/use-focus.ts
/* __next_internal_client_entry_do_not_use__ useFocus auto */ 
const useFocus = ()=>{
    const inputRef = (0,react_.useRef)(null);
    const [isFocused, setIsFocused] = (0,react_.useState)(false);
    (0,react_.useEffect)(()=>{
        const handleFocus = ()=>{
            setIsFocused(true);
        };
        const handleBlur = ()=>{
            setIsFocused(false);
        };
        const inputElement = inputRef.current;
        if (inputElement) {
            inputElement.addEventListener("focus", handleFocus);
            inputElement.addEventListener("blur", handleBlur);
        }
        return ()=>{
            if (inputElement) {
                inputElement.removeEventListener("focus", handleFocus);
                inputElement.removeEventListener("blur", handleBlur);
            }
        };
    }, []);
    return [
        inputRef,
        isFocused
    ];
};

// EXTERNAL MODULE: ./node_modules/react-icons/md/index.esm.js
var index_esm = __webpack_require__(64348);
// EXTERNAL MODULE: ./node_modules/lodash.debounce/index.js
var lodash_debounce = __webpack_require__(61043);
var lodash_debounce_default = /*#__PURE__*/__webpack_require__.n(lodash_debounce);
// EXTERNAL MODULE: ./node_modules/react-icons/bs/index.esm.js
var bs_index_esm = __webpack_require__(75484);
// EXTERNAL MODULE: ./node_modules/clsx/dist/clsx.js
var clsx = __webpack_require__(14889);
var clsx_default = /*#__PURE__*/__webpack_require__.n(clsx);
;// CONCATENATED MODULE: ./components/filter-search-bar.tsx







const SearchBar = ({ search, setSearch, fullWidth, placeholder })=>{
    const [ref, isFocused] = useFocus();
    const [localSearch, setLocalSearch] = (0,react_.useState)(search);
    const debouncedSetSearch = (0,react_.useMemo)(()=>lodash_debounce_default()((str)=>setSearch(str), 350), [
        setSearch
    ]);
    function handleSearch(e) {
        setLocalSearch(e.target.value);
        debouncedSetSearch(e.target.value);
    }
    function handleClearSearch() {
        setLocalSearch("");
        setSearch("");
    }
    (0,react_.useEffect)(()=>{
        return ()=>{
            debouncedSetSearch.cancel();
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: clsx_default()(fullWidth ? "w-full" : "w-fit", "relative flex items-center"),
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                htmlFor: "issue-search",
                className: "sr-only",
                children: "Issue search filter"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                type: "text",
                id: "issue-search",
                ref: ref,
                "data-state": isFocused ? "focused" : "not-focused",
                className: clsx_default()(fullWidth ? " w-full min-w-max" : "[&[data-state=focused]]:pr-8", "inset-2 h-full rounded-sm border-2 border-gray-300 bg-gray-50 px-2 py-2 text-sm outline-blue-400 transition-all duration-300 hover:bg-gray-200 focus:bg-white focus:outline-2  [&[data-state=focused]]:placeholder:text-gray-500 [&[data-state=not-focused]]:placeholder:text-transparent"),
                value: localSearch,
                onChange: handleSearch,
                placeholder: placeholder ?? "Search backlog"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* MdSearch */.vU7, {
                "data-state": search.length ? "searching" : "not-searching",
                className: "absolute bottom-0 right-0 top-0 mx-2 flex h-full items-center text-lg text-gray-500 [&[data-state=searching]]:hidden"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                "data-state": search.length ? "searching" : "not-searching",
                onClick: handleClearSearch,
                className: "[&[data-state=not-searching]]:hidden",
                children: /*#__PURE__*/ jsx_runtime_.jsx(bs_index_esm/* BsX */.z3f, {
                    className: "absolute bottom-0 right-0 top-0 mx-2 flex h-full items-center text-lg text-gray-500 "
                })
            })
        ]
    });
};



/***/ }),

/***/ 37151:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  G: () => (/* binding */ IssueDetails)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./hooks/query-hooks/use-issues/index.ts + 4 modules
var use_issues = __webpack_require__(14184);
;// CONCATENATED MODULE: ./hooks/use-is-in-viewport.ts
/* __next_internal_client_entry_do_not_use__ useIsInViewport auto */ 
const useIsInViewport = (options = {})=>{
    const { threshold = 0 } = options;
    const [isInViewport, setIsInViewport] = (0,react_.useState)(false);
    const ref = (0,react_.useRef)(null);
    (0,react_.useEffect)(()=>{
        const element = ref.current;
        if (!element) return;
        const observer = new IntersectionObserver(([entry])=>{
            if (entry) {
                setIsInViewport(entry.isIntersecting);
            }
        }, {
            threshold: threshold
        });
        observer.observe(element);
        return ()=>{
            observer.unobserve(element);
        };
    }, [
        threshold
    ]);
    return [
        isInViewport,
        ref
    ];
};

// EXTERNAL MODULE: ./node_modules/react-icons/md/index.esm.js
var index_esm = __webpack_require__(64348);
// EXTERNAL MODULE: ./node_modules/react-icons/ai/index.esm.js
var ai_index_esm = __webpack_require__(19722);
// EXTERNAL MODULE: ./components/issue/issue-menu.tsx
var issue_menu = __webpack_require__(38620);
// EXTERNAL MODULE: ./components/ui/dropdown-menu.tsx
var dropdown_menu = __webpack_require__(41772);
// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(38546);
// EXTERNAL MODULE: ./components/issue/issue-select-type.tsx
var issue_select_type = __webpack_require__(8854);
// EXTERNAL MODULE: ./node_modules/clsx/dist/clsx.js
var clsx = __webpack_require__(14889);
var clsx_default = /*#__PURE__*/__webpack_require__.n(clsx);
// EXTERNAL MODULE: ./components/issue/issue-icon.tsx
var issue_icon = __webpack_require__(27603);
// EXTERNAL MODULE: ./utils/helpers.ts
var helpers = __webpack_require__(89602);
// EXTERNAL MODULE: ./components/ui/select.tsx
var ui_select = __webpack_require__(13785);
// EXTERNAL MODULE: ./components/ui/tooltip.tsx
var tooltip = __webpack_require__(45197);
// EXTERNAL MODULE: ./hooks/use-is-authed.ts
var use_is_authed = __webpack_require__(30660);
;// CONCATENATED MODULE: ./components/issue/issue-select-epic.tsx









const IssueSelectEpic = ({ issue, children, className })=>{
    const { issues, updateIssue } = (0,use_issues/* useIssues */.g)();
    const [selected, setSelected] = (0,react_.useState)(issue.parentId);
    const [isAuthenticated, openAuthModal] = (0,use_is_authed/* useIsAuthenticated */.k)();
    function handleSelect(id) {
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        updateIssue({
            issueId: issue.id,
            parentId: id
        });
        setSelected(id);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_select/* Select */.Ph, {
        onValueChange: handleSelect,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(tooltip/* TooltipWrapper */.pf, {
                text: `Epic - ${selected ? "Change" : "Add"} epic`,
                side: "top",
                children: /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectTrigger */.i4, {
                    onClick: (e)=>e.stopPropagation(),
                    className: "flex items-center gap-x-1 rounded-[3px] p-1.5 text-xs font-semibold text-white hover:bg-gray-200 focus:ring-2",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectValue */.ki, {
                        defaultValue: selected ?? undefined,
                        className: className,
                        children: children
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectPortal */.ue, {
                className: "z-50",
                children: /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectContent */.Bw, {
                    position: "popper",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_select/* SelectViewport */.Q_, {
                        className: "min-w-60 rounded-md border border-gray-300 bg-white pt-2 shadow-md",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "pl-3 text-xs text-gray-500",
                                children: "EPICS"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectGroup */.DI, {
                                children: issues?.filter((issue)=>(0,helpers/* isEpic */.pQ)(issue)).map((issue)=>/*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectItem */.Ql, {
                                        value: issue.id,
                                        className: clsx_default()("border-l-[3px] border-transparent py-2 pl-3 text-sm hover:cursor-pointer  hover:bg-gray-50 [&[data-state=checked]]:bg-gray-200"),
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(issue_icon/* IssueIcon */.u, {
                                                    issueType: issue.type
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "rounded-md bg-opacity-30 px-4 text-sm",
                                                    children: issue.name
                                                })
                                            ]
                                        })
                                    }, issue.id))
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectSeparator */.U$, {
                                className: "mt-2 h-[1px] bg-gray-300"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                onClick: ()=>handleSelect(null),
                                className: "w-full py-3 pl-4 text-left text-sm text-gray-500 hover:bg-gray-100",
                                children: "Unlink parent"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "w-full py-3 pl-4 text-left text-sm text-gray-500 hover:bg-gray-100",
                                children: "View all epics"
                            })
                        ]
                    })
                })
            })
        ]
    });
};


// EXTERNAL MODULE: ./components/toast.tsx
var toast = __webpack_require__(34825);
;// CONCATENATED MODULE: ./components/issue/issue-path.tsx
/* __next_internal_client_entry_do_not_use__ IssuePath auto */ 










const IssuePath = ({ issue, setIssueKey })=>{
    if ((0,helpers/* isEpic */.pQ)(issue)) return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(issue_icon/* IssueIcon */.u, {
                issueType: issue.type
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(tooltip/* TooltipWrapper */.pf, {
                text: `${issue.key}: ${issue.name}`,
                side: "top",
                children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                    onClick: ()=>setIssueKey(issue.key),
                    customColors: true,
                    className: " bg-transparent text-xs text-gray-500 underline-offset-2 hover:underline",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "whitespace-nowrap",
                        children: issue.key
                    })
                })
            })
        ]
    });
    if (issue.parent && (0,helpers/* isEpic */.pQ)(issue.parent)) return /*#__PURE__*/ jsx_runtime_.jsx(ParentContainer, {
        issue: issue,
        setIssueKey: setIssueKey,
        children: /*#__PURE__*/ jsx_runtime_.jsx(IssueSelectEpic, {
            issue: issue,
            children: /*#__PURE__*/ jsx_runtime_.jsx(issue_icon/* IssueIcon */.u, {
                issueType: issue.parent.type
            })
        }, issue.id)
    });
    if (issue.parent) return /*#__PURE__*/ jsx_runtime_.jsx(ParentContainer, {
        issue: issue,
        setIssueKey: setIssueKey,
        children: /*#__PURE__*/ jsx_runtime_.jsx(issue_icon/* IssueIcon */.u, {
            issueType: issue.parent.type
        })
    });
    return /*#__PURE__*/ jsx_runtime_.jsx(ParentContainer, {
        issue: issue,
        setIssueKey: setIssueKey,
        children: /*#__PURE__*/ jsx_runtime_.jsx(IssueSelectEpic, {
            issue: issue,
            children: /*#__PURE__*/ jsx_runtime_.jsx(AddEpic, {})
        })
    });
};
const ParentContainer = ({ children, issue, setIssueKey })=>{
    const { updateIssue } = (0,use_issues/* useIssues */.g)();
    const [isAuthenticated, openAuthModal] = (0,use_is_authed/* useIsAuthenticated */.k)();
    function handleSelectType(type) {
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        updateIssue({
            issueId: issue.id,
            type
        }, {
            onSuccess: (data)=>{
                toast.toast.success({
                    message: `Issue type updated to ${data.type}`,
                    description: "Issue type changed"
                });
            }
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex gap-x-3",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center",
                children: [
                    children,
                    /*#__PURE__*/ jsx_runtime_.jsx(IssueLink, {
                        issue: issue.parent,
                        setIssueKey: setIssueKey
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "py-1.5 text-gray-500",
                children: "/"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative flex items-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(issue_select_type/* IssueSelectType */.o, {
                        currentType: issue.type,
                        onSelect: handleSelectType
                    }, issue.id + issue.type),
                    /*#__PURE__*/ jsx_runtime_.jsx(tooltip/* TooltipWrapper */.pf, {
                        text: `${issue.key}: ${issue.name}`,
                        side: "top",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(IssueLink, {
                            issue: issue,
                            setIssueKey: setIssueKey
                        })
                    })
                ]
            })
        ]
    });
};
const IssueLink = ({ issue, setIssueKey })=>{
    if (!issue) return /*#__PURE__*/ jsx_runtime_.jsx("div", {});
    return /*#__PURE__*/ jsx_runtime_.jsx(tooltip/* TooltipWrapper */.pf, {
        text: `${issue.key}: ${issue.name}`,
        side: "top",
        children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
            onClick: ()=>setIssueKey(issue?.key ?? null),
            customColors: true,
            className: " bg-transparent text-xs text-gray-500 underline-offset-2 hover:underline",
            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "whitespace-nowrap",
                children: issue?.key
            })
        })
    });
};
const AddEpic = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center font-normal text-gray-500",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ai_index_esm/* AiOutlinePlus */.Lfi, {
                className: "text-sm"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                children: "Add Epic"
            })
        ]
    });
};


// EXTERNAL MODULE: ./components/not-implemented.tsx + 1 modules
var not_implemented = __webpack_require__(14782);
// EXTERNAL MODULE: ./node_modules/react-icons/bs/index.esm.js
var bs_index_esm = __webpack_require__(75484);
;// CONCATENATED MODULE: ./components/issue/issue-details/issue-details-header.tsx









const IssueDetailsHeader = ({ issue, setIssueKey, isInViewport })=>{
    if (!issue) return /*#__PURE__*/ jsx_runtime_.jsx("div", {});
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        "data-state": isInViewport ? "inViewport" : "notInViewport",
        className: "sticky top-0 z-10 flex h-fit w-full items-center justify-between border-b-2 border-transparent bg-white p-0.5 [&[data-state=notInViewport]]:border-gray-200",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(IssuePath, {
                issue: issue,
                setIssueKey: setIssueKey
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative flex items-center gap-x-0.5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(not_implemented/* NotImplemented */.r, {
                        feature: "watch",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                            customColors: true,
                            className: "bg-transparent hover:bg-gray-200",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* MdRemoveRedEye */.FpO, {
                                className: "text-xl"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(not_implemented/* NotImplemented */.r, {
                        feature: "like",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                            customColors: true,
                            className: "bg-transparent hover:bg-gray-200",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ai_index_esm/* AiOutlineLike */.DZs, {
                                className: "text-xl"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(not_implemented/* NotImplemented */.r, {
                        feature: "share",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                            customColors: true,
                            className: "bg-transparent hover:bg-gray-200",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* MdOutlineShare */.Npg, {
                                className: "text-xl"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(issue_menu/* IssueDropdownMenu */.U, {
                        issue: issue,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu/* DropdownTrigger */.WA, {
                            asChild: true,
                            className: "rounded-m flex items-center gap-x-1 bg-opacity-30 p-2 text-xs font-semibold focus:ring-2 [&[data-state=open]]:bg-gray-700 [&[data-state=open]]:text-white",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "rounded-[3px] text-gray-800 hover:bg-gray-200",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(bs_index_esm/* BsThreeDots */.evw, {
                                    className: "sm:text-xl"
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                        customColors: true,
                        className: "bg-transparent hover:bg-gray-200",
                        onClick: ()=>setIssueKey(null),
                        children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* MdClose */.FU5, {
                            className: "text-2xl"
                        })
                    })
                ]
            })
        ]
    });
};


// EXTERNAL MODULE: ./components/svgs.tsx
var svgs = __webpack_require__(16206);
// EXTERNAL MODULE: ./components/issue/issue-title.tsx
var issue_title = __webpack_require__(38698);
// EXTERNAL MODULE: ./components/issue/issue-select-status.tsx
var issue_select_status = __webpack_require__(61803);
// EXTERNAL MODULE: ./context/use-selected-issue-context.tsx
var use_selected_issue_context = __webpack_require__(90779);
// EXTERNAL MODULE: ./utils/api/index.ts + 3 modules
var api = __webpack_require__(27932);
// EXTERNAL MODULE: ./node_modules/@tanstack/react-query/build/lib/QueryClientProvider.mjs
var QueryClientProvider = __webpack_require__(98417);
// EXTERNAL MODULE: ./node_modules/@tanstack/react-query/build/lib/useQuery.mjs
var useQuery = __webpack_require__(19329);
// EXTERNAL MODULE: ./node_modules/@tanstack/react-query/build/lib/useMutation.mjs + 1 modules
var useMutation = __webpack_require__(33369);
;// CONCATENATED MODULE: ./hooks/query-hooks/use-issue-details.ts
/* __next_internal_client_entry_do_not_use__ useIssueDetails auto */ 





const useIssueDetails = ()=>{
    const { issueKey } = (0,use_selected_issue_context.useSelectedIssueContext)();
    const { issues } = (0,use_issues/* useIssues */.g)();
    const getIssueId = (0,react_.useCallback)((issues)=>{
        return issues?.find((issue)=>issue.key === issueKey)?.id ?? null;
    }, [
        issueKey
    ]);
    const [issueId, setIssueId] = (0,react_.useState)(()=>getIssueId(issues));
    (0,react_.useEffect)(()=>{
        setIssueId(getIssueId(issues));
    }, [
        setIssueId,
        getIssueId,
        issues
    ]);
    const queryClient = (0,QueryClientProvider.useQueryClient)();
    // GET
    const { data: comments, isLoading: commentsLoading } = (0,useQuery.useQuery)([
        "issues",
        "comments",
        issueId
    ], ()=>api/* api */.h.issues.getIssueComments({
            issueId: issueId ?? ""
        }), {
        enabled: !!issueId,
        refetchOnMount: false
    });
    // POST
    const { mutate: addComment, isLoading: isAddingComment } = (0,useMutation.useMutation)(api/* api */.h.issues.addCommentToIssue, {
        onSuccess: ()=>{
            // eslint-disable-next-line @typescript-eslint/no-floating-promises
            queryClient.invalidateQueries([
                "issues",
                "comments",
                issueId
            ]);
        },
        onError: (err)=>{
            if (err?.response?.data == "Too many requests") {
                toast.toast.error(use_issues/* TOO_MANY_REQUESTS */.Z);
                return;
            }
            toast.toast.error({
                message: `Something went wrong while creating comment`,
                description: "Please try again later."
            });
        }
    });
    const { mutate: updateComment, isLoading: commentUpdating } = (0,useMutation.useMutation)(api/* api */.h.issues.updateIssueComment, {
        onMutate: async (newComment)=>{
            // Cancel any outgoing refetches (so they don't overwrite our optimistic update)
            await queryClient.cancelQueries([
                "issues",
                "comments",
                issueId
            ]);
            // Snapshot the previous value
            const previousComments = queryClient.getQueryData([
                "issues",
                "comments",
                issueId
            ]);
            // Optimistically update the comment
            queryClient.setQueryData([
                "issues",
                "comments",
                issueId
            ], (old)=>{
                const newComments = (old ?? []).map((comment)=>{
                    const { content } = newComment;
                    if (comment.id === newComment.commentId) {
                        // Assign the new prop values to the comment
                        return {
                            ...comment,
                            content
                        };
                    }
                    return comment;
                });
                return newComments;
            });
            // Return a context object with the snapshotted value
            return {
                previousComments
            };
        },
        onError: (err, newIssue, context)=>{
            // If the mutation fails, use the context returned from onMutate to roll back
            queryClient.setQueryData([
                "issues",
                "comments",
                issueId
            ], context?.previousComments);
            if (err?.response?.data == "Too many requests") {
                toast.toast.error(use_issues/* TOO_MANY_REQUESTS */.Z);
                return;
            }
            toast.toast.error({
                message: `Something went wrong while updating comment`,
                description: "Please try again later."
            });
        },
        onSettled: ()=>{
            // Always refetch after error or success
            // eslint-disable-next-line @typescript-eslint/no-floating-promises
            queryClient.invalidateQueries([
                "issues",
                "comments",
                issueId
            ]);
        }
    });
    return {
        comments,
        commentsLoading,
        addComment,
        isAddingComment,
        updateComment,
        commentUpdating
    };
};

// EXTERNAL MODULE: ./node_modules/@lexical/react/LexicalErrorBoundary.js
var LexicalErrorBoundary = __webpack_require__(67787);
var LexicalErrorBoundary_default = /*#__PURE__*/__webpack_require__.n(LexicalErrorBoundary);
// EXTERNAL MODULE: ./node_modules/@lexical/react/LexicalRichTextPlugin.js
var LexicalRichTextPlugin = __webpack_require__(76894);
// EXTERNAL MODULE: ./node_modules/@lexical/react/LexicalContentEditable.js
var LexicalContentEditable = __webpack_require__(9067);
// EXTERNAL MODULE: ./node_modules/@lexical/react/LexicalOnChangePlugin.js
var LexicalOnChangePlugin = __webpack_require__(20976);
// EXTERNAL MODULE: ./node_modules/@lexical/react/LexicalHistoryPlugin.js
var LexicalHistoryPlugin = __webpack_require__(55951);
// EXTERNAL MODULE: ./node_modules/@lexical/react/LexicalListPlugin.js
var LexicalListPlugin = __webpack_require__(69812);
// EXTERNAL MODULE: ./node_modules/@lexical/react/LexicalAutoFocusPlugin.js
var LexicalAutoFocusPlugin = __webpack_require__(13530);
// EXTERNAL MODULE: ./node_modules/@lexical/code/LexicalCode.js
var LexicalCode = __webpack_require__(71773);
// EXTERNAL MODULE: ./node_modules/@lexical/list/LexicalList.js
var LexicalList = __webpack_require__(9036);
// EXTERNAL MODULE: ./node_modules/@lexical/react/LexicalComposerContext.js
var LexicalComposerContext = __webpack_require__(41162);
// EXTERNAL MODULE: ./node_modules/@lexical/rich-text/LexicalRichText.js
var LexicalRichText = __webpack_require__(99390);
// EXTERNAL MODULE: ./node_modules/@lexical/selection/LexicalSelection.js
var LexicalSelection = __webpack_require__(10797);
// EXTERNAL MODULE: ./node_modules/@lexical/utils/LexicalUtils.js
var LexicalUtils = __webpack_require__(37981);
// EXTERNAL MODULE: ./node_modules/lexical/Lexical.js
var Lexical = __webpack_require__(92572);
// EXTERNAL MODULE: ./node_modules/react-icons/fa/index.esm.js
var fa_index_esm = __webpack_require__(16775);
;// CONCATENATED MODULE: ./components/text-editor/ui/dropdown.tsx
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ 


// import { createPortal } from "react-dom";

const DropDownContext = /*#__PURE__*/ react_.createContext(null);
function DropDownItem({ children, onClick, title }) {
    const ref = (0,react_.useRef)(null);
    const dropDownContext = react_.useContext(DropDownContext);
    if (dropDownContext === null) {
        throw new Error("DropDownItem must be used within a DropDown");
    }
    const { registerItem } = dropDownContext;
    (0,react_.useEffect)(()=>{
        if (ref && ref.current) {
            registerItem(ref);
        }
    }, [
        ref,
        registerItem
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
        className: "flex items-center gap-x-2 whitespace-nowrap rounded-[3px] px-2 py-0.5 text-start text-sm hover:bg-gray-200",
        onClick: onClick,
        ref: ref,
        title: title,
        type: "button",
        children: children
    });
}
function DropDownItems({ children, dropDownRef, onClose }) {
    const [items, setItems] = (0,react_.useState)();
    const [highlightedItem, setHighlightedItem] = (0,react_.useState)();
    const registerItem = (0,react_.useCallback)((itemRef)=>{
        setItems((prev)=>prev ? [
                ...prev,
                itemRef
            ] : [
                itemRef
            ]);
    }, [
        setItems
    ]);
    const handleKeyDown = (event)=>{
        if (!items) return;
        const key = event.key;
        if ([
            "Escape",
            "ArrowUp",
            "ArrowDown",
            "Tab"
        ].includes(key)) {
            event.preventDefault();
        }
        if (key === "Escape" || key === "Tab") {
            onClose();
        } else if (key === "ArrowUp") {
            setHighlightedItem((prev)=>{
                if (!prev) return items[0];
                const index = items.indexOf(prev) - 1;
                return items[index === -1 ? items.length - 1 : index];
            });
        } else if (key === "ArrowDown") {
            setHighlightedItem((prev)=>{
                if (!prev) return items[0];
                return items[items.indexOf(prev) + 1];
            });
        }
    };
    const contextValue = (0,react_.useMemo)(()=>({
            registerItem
        }), [
        registerItem
    ]);
    (0,react_.useEffect)(()=>{
        if (items && !highlightedItem) {
            setHighlightedItem(items[0]);
        }
        if (highlightedItem && highlightedItem.current) {
            highlightedItem.current.focus();
        }
    }, [
        items,
        highlightedItem
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(DropDownContext.Provider, {
        value: contextValue,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "z-50 flex flex-col rounded-[3px] bg-white  p-1.5 shadow-md",
            ref: dropDownRef,
            onKeyDown: handleKeyDown,
            children: children
        })
    });
}
function DropDown({ disabled = false, buttonLabel, buttonAriaLabel, children, stopCloseOnClickSelf }) {
    const dropDownRef = (0,react_.useRef)(null);
    const buttonRef = (0,react_.useRef)(null);
    const [showDropDown, setShowDropDown] = (0,react_.useState)(false);
    const handleClose = ()=>{
        setShowDropDown(false);
        if (buttonRef && buttonRef.current) {
            buttonRef.current.focus();
        }
    };
    (0,react_.useEffect)(()=>{
        const button = buttonRef.current;
        const dropDown = dropDownRef.current;
        if (showDropDown && button !== null && dropDown !== null) {
            const { top, left } = button.getBoundingClientRect();
            dropDown.style.top = `${top + 40}px`;
            dropDown.style.left = `${Math.min(left, window.innerWidth - dropDown.offsetWidth - 20)}px`;
        }
    }, [
        dropDownRef,
        buttonRef,
        showDropDown
    ]);
    (0,react_.useEffect)(()=>{
        const button = buttonRef.current;
        if (button !== null && showDropDown) {
            const handle = (event)=>{
                const target = event.target;
                if (stopCloseOnClickSelf) {
                    if (dropDownRef.current && dropDownRef.current.contains(target)) return;
                }
                if (!button.contains(target)) {
                    setShowDropDown(false);
                }
            };
            document.addEventListener("click", handle);
            return ()=>{
                document.removeEventListener("click", handle);
            };
        }
    }, [
        dropDownRef,
        buttonRef,
        showDropDown,
        stopCloseOnClickSelf
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                disabled: disabled,
                "aria-label": buttonAriaLabel || buttonLabel,
                className: "flex items-center gap-x-1 rounded-md p-1.5 text-xs hover:bg-gray-200",
                onClick: ()=>setShowDropDown(!showDropDown),
                ref: buttonRef,
                children: [
                    buttonLabel && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "",
                        children: buttonLabel
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(fa_index_esm/* FaChevronDown */.RiI, {
                        className: "text-xs"
                    })
                ]
            }),
            showDropDown && // createPortal(
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute right-0 top-12 z-50",
                children: /*#__PURE__*/ jsx_runtime_.jsx(DropDownItems, {
                    dropDownRef: dropDownRef,
                    onClose: handleClose,
                    children: children
                })
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/react-icons/fi/index.esm.js
var fi_index_esm = __webpack_require__(17808);
// EXTERNAL MODULE: ./node_modules/react-icons/bi/index.esm.js
var bi_index_esm = __webpack_require__(85228);
;// CONCATENATED MODULE: ./components/text-editor/plugins/toolbar-plugin.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ 











const blockTypeToBlockName = {
    bullet: "Bulleted List",
    check: "Check List",
    code: "Code Block",
    h1: "Heading 1",
    h2: "Heading 2",
    h3: "Heading 3",
    h4: "Heading 4",
    h5: "Heading 5",
    h6: "Heading 6",
    number: "Numbered List",
    paragraph: "Normal",
    quote: "Quote"
};
function getCodeLanguageOptions() {
    const options = [];
    for (const [lang, friendlyName] of Object.entries(LexicalCode.CODE_LANGUAGE_FRIENDLY_NAME_MAP)){
        options.push([
            lang,
            friendlyName
        ]);
    }
    return options;
}
const CODE_LANGUAGE_OPTIONS = getCodeLanguageOptions();
const FONT_FAMILY_OPTIONS = [
    [
        "Arial",
        "Arial"
    ],
    [
        "Courier New",
        "Courier New"
    ],
    [
        "Georgia",
        "Georgia"
    ],
    [
        "Times New Roman",
        "Times New Roman"
    ],
    [
        "Trebuchet MS",
        "Trebuchet MS"
    ],
    [
        "Verdana",
        "Verdana"
    ]
];
const FONT_SIZE_OPTIONS = [
    [
        "10px",
        "10px"
    ],
    [
        "11px",
        "11px"
    ],
    [
        "12px",
        "12px"
    ],
    [
        "13px",
        "13px"
    ],
    [
        "14px",
        "14px"
    ],
    [
        "15px",
        "15px"
    ],
    [
        "16px",
        "16px"
    ],
    [
        "17px",
        "17px"
    ],
    [
        "18px",
        "18px"
    ],
    [
        "19px",
        "19px"
    ],
    [
        "20px",
        "20px"
    ],
    [
        "24px",
        "24px"
    ],
    [
        "26px",
        "26px"
    ],
    [
        "28px",
        "28px"
    ],
    [
        "30px",
        "30px"
    ],
    [
        "32px",
        "32px"
    ],
    [
        "34px",
        "34px"
    ]
];
function BlockFormatDropDown({ editor, blockType, disabled = false }) {
    const formatParagraph = ()=>{
        if (blockType !== "paragraph") {
            editor.update(()=>{
                const selection = (0,Lexical.$getSelection)();
                if ((0,Lexical.$isRangeSelection)(selection) || (0,Lexical.DEPRECATED_$isGridSelection)(selection)) // eslint-disable-next-line
                (0,LexicalSelection.$wrapNodes)(selection, ()=>(0,Lexical.$createParagraphNode)());
            });
        }
    };
    const formatHeading = (headingSize)=>{
        if (blockType !== headingSize) {
            editor.update(()=>{
                const selection = (0,Lexical.$getSelection)();
                if ((0,Lexical.$isRangeSelection)(selection) || (0,Lexical.DEPRECATED_$isGridSelection)(selection)) {
                    // eslint-disable-next-line
                    (0,LexicalSelection.$wrapNodes)(selection, ()=>(0,LexicalRichText.$createHeadingNode)(headingSize));
                }
            });
        }
    };
    const formatQuote = ()=>{
        if (blockType !== "quote") {
            editor.update(()=>{
                const selection = (0,Lexical.$getSelection)();
                if ((0,Lexical.$isRangeSelection)(selection) || (0,Lexical.DEPRECATED_$isGridSelection)(selection)) {
                    // eslint-disable-next-line
                    (0,LexicalSelection.$wrapNodes)(selection, ()=>(0,LexicalRichText.$createQuoteNode)());
                }
            });
        }
    };
    const formatCode = ()=>{
        if (blockType !== "code") {
            editor.update(()=>{
                let selection = (0,Lexical.$getSelection)();
                if ((0,Lexical.$isRangeSelection)(selection) || (0,Lexical.DEPRECATED_$isGridSelection)(selection)) {
                    if (selection.isCollapsed()) {
                        // eslint-disable-next-line
                        (0,LexicalSelection.$wrapNodes)(selection, ()=>(0,LexicalCode.$createCodeNode)());
                    } else {
                        const textContent = selection.getTextContent();
                        const codeNode = (0,LexicalCode.$createCodeNode)();
                        selection.insertNodes([
                            codeNode
                        ]);
                        selection = (0,Lexical.$getSelection)();
                        if ((0,Lexical.$isRangeSelection)(selection)) selection.insertRawText(textContent);
                    }
                }
            });
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DropDown, {
        disabled: disabled,
        buttonLabel: blockTypeToBlockName[blockType],
        buttonAriaLabel: "Formatting options for text style",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DropDownItem, {
                onClick: formatParagraph,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(bs_index_esm/* BsTextParagraph */.Zqz, {
                        className: "text-sm"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "Normal"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DropDownItem, {
                onClick: ()=>formatHeading("h1"),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(bs_index_esm/* BsTypeH1 */.Cxy, {
                        className: "text-sm"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "Heading 1"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DropDownItem, {
                onClick: ()=>formatHeading("h2"),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(bs_index_esm/* BsTypeH2 */.hH4, {
                        className: "text-sm"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "Heading 2"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DropDownItem, {
                onClick: ()=>formatHeading("h3"),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(bs_index_esm/* BsTypeH3 */.CGP, {
                        className: "text-sm"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "Heading 3"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DropDownItem, {
                onClick: formatQuote,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(bs_index_esm/* BsQuote */.aBF, {
                        className: "text-sm"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "Quote"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DropDownItem, {
                onClick: formatCode,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(bs_index_esm/* BsCodeSlash */.P_q, {
                        className: "text-sm"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "Code Block"
                    })
                ]
            })
        ]
    });
}
function Divider() {
    return /*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: "block h-full w-[1px] bg-gray-600"
    });
}
function FontDropDown({ editor, value, style, disabled = false }) {
    const handleClick = (0,react_.useCallback)((option)=>{
        editor.update(()=>{
            const selection = (0,Lexical.$getSelection)();
            if ((0,Lexical.$isRangeSelection)(selection)) {
                (0,LexicalSelection.$patchStyleText)(selection, {
                    [style]: option
                });
            }
        });
    }, [
        editor,
        style
    ]);
    const buttonAriaLabel = style === "font-family" ? "Formatting options for font family" : "Formatting options for font size";
    return /*#__PURE__*/ jsx_runtime_.jsx(DropDown, {
        disabled: disabled,
        buttonLabel: value,
        buttonAriaLabel: buttonAriaLabel,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "z-[50] flex h-[200px] flex-col overflow-y-auto",
            children: (style === "font-family" ? FONT_FAMILY_OPTIONS : FONT_SIZE_OPTIONS).map(([option, text])=>/*#__PURE__*/ jsx_runtime_.jsx(DropDownItem, {
                    onClick: ()=>handleClick(option),
                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "",
                        children: text
                    })
                }, option))
        })
    });
}
function ToolbarPlugin() {
    const [editor] = (0,LexicalComposerContext.useLexicalComposerContext)();
    const [activeEditor, setActiveEditor] = (0,react_.useState)(editor);
    const [blockType, setBlockType] = (0,react_.useState)("paragraph");
    const [selectedElementKey, setSelectedElementKey] = (0,react_.useState)(null);
    const [fontSize, setFontSize] = (0,react_.useState)("14px");
    const [isBold, setIsBold] = (0,react_.useState)(false);
    const [isItalic, setIsItalic] = (0,react_.useState)(false);
    const [isUnderline, setIsUnderline] = (0,react_.useState)(false);
    const [isStrikethrough, setIsStrikethrough] = (0,react_.useState)(false);
    const [canUndo, setCanUndo] = (0,react_.useState)(false);
    const [canRedo, setCanRedo] = (0,react_.useState)(false);
    const [codeLanguage, setCodeLanguage] = (0,react_.useState)("");
    const [isEditable, setIsEditable] = (0,react_.useState)(()=>editor.isEditable());
    const updateToolbar = (0,react_.useCallback)(()=>{
        const selection = (0,Lexical.$getSelection)();
        if ((0,Lexical.$isRangeSelection)(selection)) {
            const anchorNode = selection.anchor.getNode();
            let element = anchorNode.getKey() === "root" ? anchorNode : (0,LexicalUtils.$findMatchingParent)(anchorNode, (e)=>{
                const parent = e.getParent();
                return parent !== null && (0,Lexical.$isRootOrShadowRoot)(parent);
            });
            if (element === null) {
                element = anchorNode.getTopLevelElementOrThrow();
            }
            const elementKey = element.getKey();
            const elementDOM = activeEditor.getElementByKey(elementKey);
            setIsBold(selection.hasFormat("bold"));
            setIsItalic(selection.hasFormat("italic"));
            setIsUnderline(selection.hasFormat("underline"));
            setIsStrikethrough(selection.hasFormat("strikethrough"));
            if (elementDOM !== null) {
                setSelectedElementKey(elementKey);
                if ((0,LexicalList.$isListNode)(element)) {
                    const parentList = (0,LexicalUtils.$getNearestNodeOfType)(anchorNode, LexicalList.ListNode);
                    const type = parentList ? parentList.getListType() : element.getListType();
                    setBlockType(type);
                } else {
                    const type = (0,LexicalRichText.$isHeadingNode)(element) ? element.getTag() : element.getType();
                    if (type in blockTypeToBlockName) {
                        setBlockType(type);
                    }
                    if ((0,LexicalCode.$isCodeNode)(element)) {
                        const language = element.getLanguage();
                        setCodeLanguage(language ? LexicalCode.CODE_LANGUAGE_MAP[language] || language : "");
                        return;
                    }
                }
            }
            setFontSize((0,LexicalSelection.$getSelectionStyleValueForProperty)(selection, "font-size", "14px"));
        }
    }, [
        activeEditor
    ]);
    (0,react_.useEffect)(()=>{
        return editor.registerCommand(Lexical.SELECTION_CHANGE_COMMAND, (_payload, newEditor)=>{
            updateToolbar();
            setActiveEditor(newEditor);
            return false;
        }, Lexical.COMMAND_PRIORITY_CRITICAL);
    }, [
        editor,
        updateToolbar
    ]);
    (0,react_.useEffect)(()=>{
        return (0,LexicalUtils.mergeRegister)(editor.registerEditableListener((editable)=>{
            setIsEditable(editable);
        }), activeEditor.registerUpdateListener(({ editorState })=>{
            editorState.read(()=>{
                updateToolbar();
            });
        }), activeEditor.registerCommand(Lexical.CAN_UNDO_COMMAND, (payload)=>{
            setCanUndo(payload);
            return false;
        }, Lexical.COMMAND_PRIORITY_CRITICAL), activeEditor.registerCommand(Lexical.CAN_REDO_COMMAND, (payload)=>{
            setCanRedo(payload);
            return false;
        }, Lexical.COMMAND_PRIORITY_CRITICAL));
    }, [
        activeEditor,
        editor,
        updateToolbar
    ]);
    const onCodeLanguageSelect = (0,react_.useCallback)((value)=>{
        activeEditor.update(()=>{
            if (selectedElementKey !== null) {
                const node = (0,Lexical.$getNodeByKey)(selectedElementKey);
                if ((0,LexicalCode.$isCodeNode)(node)) {
                    node.setLanguage(value);
                }
            }
        });
    }, [
        activeEditor,
        selectedElementKey
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative flex items-center justify-between border-b bg-white p-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                disabled: !canUndo || !isEditable,
                onClick: ()=>{
                    activeEditor.dispatchCommand(Lexical.UNDO_COMMAND, undefined);
                },
                title: "Undo (⌘Z)",
                type: "button",
                className: "rounded-md p-1.5 hover:bg-gray-200",
                "aria-label": "Undo",
                children: /*#__PURE__*/ jsx_runtime_.jsx(fi_index_esm/* FiRotateCcw */.bxQ, {
                    className: "text-sm"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                disabled: !canRedo || !isEditable,
                onClick: ()=>{
                    activeEditor.dispatchCommand(Lexical.REDO_COMMAND, undefined);
                },
                title: "Redo (⌘Y)",
                type: "button",
                className: "rounded-md p-1.5 hover:bg-gray-200",
                "aria-label": "Redo",
                children: /*#__PURE__*/ jsx_runtime_.jsx(fi_index_esm/* FiRotateCw */.kV7, {
                    className: "text-sm"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Divider, {}),
            blockType in blockTypeToBlockName && activeEditor === editor && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(BlockFormatDropDown, {
                        disabled: !isEditable,
                        blockType: blockType,
                        editor: editor
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Divider, {})
                ]
            }),
            blockType === "code" ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(DropDown, {
                    disabled: !isEditable,
                    buttonLabel: (0,LexicalCode.getLanguageFriendlyName)(codeLanguage),
                    buttonAriaLabel: "Select language",
                    children: CODE_LANGUAGE_OPTIONS.map(([value, name])=>{
                        return /*#__PURE__*/ jsx_runtime_.jsx(DropDownItem, {
                            onClick: ()=>onCodeLanguageSelect(value),
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: name
                            })
                        }, value);
                    })
                })
            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(FontDropDown, {
                        disabled: !isEditable,
                        style: "font-size",
                        value: fontSize,
                        editor: editor
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Divider, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        disabled: !isEditable,
                        onClick: ()=>{
                            activeEditor.dispatchCommand(Lexical.FORMAT_TEXT_COMMAND, "bold");
                        },
                        className: "rounded-md p-1.5 " + (isBold ? "bg-gray-200" : ""),
                        title: "Bold (⌘B)",
                        type: "button",
                        "aria-label": "Format text as bold. Shortcut: ⌘B",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(bs_index_esm/* BsTypeBold */.n5T, {
                            className: "text-base"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        disabled: !isEditable,
                        onClick: ()=>{
                            activeEditor.dispatchCommand(Lexical.FORMAT_TEXT_COMMAND, "italic");
                        },
                        className: "rounded-md p-1.5 " + (isItalic ? "bg-gray-200" : ""),
                        title: "Italic (⌘I)",
                        type: "button",
                        "aria-label": "Format text as italics. Shortcut: ⌘I",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(bs_index_esm/* BsTypeItalic */.XJX, {
                            className: "text-base"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        disabled: !isEditable,
                        onClick: ()=>{
                            activeEditor.dispatchCommand(Lexical.FORMAT_TEXT_COMMAND, "underline");
                        },
                        className: "rounded-md p-1.5 " + (isUnderline ? "bg-gray-200" : ""),
                        title: "Underline (⌘U)",
                        type: "button",
                        "aria-label": "Format text as underline. Shortcut: ⌘U",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(bs_index_esm/* BsTypeUnderline */.rl2, {
                            className: "text-base"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        disabled: !isEditable,
                        onClick: ()=>{
                            activeEditor.dispatchCommand(Lexical.FORMAT_TEXT_COMMAND, "strikethrough");
                        },
                        className: "rounded-md p-1.5 " + (isStrikethrough ? "bg-gray-200" : ""),
                        title: "Strikethrough (⌘K)",
                        type: "button",
                        "aria-label": "Format text as italics. Shortcut: ⌘K",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(bs_index_esm/* BsTypeStrikethrough */.Q$W, {
                            className: "text-base"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Divider, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DropDown, {
                disabled: !isEditable,
                buttonLabel: "Align",
                buttonAriaLabel: "Formatting options for text alignment",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DropDownItem, {
                        onClick: ()=>{
                            activeEditor.dispatchCommand(Lexical.FORMAT_ELEMENT_COMMAND, "left");
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(fi_index_esm/* FiAlignLeft */.SwK, {
                                className: "text-sm"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Left Align"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DropDownItem, {
                        onClick: ()=>{
                            activeEditor.dispatchCommand(Lexical.FORMAT_ELEMENT_COMMAND, "center");
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(fi_index_esm/* FiAlignCenter */.cov, {
                                className: "text-sm"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Center Align"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DropDownItem, {
                        onClick: ()=>{
                            activeEditor.dispatchCommand(Lexical.FORMAT_ELEMENT_COMMAND, "right");
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(fi_index_esm/* FiAlignRight */.Pwq, {
                                className: "text-sm"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Right Align"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DropDownItem, {
                        onClick: ()=>{
                            activeEditor.dispatchCommand(Lexical.FORMAT_ELEMENT_COMMAND, "justify");
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(fi_index_esm/* FiAlignJustify */.X_s, {
                                className: "text-sm"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Justify Align"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Divider, {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DropDownItem, {
                        onClick: ()=>{
                            activeEditor.dispatchCommand(Lexical.OUTDENT_CONTENT_COMMAND, undefined);
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(bi_index_esm/* BiRightIndent */.WHD, {
                                className: "text-sm"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Outdent"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DropDownItem, {
                        onClick: ()=>{
                            activeEditor.dispatchCommand(Lexical.INDENT_CONTENT_COMMAND, undefined);
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(bi_index_esm/* BiLeftIndent */.xC0, {
                                className: "text-sm"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Indent"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/text-editor/context/shared-history.tsx
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ 



const Context = /*#__PURE__*/ (0,react_.createContext)({});
const SharedHistoryContext = ({ children })=>{
    const historyContext = (0,react_.useMemo)(()=>({
            historyState: (0,LexicalHistoryPlugin.createEmptyHistoryState)()
        }), []);
    return /*#__PURE__*/ jsx_runtime_.jsx(Context.Provider, {
        value: historyContext,
        children: children
    });
};
const useSharedHistoryContext = ()=>{
    return (0,react_.useContext)(Context);
};

;// CONCATENATED MODULE: ./components/text-editor/plugins/code-highlight-plugin.tsx



function CodeHighlightPlugin() {
    const [editor] = (0,LexicalComposerContext.useLexicalComposerContext)();
    (0,react_.useEffect)(()=>{
        return (0,LexicalCode.registerCodeHighlighting)(editor);
    }, [
        editor
    ]);
    return null;
}

// EXTERNAL MODULE: ./node_modules/@lexical/react/LexicalComposer.js
var LexicalComposer = __webpack_require__(95435);
// EXTERNAL MODULE: ./node_modules/@lexical/table/LexicalTable.js
var LexicalTable = __webpack_require__(43353);
// EXTERNAL MODULE: ./components/text-editor/theme/theme.module.css
var theme_module = __webpack_require__(8730);
var theme_module_default = /*#__PURE__*/__webpack_require__.n(theme_module);
;// CONCATENATED MODULE: ./components/text-editor/theme/index.ts
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ 
const theme = {
    characterLimit: (theme_module_default()).PlaygroundEditorTheme__characterLimit,
    code: (theme_module_default()).PlaygroundEditorTheme__code,
    codeHighlight: {
        atrule: (theme_module_default()).PlaygroundEditorTheme__tokenAttr || "",
        attr: (theme_module_default()).PlaygroundEditorTheme__tokenAttr || "",
        boolean: (theme_module_default()).PlaygroundEditorTheme__tokenProperty || "",
        builtin: (theme_module_default()).PlaygroundEditorTheme__tokenSelector || "",
        cdata: (theme_module_default()).PlaygroundEditorTheme__tokenComment || "",
        char: (theme_module_default()).PlaygroundEditorTheme__tokenSelector || "",
        class: (theme_module_default()).PlaygroundEditorTheme__tokenFunction || "",
        "class-name": (theme_module_default()).PlaygroundEditorTheme__tokenFunction || "",
        comment: (theme_module_default()).PlaygroundEditorTheme__tokenComment || "",
        constant: (theme_module_default()).PlaygroundEditorTheme__tokenProperty || "",
        deleted: (theme_module_default()).PlaygroundEditorTheme__tokenProperty || "",
        doctype: (theme_module_default()).PlaygroundEditorTheme__tokenComment || "",
        entity: (theme_module_default()).PlaygroundEditorTheme__tokenOperator || "",
        function: (theme_module_default()).PlaygroundEditorTheme__tokenFunction || "",
        important: (theme_module_default()).PlaygroundEditorTheme__tokenVariable || "",
        inserted: (theme_module_default()).PlaygroundEditorTheme__tokenSelector || "",
        keyword: (theme_module_default()).PlaygroundEditorTheme__tokenAttr || "",
        namespace: (theme_module_default()).PlaygroundEditorTheme__tokenVariable || "",
        number: (theme_module_default()).PlaygroundEditorTheme__tokenProperty || "",
        operator: (theme_module_default()).PlaygroundEditorTheme__tokenOperator || "",
        prolog: (theme_module_default()).PlaygroundEditorTheme__tokenComment || "",
        property: (theme_module_default()).PlaygroundEditorTheme__tokenProperty || "",
        punctuation: (theme_module_default()).PlaygroundEditorTheme__tokenPunctuation || "",
        regex: (theme_module_default()).PlaygroundEditorTheme__tokenVariable || "",
        selector: (theme_module_default()).PlaygroundEditorTheme__tokenSelector || "",
        string: (theme_module_default()).PlaygroundEditorTheme__tokenSelector || "",
        symbol: (theme_module_default()).PlaygroundEditorTheme__tokenProperty || "",
        tag: (theme_module_default()).PlaygroundEditorTheme__tokenProperty || "",
        url: (theme_module_default()).PlaygroundEditorTheme__tokenOperator || "",
        variable: (theme_module_default()).PlaygroundEditorTheme__tokenVariable || ""
    },
    embedBlock: {
        base: (theme_module_default()).PlaygroundEditorTheme__embedBlock || "",
        focus: (theme_module_default()).PlaygroundEditorTheme__embedBlockFocus || ""
    },
    hashtag: (theme_module_default()).PlaygroundEditorTheme__hashtag || "",
    heading: {
        h1: (theme_module_default()).PlaygroundEditorTheme__h1 || "",
        h2: (theme_module_default()).PlaygroundEditorTheme__h2 || "",
        h3: (theme_module_default()).PlaygroundEditorTheme__h3 || "",
        h4: (theme_module_default()).PlaygroundEditorTheme__h4 || "",
        h5: (theme_module_default()).PlaygroundEditorTheme__h5 || "",
        h6: (theme_module_default()).PlaygroundEditorTheme__h6 || ""
    },
    image: "editor-image",
    link: (theme_module_default()).PlaygroundEditorTheme__link || "",
    list: {
        listitem: (theme_module_default()).PlaygroundEditorTheme__listItem || "",
        listitemChecked: (theme_module_default()).PlaygroundEditorTheme__listItemChecked || "",
        listitemUnchecked: (theme_module_default()).PlaygroundEditorTheme__listItemUnchecked || "",
        nested: {
            listitem: (theme_module_default()).PlaygroundEditorTheme__nestedListItem || ""
        },
        olDepth: [
            (theme_module_default()).PlaygroundEditorTheme__ol1 || "",
            (theme_module_default()).PlaygroundEditorTheme__ol2 || "",
            (theme_module_default()).PlaygroundEditorTheme__ol3 || "",
            (theme_module_default()).PlaygroundEditorTheme__ol4 || "",
            (theme_module_default()).PlaygroundEditorTheme__ol5 || ""
        ],
        ul: (theme_module_default()).PlaygroundEditorTheme__ul || ""
    },
    ltr: (theme_module_default()).PlaygroundEditorTheme__ltr || "",
    mark: (theme_module_default()).PlaygroundEditorTheme__mark || "",
    markOverlap: (theme_module_default()).PlaygroundEditorTheme__markOverlap || "",
    paragraph: (theme_module_default()).PlaygroundEditorTheme__paragraph || "",
    quote: (theme_module_default()).PlaygroundEditorTheme__quote || "",
    rtl: (theme_module_default()).PlaygroundEditorTheme__rtl || "",
    table: (theme_module_default()).PlaygroundEditorTheme__table || "",
    tableAddColumns: (theme_module_default()).PlaygroundEditorTheme__tableAddColumns || "",
    tableAddRows: (theme_module_default()).PlaygroundEditorTheme__tableAddRows || "",
    tableCell: (theme_module_default()).PlaygroundEditorTheme__tableCell || "",
    tableCellActionButton: (theme_module_default()).PlaygroundEditorTheme__tableCellActionButton || "",
    tableCellActionButtonContainer: (theme_module_default()).PlaygroundEditorTheme__tableCellActionButtonContainer || "",
    tableCellEditing: (theme_module_default()).PlaygroundEditorTheme__tableCellEditing || "",
    tableCellHeader: (theme_module_default()).PlaygroundEditorTheme__tableCellHeader || "",
    tableCellPrimarySelected: (theme_module_default()).PlaygroundEditorTheme__tableCellPrimarySelected || "",
    tableCellResizer: (theme_module_default()).PlaygroundEditorTheme__tableCellResizer || "",
    tableCellSelected: (theme_module_default()).PlaygroundEditorTheme__tableCellSelected || "",
    tableCellSortedIndicator: (theme_module_default()).PlaygroundEditorTheme__tableCellSortedIndicator || "",
    tableResizeRuler: (theme_module_default()).PlaygroundEditorTheme__tableCellResizeRuler || "",
    tableSelected: (theme_module_default()).PlaygroundEditorTheme__tableSelected || "",
    text: {
        bold: (theme_module_default()).PlaygroundEditorTheme__textBold || "",
        code: (theme_module_default()).PlaygroundEditorTheme__textCode || "",
        italic: (theme_module_default()).PlaygroundEditorTheme__textItalic || "",
        strikethrough: (theme_module_default()).PlaygroundEditorTheme__textStrikethrough || "",
        subscript: (theme_module_default()).PlaygroundEditorTheme__textSubscript || "",
        superscript: (theme_module_default()).PlaygroundEditorTheme__textSuperscript || "",
        underline: (theme_module_default()).PlaygroundEditorTheme__textUnderline || "",
        underlineStrikethrough: (theme_module_default()).PlaygroundEditorTheme__textUnderlineStrikethrough || ""
    }
};
/* harmony default export */ const text_editor_theme = (theme);

;// CONCATENATED MODULE: ./components/text-editor/context/lexical-composer.tsx








const EditorComposer = ({ jsonState, readonly, children })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(LexicalComposer.LexicalComposer, {
        initialConfig: {
            namespace: "Jira Clone",
            editorState: JSON.stringify(jsonState),
            editable: !readonly,
            theme: text_editor_theme,
            nodes: [
                LexicalRichText.HeadingNode,
                LexicalRichText.QuoteNode,
                LexicalList.ListNode,
                LexicalList.ListItemNode,
                LexicalRichText.QuoteNode,
                LexicalCode.CodeNode,
                LexicalCode.CodeHighlightNode,
                LexicalTable.TableCellNode,
                LexicalTable.TableNode,
                LexicalTable.TableRowNode
            ],
            onError (error) {
                throw error;
            }
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx(SharedHistoryContext, {
            children: children
        })
    });
};

;// CONCATENATED MODULE: ./components/text-editor/editor.tsx
/* __next_internal_client_entry_do_not_use__ Editor auto */ 














function onChange(state, setJsonState) {
    state.read(()=>{
        if (state.isEmpty()) {
            setJsonState(undefined);
            return;
        }
        setJsonState(state.toJSON());
    });
}
const Editor = ({ action, onSave, onCancel, content, className })=>{
    const { historyState } = useSharedHistoryContext();
    const [jsonState, setJsonState] = (0,react_.useState)(content);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: clsx_default()("w-full rounded-[3px] border border-gray-200 bg-white shadow-sm", className),
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(EditorComposer, {
                    readonly: false,
                    jsonState: jsonState,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(ToolbarPlugin, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "relative",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(LexicalRichTextPlugin.RichTextPlugin, {
                                ErrorBoundary: (LexicalErrorBoundary_default()),
                                contentEditable: /*#__PURE__*/ jsx_runtime_.jsx(LexicalContentEditable.ContentEditable, {
                                    className: "min-h-[100px] w-full resize-none overflow-hidden text-ellipsis px-2.5 py-4 outline-none"
                                }),
                                placeholder: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "pointer-events-none absolute top-6 select-none px-3 text-sm text-gray-500",
                                    children: [
                                        "Add your ",
                                        action,
                                        " here..."
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(CodeHighlightPlugin, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(LexicalListPlugin.ListPlugin, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(LexicalAutoFocusPlugin.AutoFocusPlugin, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(LexicalOnChangePlugin.OnChangePlugin, {
                            onChange: (editor)=>onChange(editor, setJsonState)
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(LexicalHistoryPlugin.HistoryPlugin, {
                            externalHistoryState: historyState
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "my-3 flex gap-x-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                        onClick: ()=>onSave && onSave(jsonState),
                        customColors: true,
                        customPadding: true,
                        className: "bg-inprogress px-2.5 py-1.5 text-sm font-medium text-white hover:brightness-110",
                        children: "Save"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                        onClick: onCancel,
                        customColors: true,
                        customPadding: true,
                        className: "px-2.5 py-1.5 text-sm font-medium hover:bg-gray-200",
                        children: "Cancel"
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./hooks/use-keydown-listener.ts
/* __next_internal_client_entry_do_not_use__ useKeydownListener auto */ 
const useKeydownListener = (ref, targetKey, callback)=>{
    const inputRef = (0,react_.useRef)(null);
    const isInsideContentEditable = ()=>!!document.activeElement?.getAttribute("contenteditable") || document.activeElement?.tagName && [
            "TEXTAREA",
            "INPUT"
        ].includes(document.activeElement?.tagName);
    (0,react_.useEffect)(()=>{
        const handleKeyDown = (event)=>{
            if (!isInsideContentEditable()) {
                if (typeof targetKey === "string") {
                    if (event.key === targetKey) {
                        event.preventDefault();
                        callback(ref, event);
                    }
                } else if (Array.isArray(targetKey)) {
                    if (targetKey.includes(event.key)) {
                        event.preventDefault();
                        callback(ref, event);
                    }
                }
            }
        };
        const currentRef = ref.current;
        if (currentRef) {
            document.addEventListener("keydown", handleKeyDown);
        }
        return ()=>{
            if (currentRef) {
                document.removeEventListener("keydown", handleKeyDown);
            }
        };
    }, [
        ref,
        targetKey,
        callback
    ]);
    return [
        inputRef
    ];
};

// EXTERNAL MODULE: ./node_modules/@clerk/clerk-react/dist/esm/index.js + 63 modules
var esm = __webpack_require__(48751);
// EXTERNAL MODULE: ./components/avatar.tsx
var avatar = __webpack_require__(76628);
// EXTERNAL MODULE: ./node_modules/dayjs/dayjs.min.js
var dayjs_min = __webpack_require__(43598);
var dayjs_min_default = /*#__PURE__*/__webpack_require__.n(dayjs_min);
// EXTERNAL MODULE: ./node_modules/dayjs/plugin/relativeTime.js
var relativeTime = __webpack_require__(56087);
var relativeTime_default = /*#__PURE__*/__webpack_require__.n(relativeTime);
;// CONCATENATED MODULE: ./components/text-editor/preview.tsx
/* __next_internal_client_entry_do_not_use__ EditorPreview auto */ 








const EditorPreview = ({ action, content, className })=>{
    const [jsonState] = (0,react_.useState)(content);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(EditorComposer, {
        readonly: true,
        jsonState: jsonState,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "relative w-full rounded-[3px] bg-white",
                children: /*#__PURE__*/ jsx_runtime_.jsx(LexicalRichTextPlugin.RichTextPlugin, {
                    ErrorBoundary: (LexicalErrorBoundary_default()),
                    contentEditable: /*#__PURE__*/ jsx_runtime_.jsx(LexicalContentEditable.ContentEditable, {
                        className: clsx_default()("w-full resize-none overflow-hidden text-ellipsis rounded-[3px] outline-none", className)
                    }),
                    placeholder: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "pointer-events-none absolute left-0 top-0 flex h-full select-none items-center px-1 text-sm text-gray-500",
                        children: [
                            "Add your ",
                            action,
                            " here..."
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(CodeHighlightPlugin, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(LexicalListPlugin.ListPlugin, {})
        ]
    });
};

;// CONCATENATED MODULE: ./components/issue/issue-details/issue-details-info/issue-details-info-comments.tsx













dayjs_min_default().extend((relativeTime_default()));
const Comments = ({ issue })=>{
    const scrollRef = (0,react_.useRef)(null);
    const [isWritingComment, setIsWritingComment] = (0,react_.useState)(false);
    const [isInViewport, ref] = useIsInViewport();
    const { comments, addComment } = useIssueDetails();
    const [isAuthenticated, openAuthModal] = (0,use_is_authed/* useIsAuthenticated */.k)();
    const { user } = (0,esm/* useUser */.aF)();
    useKeydownListener(scrollRef, [
        "m",
        "M"
    ], handleEdit);
    function handleEdit(ref) {
        setIsWritingComment(true);
        setTimeout(()=>{
            if (ref.current) {
                ref.current.scrollIntoView({
                    behavior: "smooth"
                });
            }
        }, 50);
    }
    function handleSave(state) {
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        if (!state) {
            setIsWritingComment(false);
            return;
        }
        addComment({
            issueId: issue.id,
            content: JSON.stringify(state),
            // eslint-disable-next-line
            authorId: user.id
        });
        setIsWritingComment(false);
    }
    function handleCancel() {
        setIsWritingComment(false);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                children: "Comments"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "sticky bottom-0 mb-5 w-full bg-white",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        ref: scrollRef,
                        id: "dummy-scroll-div"
                    }),
                    isWritingComment ? /*#__PURE__*/ jsx_runtime_.jsx(Editor, {
                        action: "comment",
                        content: undefined,
                        onSave: handleSave,
                        onCancel: handleCancel
                    }) : /*#__PURE__*/ jsx_runtime_.jsx(AddComment, {
                        user: user,
                        onAddComment: ()=>handleEdit(scrollRef),
                        commentsInViewport: isInViewport
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                ref: ref,
                className: "flex flex-col gap-y-5 pb-5",
                children: comments?.map((comment)=>/*#__PURE__*/ jsx_runtime_.jsx(CommentPreview, {
                        comment: comment,
                        user: user
                    }, comment.id))
            })
        ]
    });
};
const CommentPreview = ({ comment, user })=>{
    const [isEditing, setIsEditing] = (0,react_.useState)(false);
    const [isAuthenticated, openAuthModal] = (0,use_is_authed/* useIsAuthenticated */.k)();
    const { updateComment } = useIssueDetails();
    function handleSave(state) {
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        updateComment({
            issueId: comment.issueId,
            commentId: comment.id,
            content: JSON.stringify(state)
        });
        setIsEditing(false);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex w-full gap-x-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(avatar/* Avatar */.q, {
                src: comment.author?.avatar ?? "",
                alt: `${comment.author?.name ?? "Guest"}`
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center gap-x-3 text-xs",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "font-semibold text-gray-600 ",
                                children: comment.author?.name
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-gray-500",
                                children: dayjs_min_default()(comment.createdAt).fromNow()
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                "data-state": comment.isEdited ? "edited" : "not-edited",
                                className: "hidden text-gray-400 [&[data-state=edited]]:block",
                                children: "(Edited)"
                            })
                        ]
                    }),
                    isEditing ? /*#__PURE__*/ jsx_runtime_.jsx(Editor, {
                        action: "comment",
                        content: comment.content ? JSON.parse(comment.content) : undefined,
                        onSave: handleSave,
                        onCancel: ()=>setIsEditing(false),
                        className: "mt-2"
                    }) : /*#__PURE__*/ jsx_runtime_.jsx(EditorPreview, {
                        action: "comment",
                        content: comment.content ? JSON.parse(comment.content) : undefined
                    }),
                    comment.authorId == user?.id ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mb-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                onClick: ()=>setIsEditing(true),
                                customColors: true,
                                className: "bg-transparent text-xs font-medium text-gray-500 underline-offset-2 hover:underline",
                                children: "Edit"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                customColors: true,
                                className: "bg-transparent text-xs font-medium text-gray-500 underline-offset-2 hover:underline",
                                children: "Delete"
                            })
                        ]
                    }) : null
                ]
            })
        ]
    });
};
const AddComment = ({ onAddComment, user, commentsInViewport })=>{
    function handleAddComment(event) {
        event.preventDefault();
        onAddComment();
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        "data-state": commentsInViewport ? "inViewport" : "notInViewport",
        className: "flex w-full gap-x-2 border-t-2 border-transparent py-3 [&[data-state=notInViewport]]:border-gray-200",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(avatar/* Avatar */.q, {
                src: user?.imageUrl,
                alt: user ? `${user?.firstName ?? ""} ${user?.lastName ?? ""}` : "Guest"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                        htmlFor: "add-comment",
                        className: "sr-only",
                        children: "Add Comment"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        onMouseDown: handleAddComment,
                        type: "text",
                        id: "add-comment",
                        placeholder: "Add a comment...",
                        className: "w-full rounded-[3px] border border-gray-300 px-4 py-2 placeholder:text-sm"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "my-2 text-xs text-gray-500",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "font-bold",
                                children: "Pro tip:"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: " press "
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "rounded-[3px] bg-gray-300 px-1 py-0.5 font-bold",
                                children: "M"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: " to comment "
                            })
                        ]
                    })
                ]
            })
        ]
    });
};


;// CONCATENATED MODULE: ./components/issue/issue-details/issue-details-info/issue-details-info-meta.tsx


const IssueMetaInfo = ({ issue })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "mb-3 flex flex-col gap-y-3",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "text-xs text-gray-500",
                children: "Created " + (0,helpers/* dateToLongString */.CD)(issue.createdAt)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "text-xs text-gray-500",
                children: "Updated " + (0,helpers/* dateToLongString */.CD)(issue.updatedAt)
            })
        ]
    });
};


;// CONCATENATED MODULE: ./components/issue/issue-details/issue-details-info/issue-details-info-description.tsx






const Description = ({ issue })=>{
    const [isEditing, setIsEditing] = (0,react_.useState)(false);
    const { updateIssue } = (0,use_issues/* useIssues */.g)();
    const [isAuthenticated, openAuthModal] = (0,use_is_authed/* useIsAuthenticated */.k)();
    const [content, setContent] = (0,react_.useState)(issue.description ? JSON.parse(issue.description) : undefined);
    function handleEdit(event) {
        event.preventDefault();
        setIsEditing(true);
    }
    function handleSave(state) {
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        setContent(state);
        updateIssue({
            issueId: issue.id,
            description: state ? JSON.stringify(state) : undefined
        });
        setIsEditing(false);
    }
    function handleCancel() {
        setIsEditing(false);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                children: "Description"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: isEditing ? /*#__PURE__*/ jsx_runtime_.jsx(Editor, {
                    action: "description",
                    content: content,
                    onSave: handleSave,
                    onCancel: handleCancel
                }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    onMouseDown: handleEdit,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(EditorPreview, {
                        action: "description",
                        content: content,
                        className: "transition-all duration-200 hover:bg-gray-100"
                    })
                })
            })
        ]
    });
};


// EXTERNAL MODULE: ./components/ui/accordion.tsx
var accordion = __webpack_require__(74887);
// EXTERNAL MODULE: ./hooks/query-hooks/use-sprints.ts
var use_sprints = __webpack_require__(75589);
// EXTERNAL MODULE: ./components/issue/issue-select-assignee.tsx
var issue_select_assignee = __webpack_require__(64844);
;// CONCATENATED MODULE: ./components/issue/issue-details/issue-details-info/issue-details-info-accordion.tsx











const IssueDetailsInfoAccordion = ({ issue })=>{
    const { updateIssue } = (0,use_issues/* useIssues */.g)();
    const [isAuthenticated, openAuthModal] = (0,use_is_authed/* useIsAuthenticated */.k)();
    const { sprints } = (0,use_sprints/* useSprints */.D)();
    const { user } = (0,esm/* useUser */.aF)();
    const [openAccordion, setOpenAccordion] = (0,react_.useState)("details");
    function handleAutoAssign() {
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        updateIssue({
            issueId: issue.id,
            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            assigneeId: user.id
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(accordion/* Accordion */.UQ, {
        onValueChange: setOpenAccordion,
        value: openAccordion,
        className: "my-3 w-min min-w-full rounded-[3px] border",
        type: "single",
        collapsible: true,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(accordion/* AccordionItem */.Qd, {
            value: "details",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(accordion/* AccordionTrigger */.o4, {
                    className: "flex w-full items-center justify-between p-2 font-medium hover:bg-gray-100 [&[data-state=open]>svg]:rotate-180 [&[data-state=open]]:border-b",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex items-center gap-x-1",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-sm",
                                    children: "Details"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-xs text-gray-500",
                                    children: "(Assignee, Sprint, Reporter)"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(fa_index_esm/* FaChevronUp */.s$2, {
                            className: "mr-2 text-xs text-black transition-transform",
                            "aria-hidden": true
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(accordion/* AccordionContent */.vF, {
                    className: "flex flex-col bg-white px-3 [&[data-state=open]]:py-2",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            "data-state": issue.assignee ? "assigned" : "unassigned",
                            className: "my-2 grid grid-cols-3 [&[data-state=assigned]]:items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-sm font-semibold text-gray-600",
                                    children: "Assignee"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(issue_select_assignee/* IssueAssigneeSelect */.G, {
                                            issue: issue
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                            onClick: handleAutoAssign,
                                            "data-state": issue.assignee ? "assigned" : "unassigned",
                                            customColors: true,
                                            customPadding: true,
                                            className: "mt-1 hidden text-sm text-blue-600 underline-offset-2 hover:underline [&[data-state=unassigned]]:flex",
                                            children: "Assign to me"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "my-4 grid grid-cols-3 items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-sm font-semibold text-gray-600",
                                    children: "Sprint"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex items-center",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-sm text-gray-700",
                                        children: sprints?.find((sprint)=>sprint?.id == issue.sprintId)?.name ?? "None"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "my-2 grid grid-cols-3  items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-sm font-semibold text-gray-600",
                                    children: "Reporter"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex items-center gap-x-3 ",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(avatar/* Avatar */.q, {
                                            src: issue.reporter?.avatar,
                                            alt: `${issue.reporter?.name ?? "Unassigned"}`
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "whitespace-nowrap text-sm",
                                            children: issue.reporter?.name
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};


// EXTERNAL MODULE: ./node_modules/react-icons/cg/index.esm.js
var cg_index_esm = __webpack_require__(32314);
;// CONCATENATED MODULE: ./components/issue/issue-details/issue-details-info/issue-details-info-actions.tsx








const IssueDetailsInfoActions = ({ onAddChildIssue, variant = "sm" })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex gap-x-2 text-gray-700",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(not_implemented/* NotImplemented */.r, {
                feature: "attachment",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                    customColors: true,
                    className: "flex items-center whitespace-nowrap bg-gray-100 hover:bg-gray-200",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(cg_index_esm/* CgAttachment */.fmF, {
                            className: "rotate-45 text-xl"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            "data-state": variant === "sm" ? "sm" : "lg",
                            className: "whitespace-nowrap text-sm  font-medium [&[data-state=lg]]:ml-2",
                            children: variant === "sm" ? null : "Attach"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(tooltip/* TooltipWrapper */.pf, {
                text: "Add child issue",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                    onClick: onAddChildIssue,
                    customColors: true,
                    className: "flex items-center whitespace-nowrap bg-gray-100 hover:bg-gray-200",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(svgs/* ChildrenTreeIcon */.eS, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            "data-state": variant === "sm" ? "sm" : "lg",
                            className: "whitespace-nowrap text-sm  font-medium [&[data-state=lg]]:ml-2",
                            children: variant === "sm" ? null : "Add a child issue"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(not_implemented/* NotImplemented */.r, {
                feature: "link",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                    customColors: true,
                    className: "flex items-center whitespace-nowrap bg-gray-100 hover:bg-gray-200",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(bi_index_esm/* BiLink */.Wlb, {
                            className: "text-xl"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            "data-state": variant === "sm" ? "sm" : "lg",
                            className: "whitespace-nowrap text-sm  font-medium [&[data-state=lg]]:ml-2",
                            children: variant === "sm" ? null : "Link issue"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(not_implemented/* NotImplemented */.r, {
                feature: "add apps",
                children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                    customColors: true,
                    className: "flex items-center whitespace-nowrap bg-gray-100 hover:bg-gray-200",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(bs_index_esm/* BsThreeDots */.evw, {
                        className: "text-xl"
                    })
                })
            })
        ]
    });
};


// EXTERNAL MODULE: ./components/ui/context-menu.tsx
var context_menu = __webpack_require__(72463);
// EXTERNAL MODULE: ./components/issue/issue-empty.tsx
var issue_empty = __webpack_require__(74349);
// EXTERNAL MODULE: ./components/progress-bar.tsx
var progress_bar = __webpack_require__(40796);
;// CONCATENATED MODULE: ./components/issue/issue-details/issue-details-info/issue-details-info-child-issues.tsx

















const ChildIssueList = ({ issues, parentIsEpic, parentId, isAddingChildIssue, setIsAddingChildIssue })=>{
    const { createIssue, isCreating } = (0,use_issues/* useIssues */.g)();
    const [isEditing, setIsEditing] = (0,react_.useState)(isAddingChildIssue);
    const [isAuthenticated, openAuthModal] = (0,use_is_authed/* useIsAuthenticated */.k)();
    function handleCreateIssue({ name, type, parentId }) {
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        if (!name) {
            return;
        }
        createIssue({
            name,
            type,
            parentId,
            sprintId: null,
            reporterId: null
        }, {
            onSuccess: ()=>{
                setIsEditing(false);
                setIsAddingChildIssue(false);
            }
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        children: "Child Issues"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                        onClick: ()=>setIsEditing(true),
                        customColors: true,
                        customPadding: true,
                        className: "p-1 hover:bg-gray-100",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ai_index_esm/* AiOutlinePlus */.Lfi, {})
                    })
                ]
            }),
            issues.length ? /*#__PURE__*/ jsx_runtime_.jsx(progress_bar/* ProgressBar */.k, {
                issues: issues
            }) : null,
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "mt-3"
            }),
            issues.sort((a, b)=>new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()).map((issue)=>{
                return /*#__PURE__*/ jsx_runtime_.jsx(ChildIssue, {
                    issue: issue
                }, issue.key);
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(issue_empty/* EmtpyIssue */.z, {
                "data-state": isEditing || isAddingChildIssue ? "open" : "closed",
                className: "[&[data-state=closed]]:hidden",
                onCreate: ({ name, type, parentId })=>handleCreateIssue({
                        name,
                        type,
                        parentId
                    }),
                onCancel: ()=>{
                    setIsEditing(false);
                    setIsAddingChildIssue(false);
                },
                isCreating: isCreating,
                isSubtask: !parentIsEpic,
                parentId: parentId
            })
        ]
    });
};
const ChildIssue = ({ issue })=>{
    const [isEditing, setIsEditing] = (0,react_.useState)(false);
    const inputRef = (0,react_.useRef)(null);
    const { setIssueKey, issueKey } = (0,use_selected_issue_context.useSelectedIssueContext)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        "data-state": issueKey == issue.key ? "selected" : "not-selected",
        onClick: ()=>setIssueKey(issue.key),
        className: clsx_default()("group flex w-full max-w-full items-center justify-between border-[0.3px] border-gray-300 px-3 py-1.5 text-sm hover:bg-gray-50 [&[data-state=selected]]:bg-blue-100"),
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                "data-state": isEditing ? "editing" : "not-editing",
                className: "flex w-fit items-center gap-x-2 [&[data-state=editing]]:w-full [&[data-state=not-editing]]:overflow-x-hidden",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(issue_icon/* IssueIcon */.u, {
                        issueType: issue.type
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        "data-state": issue.status,
                        className: "whitespace-nowrap text-sm text-gray-500 [&[data-state=DONE]]:line-through",
                        children: issue.key
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(issue_title/* IssueTitle */.w, {
                        className: "truncate py-1.5 text-sm hover:cursor-pointer hover:underline",
                        isEditing: isEditing,
                        setIsEditing: setIsEditing,
                        issue: issue,
                        useTooltip: true,
                        ref: inputRef
                    }, issue.id + issue.name),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        "data-state": isEditing ? "editing" : "not-editing",
                        className: "flex items-center gap-x-1 [&[data-state=editing]]:hidden",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                            onClick: (e)=>{
                                e.stopPropagation();
                                setIsEditing(!isEditing);
                            },
                            className: "invisible w-0 px-0 group-hover:visible group-hover:w-fit group-hover:bg-transparent group-hover:px-1.5 group-hover:hover:bg-gray-200 ",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* MdEdit */.zmo, {
                                className: "text-sm"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(issue_menu/* IssueContextMenu */.L, {
                isEditing: isEditing,
                className: "flex-auto",
                children: /*#__PURE__*/ jsx_runtime_.jsx(context_menu/* ContextTrigger */.ud, {
                    className: "h-8 w-full"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative ml-2 flex min-w-fit items-center justify-end gap-x-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(issue_select_assignee/* IssueAssigneeSelect */.G, {
                        issue: issue,
                        avatarSize: 20,
                        avatarOnly: true
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(issue_select_status/* IssueSelectStatus */.ej, {
                        currentStatus: issue.status,
                        issueId: issue.id
                    }, issue.id + issue.status)
                ]
            })
        ]
    }, issue.id);
};


// EXTERNAL MODULE: ./components/color-picker.tsx
var color_picker = __webpack_require__(14285);
;// CONCATENATED MODULE: ./hooks/use-container-width.ts
/* __next_internal_client_entry_do_not_use__ useContainerWidth auto */ 
const useContainerWidth = ()=>{
    const containerRef = (0,react_.useRef)(null);
    const [containerWidth, setContainerWidth] = (0,react_.useState)(null);
    const handleResize = ()=>{
        if (containerRef.current) {
            setContainerWidth(containerRef.current.offsetWidth);
        }
    };
    (0,react_.useEffect)(()=>{
        handleResize();
        if (containerRef.current) {
            const resizeObserver = new ResizeObserver(handleResize);
            resizeObserver.observe(containerRef.current);
            const curr = containerRef.current;
            return ()=>{
                if (curr) {
                    resizeObserver.unobserve(curr);
                }
            };
        }
    }, []);
    return [
        containerRef,
        containerWidth
    ];
};

// EXTERNAL MODULE: ./node_modules/react-split/dist/react-split.js
var react_split = __webpack_require__(49641);
var react_split_default = /*#__PURE__*/__webpack_require__.n(react_split);
// EXTERNAL MODULE: ./styles/split.css
var split = __webpack_require__(19746);
;// CONCATENATED MODULE: ./components/issue/issue-details/issue-details-info/index.tsx



















const IssueDetailsInfo = /*#__PURE__*/ react_default().forwardRef(({ issue }, ref)=>{
    const [parentRef, parentWidth] = useContainerWidth();
    if (!issue) return /*#__PURE__*/ jsx_runtime_.jsx("div", {});
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        ref: parentRef,
        children: !parentWidth ? null : parentWidth > 800 ? /*#__PURE__*/ jsx_runtime_.jsx(LargeIssueDetails, {
            issue: issue,
            ref: ref
        }) : /*#__PURE__*/ jsx_runtime_.jsx(SmallIssueDetailsInfo, {
            issue: issue,
            ref: ref
        })
    });
});
IssueDetailsInfo.displayName = "IssueDetailsInfo";
const SmallIssueDetailsInfo = /*#__PURE__*/ react_default().forwardRef(({ issue }, ref)=>{
    const { issueKey } = (0,use_selected_issue_context.useSelectedIssueContext)();
    const nameRef = (0,react_.useRef)(null);
    const [isEditing, setIsEditing] = (0,react_.useState)(false);
    const [isAddingChildIssue, setIsAddingChildIssue] = (0,react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center gap-x-2",
                children: [
                    (0,helpers/* isEpic */.pQ)(issue) ? /*#__PURE__*/ jsx_runtime_.jsx(color_picker/* ColorPicker */.zH, {
                        issue: issue
                    }) : null,
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        ref: ref,
                        role: "button",
                        onClick: ()=>setIsEditing(true),
                        "data-state": isEditing ? "editing" : "notEditing",
                        className: "w-full transition-all [&[data-state=notEditing]]:hover:bg-gray-100",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(issue_title/* IssueTitle */.w, {
                            className: "mr-1 py-1",
                            isEditing: isEditing,
                            setIsEditing: setIsEditing,
                            issue: issue,
                            ref: nameRef
                        }, issue.id + issue.name)
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(IssueDetailsInfoActions, {
                onAddChildIssue: ()=>setIsAddingChildIssue(true)
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative flex items-center gap-x-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(issue_select_status/* IssueSelectStatus */.ej, {
                        currentStatus: issue.status,
                        issueId: issue.id,
                        variant: "lg"
                    }, issue.id + issue.status),
                    /*#__PURE__*/ jsx_runtime_.jsx(not_implemented/* NotImplemented */.r, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                            customColors: true,
                            className: "hover:bg-gray-200",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(svgs/* LightningIcon */.Bk, {
                                        className: "mt-0.5"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "Actions"
                                    })
                                ]
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Description, {
                issue: issue
            }, String(issueKey) + issue.id),
            (0,helpers/* hasChildren */.g8)(issue) || isAddingChildIssue ? /*#__PURE__*/ jsx_runtime_.jsx(ChildIssueList, {
                issues: issue.children,
                parentIsEpic: (0,helpers/* isEpic */.pQ)(issue),
                parentId: issue.id,
                isAddingChildIssue: isAddingChildIssue,
                setIsAddingChildIssue: setIsAddingChildIssue
            }) : null,
            /*#__PURE__*/ jsx_runtime_.jsx(IssueDetailsInfoAccordion, {
                issue: issue
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(IssueMetaInfo, {
                issue: issue
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Comments, {
                issue: issue
            })
        ]
    });
});
SmallIssueDetailsInfo.displayName = "SmallIssueDetailsInfo";
const LargeIssueDetails = /*#__PURE__*/ react_default().forwardRef(({ issue }, ref)=>{
    const { issueKey } = (0,use_selected_issue_context.useSelectedIssueContext)();
    const nameRef = (0,react_.useRef)(null);
    const [isEditing, setIsEditing] = (0,react_.useState)(false);
    const [isAddingChildIssue, setIsAddingChildIssue] = (0,react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((react_split_default()), {
        sizes: [
            60,
            40
        ],
        gutterSize: 2,
        className: "flex max-h-[70vh] w-full overflow-hidden",
        minSize: 300,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "overflow-y-auto pr-3",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center gap-x-2",
                        children: [
                            (0,helpers/* isEpic */.pQ)(issue) ? /*#__PURE__*/ jsx_runtime_.jsx(color_picker/* ColorPicker */.zH, {
                                issue: issue
                            }) : null,
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                ref: ref,
                                role: "button",
                                onClick: ()=>setIsEditing(true),
                                "data-state": isEditing ? "editing" : "notEditing",
                                className: "w-full transition-all [&[data-state=notEditing]]:hover:bg-gray-100",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(issue_title/* IssueTitle */.w, {
                                    className: "mr-1 py-1",
                                    isEditing: isEditing,
                                    setIsEditing: setIsEditing,
                                    issue: issue,
                                    ref: nameRef
                                }, issue.id + issue.name)
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(IssueDetailsInfoActions, {
                        onAddChildIssue: ()=>setIsAddingChildIssue(true),
                        variant: "lg"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Description, {
                        issue: issue
                    }, String(issueKey) + issue.id),
                    (0,helpers/* hasChildren */.g8)(issue) || isAddingChildIssue ? /*#__PURE__*/ jsx_runtime_.jsx(ChildIssueList, {
                        issues: issue.children,
                        parentIsEpic: (0,helpers/* isEpic */.pQ)(issue),
                        parentId: issue.id,
                        isAddingChildIssue: isAddingChildIssue,
                        setIsAddingChildIssue: setIsAddingChildIssue
                    }) : null,
                    /*#__PURE__*/ jsx_runtime_.jsx(Comments, {
                        issue: issue
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mt-4 bg-white pl-3",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "relative flex items-center gap-x-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(issue_select_status/* IssueSelectStatus */.ej, {
                                currentStatus: issue.status,
                                issueId: issue.id,
                                variant: "lg"
                            }, issue.id + issue.status),
                            /*#__PURE__*/ jsx_runtime_.jsx(not_implemented/* NotImplemented */.r, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                    customColors: true,
                                    className: "hover:bg-gray-200",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex items-center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(svgs/* LightningIcon */.Bk, {
                                                className: "mt-0.5"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Actions"
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(IssueDetailsInfoAccordion, {
                        issue: issue
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(IssueMetaInfo, {
                        issue: issue
                    })
                ]
            })
        ]
    });
});
LargeIssueDetails.displayName = "LargeIssueDetails";


;// CONCATENATED MODULE: ./components/issue/issue-details/index.tsx
/* __next_internal_client_entry_do_not_use__ IssueDetails auto */ 





const IssueDetails = ({ issueKey, setIssueKey })=>{
    const { issues } = (0,use_issues/* useIssues */.g)();
    const renderContainerRef = react_default().useRef(null);
    const [isInViewport, viewportRef] = useIsInViewport({
        threshold: 1
    });
    const getIssue = (0,react_.useCallback)((issueKey)=>{
        return issues?.find((issue)=>issue.key === issueKey);
    }, [
        issues
    ]);
    const [issueInfo, setIssueInfo] = (0,react_.useState)(()=>getIssue(issueKey));
    (0,react_.useEffect)(()=>{
        setIssueInfo(()=>getIssue(issueKey));
        if (renderContainerRef.current) {
            renderContainerRef.current.scrollTo({
                top: 0,
                behavior: "smooth"
            });
        }
    }, [
        issueKey,
        getIssue
    ]);
    if (!issueInfo || !issues) return /*#__PURE__*/ jsx_runtime_.jsx("div", {});
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        ref: renderContainerRef,
        "data-state": issueKey ? "open" : "closed",
        className: "relative z-10 flex w-full flex-col overflow-y-auto pl-4 pr-2 [&[data-state=closed]]:hidden",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(IssueDetailsHeader, {
                issue: issueInfo,
                setIssueKey: setIssueKey,
                isInViewport: isInViewport
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(IssueDetailsInfo, {
                issue: issueInfo,
                ref: viewportRef
            })
        ]
    });
};



/***/ }),

/***/ 74349:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   z: () => (/* binding */ EmtpyIssue)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _issue_select_type__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8854);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(38546);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(64348);
/* harmony import */ var _ui_spinner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(35215);
/* harmony import */ var _issue_icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(27603);
/* __next_internal_client_entry_do_not_use__ EmtpyIssue auto */ 







const EmtpyIssue = ({ onCreate, onCancel, isCreating, className, isEpic, isSubtask, parentId, ...props })=>{
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [type, setType] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(()=>initialType());
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    function initialType() {
        if (isSubtask) return "SUBTASK";
        if (isEpic) return "EPIC";
        return "TASK";
    }
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        focusInput();
    }, [
        props
    ]);
    function focusInput() {
        if (inputRef.current) {
            inputRef.current.focus();
        }
    }
    function handleSelect(type) {
        setType(type);
        setTimeout(()=>focusInput(), 50);
    }
    function handleCreateIssue(e) {
        if (e.key === "Enter") {
            e.preventDefault();
            if (!name) {
                return;
            }
            onCreate({
                name,
                type,
                parentId: parentId ?? null
            });
            setName("");
        }
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        ...props,
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("relative flex items-center gap-x-2 border-2 border-blue-400 bg-white p-1.5", className),
        children: [
            isSubtask ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "py-4"
            }) : isEpic ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_issue_icon__WEBPACK_IMPORTED_MODULE_6__/* .IssueIcon */ .u, {
                issueType: "EPIC"
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_issue_select_type__WEBPACK_IMPORTED_MODULE_3__/* .IssueSelectType */ .o, {
                currentType: type,
                dropdownIcon: true,
                onSelect: handleSelect
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                htmlFor: "empty-issue-input",
                className: "sr-only",
                children: "Empty issue input"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                ref: inputRef,
                autoFocus: true,
                type: "text",
                id: "empty-issue-input",
                placeholder: "What needs to be done?",
                className: " w-full pl-2 pr-20 text-sm focus:outline-none",
                value: name,
                onChange: (e)=>setName(e.currentTarget.value),
                onKeyDown: handleCreateIssue
            }),
            isCreating ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "absolute right-2 z-10",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_spinner__WEBPACK_IMPORTED_MODULE_5__/* .Spinner */ .$, {
                    size: "sm"
                })
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "absolute right-2 z-10 flex gap-x-1",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_4__/* .Button */ .z, {
                        className: "aspect-square shadow-md",
                        onClick: ()=>onCancel(),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_7__/* .MdClose */ .FU5, {
                            className: "text-sm"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_4__/* .Button */ .z, {
                        className: "aspect-square shadow-md",
                        onClick: ()=>onCreate({
                                name,
                                type,
                                parentId: parentId ?? null
                            }),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_7__/* .MdCheck */ .HhX, {
                            className: "text-sm"
                        })
                    })
                ]
            })
        ]
    });
};



/***/ }),

/***/ 27603:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   u: () => (/* binding */ IssueIcon)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(75484);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16775);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(75655);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _svgs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16206);






const Icon = ({ children, className })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_1___default()("rounded-sm  p-0.5 text-sm text-white", className),
        children: children
    });
};
const _SubTaskIcon = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
        className: "h-fit bg-task",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_svgs__WEBPACK_IMPORTED_MODULE_2__/* .SubTaskIcon */ .dv, {
            className: "text-white"
        })
    });
};
const TaskIcon = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
        className: "h-fit bg-task",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__/* .FaCheck */ .l_A, {
            className: " p-0.5 text-white"
        })
    });
};
const StoryIcon = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
        className: "h-fit bg-story",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__/* .BsBookmarkFill */ .vw0, {
            className: "p-0.5"
        })
    });
};
const BugIcon = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
        className: "h-fit bg-bug",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__/* .BsFillRecordFill */ .Z46, {})
    });
};
const EpicIcon = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
        className: "h-fit bg-epic",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_5__/* .HiLightningBolt */ .NNQ, {})
    });
};
const IssueIcon = ({ issueType })=>{
    if (issueType === "TASK") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TaskIcon, {});
    if (issueType === "STORY") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StoryIcon, {});
    if (issueType === "BUG") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BugIcon, {});
    if (issueType === "EPIC") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(EpicIcon, {});
    if (issueType === "SUBTASK") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SubTaskIcon, {});
    return null;
};



/***/ }),

/***/ 38620:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   L: () => (/* binding */ IssueContextMenu),
/* harmony export */   U: () => (/* binding */ IssueDropdownMenu)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hooks_query_hooks_use_issues__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14184);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(41772);
/* harmony import */ var _components_ui_context_menu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(72463);
/* harmony import */ var _hooks_use_is_authed__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(30660);






const menuOptions = {
    actions: [
        // ONLY DELETE IS IMPLEMENTED
        // { id: "add-flag", label: "Add Flag" },
        // { id: "change-parent", label: "Change Parent" },
        // { id: "copy-issue-link", label: "Copy Issue Link" },
        // { id: "split-issue", label: "Split Issue" },
        {
            id: "delete",
            label: "Delete"
        }
    ]
};
const IssueDropdownMenu = ({ children, issue })=>{
    const { deleteIssue, updateIssue } = (0,_hooks_query_hooks_use_issues__WEBPACK_IMPORTED_MODULE_1__/* .useIssues */ .g)();
    const [isAuthenticated, openAuthModal] = (0,_hooks_use_is_authed__WEBPACK_IMPORTED_MODULE_5__/* .useIsAuthenticated */ .k)();
    const handleIssueAction = (id, e, sprintId)=>{
        e.stopPropagation();
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        if (id == "delete") {
            deleteIssue({
                issueId: issue.id
            });
        }
        if (id == "move-to") {
            updateIssue({
                issueId: issue.id,
                sprintId
            });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__/* .Dropdown */ .Lt, {
        children: [
            children,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__/* .DropdownPortal */ .nI, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__/* .DropdownContent */ .Nv, {
                    side: "top",
                    sideOffset: 5,
                    align: "end",
                    className: "z-50 w-fit min-w-[100px] rounded-md border border-gray-300 bg-white pt-2 shadow-md",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__/* .DropdownLabel */ .HF, {
                            className: "p-2 text-xs font-normal text-gray-400",
                            children: "ACTIONS"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__/* .DropdownGroup */ .pb, {
                            children: menuOptions.actions.map((action)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__/* .DropdownItem */ .hP, {
                                    onClick: (e)=>handleIssueAction(action.id, e),
                                    textValue: action.label,
                                    className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("border-transparent p-2 text-sm hover:cursor-default hover:bg-gray-100"),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("pr-2 text-sm"),
                                        children: action.label
                                    })
                                }, action.id))
                        })
                    ]
                })
            })
        ]
    });
};
const IssueContextMenu = ({ children, isEditing, className })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        "data-state": isEditing ? "editing" : "not-editing",
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("flex [&[data-state=editing]]:hidden", className),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_context_menu__WEBPACK_IMPORTED_MODULE_4__/* .Context */ ._y, {
            children: [
                children,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_context_menu__WEBPACK_IMPORTED_MODULE_4__/* .ContextPortal */ .FI, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_context_menu__WEBPACK_IMPORTED_MODULE_4__/* .ContextContent */ .QT, {
                        className: "w-fit min-w-[100px] rounded-md border border-gray-300 bg-white pt-2 shadow-md",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_context_menu__WEBPACK_IMPORTED_MODULE_4__/* .ContextLabel */ .Fb, {
                                className: "p-2 text-xs font-normal text-gray-400",
                                children: "ACTIONS"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_context_menu__WEBPACK_IMPORTED_MODULE_4__/* .ContextGroup */ .c5, {
                                children: menuOptions.actions.map((action)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_context_menu__WEBPACK_IMPORTED_MODULE_4__/* .ContextItem */ .Ph, {
                                        textValue: action.label,
                                        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("border-transparent p-2 text-sm hover:cursor-default hover:bg-gray-100"),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("pr-2 text-sm"),
                                            children: action.label
                                        })
                                    }, action.id))
                            })
                        ]
                    })
                })
            ]
        })
    });
};



/***/ }),

/***/ 64844:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   G: () => (/* binding */ IssueAssigneeSelect)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_select__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(13785);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks_query_hooks_use_project__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5663);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _hooks_query_hooks_use_issues__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(14184);
/* harmony import */ var _avatar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(76628);
/* harmony import */ var _toast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(34825);
/* harmony import */ var _hooks_use_is_authed__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(30660);









const IssueAssigneeSelect = ({ issue, avatarSize, avatarOnly = false })=>{
    const { members } = (0,_hooks_query_hooks_use_project__WEBPACK_IMPORTED_MODULE_3__/* .useProject */ .P)();
    const { updateIssue, isUpdating } = (0,_hooks_query_hooks_use_issues__WEBPACK_IMPORTED_MODULE_5__/* .useIssues */ .g)();
    const [isAuthenticated, openAuthModal] = (0,_hooks_use_is_authed__WEBPACK_IMPORTED_MODULE_8__/* .useIsAuthenticated */ .k)();
    const unassigned = {
        id: "unassigned",
        name: "Unassigned",
        avatar: undefined,
        email: ""
    };
    const [selected, setSelected] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(issue.assignee?.id ?? null);
    function handleSelectChange(value) {
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        setSelected(value);
        updateIssue({
            issueId: issue.id,
            assigneeId: value === "unassigned" ? null : value
        }, {
            onSuccess: (data)=>{
                _toast__WEBPACK_IMPORTED_MODULE_7__.toast.success({
                    message: `Issue assignee updated to ${data.assignee?.name ?? "Unassigned"}`,
                    description: "Issue assignee changed"
                });
            }
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_select__WEBPACK_IMPORTED_MODULE_1__/* .Select */ .Ph, {
        onValueChange: handleSelectChange,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_1__/* .SelectTrigger */ .i4, {
                onClick: (e)=>e.stopPropagation(),
                disabled: isUpdating,
                className: clsx__WEBPACK_IMPORTED_MODULE_2___default()(avatarOnly ? "rounded-full transition-all duration-200 hover:brightness-75" : "-ml-2 rounded-[3px] py-1 pl-2 pr-8 hover:bg-gray-200", "flex w-fit items-center gap-x-1 whitespace-nowrap"),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_1__/* .SelectValue */ .ki, {
                    asChild: true,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_avatar__WEBPACK_IMPORTED_MODULE_6__/* .Avatar */ .q, {
                                size: avatarSize,
                                src: issue.assignee?.avatar,
                                alt: `${issue.assignee?.name ?? "Unassigned"}`
                            }),
                            avatarOnly ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "rounded-md bg-opacity-30 px-2 text-sm",
                                children: issue.assignee?.name ?? "Unassigned"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_1__/* .SelectPortal */ .ue, {
                className: "z-50 w-full",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_1__/* .SelectContent */ .Bw, {
                    position: "popper",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_1__/* .SelectViewport */ .Q_, {
                        className: "w-full rounded-md border border-gray-300 bg-white pt-2 shadow-md",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_1__/* .SelectGroup */ .DI, {
                            children: members && [
                                ...members,
                                unassigned
                            ].map((member)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_1__/* .SelectItem */ .Ql, {
                                    value: member.id,
                                    "data-state": member.id == selected ? "checked" : "unchecked",
                                    className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("border-l-[3px] border-transparent py-2 pl-2 pr-8 text-sm hover:cursor-default hover:border-blue-600 hover:bg-gray-100 focus:outline-none [&[data-state=checked]]:border-blue-600"),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_avatar__WEBPACK_IMPORTED_MODULE_6__/* .Avatar */ .q, {
                                                src: member?.avatar,
                                                alt: `${member?.name ?? "Unassigned"}`
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "rounded-md bg-opacity-30 px-2 text-sm",
                                                children: member.name
                                            })
                                        ]
                                    })
                                }, member.id))
                        })
                    })
                })
            })
        ]
    });
};



/***/ }),

/***/ 61803:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Jb: () => (/* binding */ statusMap),
/* harmony export */   ej: () => (/* binding */ IssueSelectStatus)
/* harmony export */ });
/* unused harmony export statuses */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks_query_hooks_use_issues__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14184);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(16775);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_not_implemented__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(14782);
/* harmony import */ var _utils_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(89602);
/* harmony import */ var _components_ui_select__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(13785);
/* harmony import */ var _hooks_use_is_authed__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(30660);









const statuses = [
    {
        value: "TODO",
        smBgColor: "#f5f5f5",
        lgBgColor: "#f5f5f5",
        smTextColor: "#383939",
        lgTextColor: "#383939"
    },
    {
        value: "IN_PROGRESS",
        smBgColor: "#e0ecfc",
        lgBgColor: "#0854cc",
        smTextColor: "#0854cc",
        lgTextColor: "#fff"
    },
    {
        value: "DONE",
        smBgColor: "#e8fcec",
        lgBgColor: "#08845c",
        smTextColor: "#08845c",
        lgTextColor: "#fff"
    }
];
const statusMap = {
    DONE: "DONE",
    IN_PROGRESS: "IN PROGRESS",
    TODO: "TO DO"
};
const IssueSelectStatus = ({ currentStatus, issueId, variant = "sm" })=>{
    const [selected, setSelected] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(()=>// eslint-disable-next-line @typescript-eslint/no-non-null-assertion
        statuses.find((status)=>status.value == currentStatus) ?? statuses[0]);
    const { updateIssue, isUpdating } = (0,_hooks_query_hooks_use_issues__WEBPACK_IMPORTED_MODULE_2__/* .useIssues */ .g)();
    const [isAuthenticated, openAuthModal] = (0,_hooks_use_is_authed__WEBPACK_IMPORTED_MODULE_6__/* .useIsAuthenticated */ .k)();
    function handleSelectChange(value) {
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
        const newStatus = statuses.find((status)=>status.value == value);
        updateIssue({
            issueId,
            status: value
        });
        setSelected(newStatus);
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_select__WEBPACK_IMPORTED_MODULE_5__/* .Select */ .Ph, {
            onValueChange: handleSelectChange,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_select__WEBPACK_IMPORTED_MODULE_5__/* .SelectTrigger */ .i4, {
                    onClick: (e)=>e.stopPropagation(),
                    disabled: isUpdating,
                    // TODO: Colors could be managed with data-state?
                    style: {
                        backgroundColor: variant == "sm" ? selected.smBgColor : selected.lgBgColor,
                        color: variant == "sm" ? selected.smTextColor : selected.lgTextColor
                    },
                    className: clsx__WEBPACK_IMPORTED_MODULE_3___default()(variant == "sm" && "bg-opacity-20 px-1.5 py-0.5 text-xs font-bold", variant == "lg" && "my-2 px-3 py-1.5 text-[16px] font-semibold", isUpdating && "cursor-not-allowed", "flex items-center gap-x-1 whitespace-nowrap rounded-[3px] focus:ring-2"),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_5__/* .SelectValue */ .ki, {
                            className: "w-full whitespace-nowrap bg-transparent text-white",
                            children: variant == "sm" ? statusMap[selected.value] : (0,_utils_helpers__WEBPACK_IMPORTED_MODULE_7__/* .capitalizeMany */ .bs)(statusMap[selected.value])
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_5__/* .SelectIcon */ .GV, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_8__/* .FaChevronDown */ .RiI, {
                                className: "text-xs"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_5__/* .SelectPortal */ .ue, {
                    className: "z-50",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_5__/* .SelectContent */ .Bw, {
                        position: "popper",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_select__WEBPACK_IMPORTED_MODULE_5__/* .SelectViewport */ .Q_, {
                            className: "w-60 rounded-md border border-gray-300 bg-white pt-2 shadow-md",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_5__/* .SelectGroup */ .DI, {
                                    children: statuses.map((status)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_5__/* .SelectItem */ .Ql, {
                                            value: status.value,
                                            "data-state": status.value == selected.value ? "checked" : "unchecked",
                                            className: clsx__WEBPACK_IMPORTED_MODULE_3___default()("border-l-[3px] border-transparent py-1 pl-2 text-sm hover:cursor-default hover:border-blue-600 hover:bg-gray-100 [&[data-state=checked]]:border-blue-600"),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                style: {
                                                    color: status.smTextColor
                                                },
                                                className: "rounded-md bg-opacity-30 px-2 text-xs font-semibold",
                                                children: statusMap[status.value]
                                            })
                                        }, status.value))
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_5__/* .SelectSeparator */ .U$, {
                                    className: "mt-2 h-[1px] bg-gray-300"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_not_implemented__WEBPACK_IMPORTED_MODULE_4__/* .NotImplemented */ .r, {
                                    feature: "workflow",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: "w-full border py-4 pl-5 text-left text-sm font-medium hover:cursor-default hover:bg-gray-100",
                                        children: "View Workflow"
                                    })
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });
};



/***/ }),

/***/ 8854:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ ISSUE_TYPES),
/* harmony export */   o: () => (/* binding */ IssueSelectType)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _issue_icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(27603);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16775);
/* harmony import */ var _components_ui_select__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(13785);
/* harmony import */ var _ui_tooltip__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45197);
/* harmony import */ var _utils_helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(89602);








const ISSUE_TYPES = [
    "STORY",
    "TASK",
    "BUG"
];
const SUBTASK_OPTIONS = [
    "SUBTASK"
];
const IssueSelectType = ({ currentType, dropdownIcon, onSelect })=>{
    const [selected, setSelected] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(currentType);
    function handleSelect(selected) {
        const _selected = selected;
        if (onSelect) {
            onSelect(_selected);
        }
        setSelected(_selected);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_select__WEBPACK_IMPORTED_MODULE_4__/* .Select */ .Ph, {
        onValueChange: handleSelect,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_tooltip__WEBPACK_IMPORTED_MODULE_5__/* .TooltipWrapper */ .pf, {
                text: `${(0,_utils_helpers__WEBPACK_IMPORTED_MODULE_6__/* .capitalize */ .kC)(selected)} - Change issue type`,
                side: "top",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_select__WEBPACK_IMPORTED_MODULE_4__/* .SelectTrigger */ .i4, {
                    className: "flex items-center gap-x-1 rounded-[3px] bg-opacity-30 p-1.5 text-xs font-semibold text-white hover:bg-gray-200 focus:ring-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_4__/* .SelectValue */ .ki, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_issue_icon__WEBPACK_IMPORTED_MODULE_3__/* .IssueIcon */ .u, {
                                issueType: selected
                            })
                        }),
                        dropdownIcon ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_4__/* .SelectIcon */ .GV, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_7__/* .FaChevronDown */ .RiI, {
                                className: "text-gray-500"
                            })
                        }) : null
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_4__/* .SelectPortal */ .ue, {
                className: "z-50",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_4__/* .SelectContent */ .Bw, {
                    position: "popper",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_select__WEBPACK_IMPORTED_MODULE_4__/* .SelectViewport */ .Q_, {
                        className: "w-52 rounded-md border border-gray-300 bg-white py-2 shadow-md",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "pl-3 text-xs text-gray-500",
                                children: "CHANGE ISSUE TYPE"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_4__/* .SelectGroup */ .DI, {
                                children: (currentType === "SUBTASK" ? SUBTASK_OPTIONS : ISSUE_TYPES).map((type)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_select__WEBPACK_IMPORTED_MODULE_4__/* .SelectItem */ .Ql, {
                                        value: type,
                                        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("border-transparent py-2 pl-3 text-sm hover:cursor-default hover:bg-gray-50"),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_issue_icon__WEBPACK_IMPORTED_MODULE_3__/* .IssueIcon */ .u, {
                                                    issueType: type
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("px-2 text-xs"),
                                                    children: type
                                                })
                                            ]
                                        })
                                    }, type))
                            })
                        ]
                    })
                })
            })
        ]
    });
};



/***/ }),

/***/ 14389:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   N: () => (/* binding */ CountBall),
/* harmony export */   _: () => (/* binding */ IssueStatusCount)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(89602);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* __next_internal_client_entry_do_not_use__ IssueStatusCount,CountBall auto */ 



const IssueStatusCount = ({ issues })=>{
    const memoizedCount = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(_utils_helpers__WEBPACK_IMPORTED_MODULE_3__/* .getIssueCountByStatus */ .Z, []);
    const [statusCount, setStatusCount] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(()=>memoizedCount(issues ?? []));
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        setStatusCount(()=>memoizedCount(issues ?? []));
    }, [
        issues,
        memoizedCount
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
        children: Object.entries(statusCount ?? {})?.map(([status, count])=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CountBall, {
                count: count,
                className: clsx__WEBPACK_IMPORTED_MODULE_1___default()(status == "TODO" && "bg-todo text-black", status == "IN_PROGRESS" && "bg-inprogress text-white", status == "DONE" && "bg-done text-white")
            }, status))
    });
};
const CountBall = ({ count, className, hideOnZero = false })=>{
    if (hideOnZero && count === 0) return null;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        className: clsx__WEBPACK_IMPORTED_MODULE_1___default()("flex h-4 w-fit items-center justify-center rounded-full px-2 text-xs font-semibold", className),
        children: count
    });
};



/***/ }),

/***/ 38698:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   w: () => (/* binding */ IssueTitle)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks_query_hooks_use_issues__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14184);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(38546);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(64348);
/* harmony import */ var _ui_tooltip__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(45197);
/* harmony import */ var _hooks_use_is_authed__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(30660);







const IssueTitle = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ isEditing, setIsEditing, issue, className, useTooltip }, ref)=>{
    const [currentTitle, setCurrentTitle] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(issue.name);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isEditing) {
            ref.current?.focus();
        }
    }, [
        isEditing,
        ref
    ]);
    const { updateIssue } = (0,_hooks_query_hooks_use_issues__WEBPACK_IMPORTED_MODULE_2__/* .useIssues */ .g)();
    const [isAuthenticated, openAuthModal] = (0,_hooks_use_is_authed__WEBPACK_IMPORTED_MODULE_5__/* .useIsAuthenticated */ .k)();
    function handleNameChange(e) {
        e.stopPropagation();
        e.preventDefault();
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        updateIssue({
            issueId: issue.id,
            name: currentTitle
        });
        setIsEditing(false);
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: isEditing ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "relative flex w-full",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                    htmlFor: "issue-title",
                    className: "sr-only",
                    children: "Issue title"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    type: "text",
                    ref: ref,
                    id: "issue-title",
                    value: currentTitle,
                    onChange: (e)=>setCurrentTitle(e.target.value),
                    className: "w-full min-w-max whitespace-pre-wrap px-1 py-1.5 outline-2 outline-blue-400",
                    onKeyDown: (e)=>{
                        if (e.key === "Enter") {
                            handleNameChange(e);
                        }
                        if (e.key === "Escape") {
                            setIsEditing(false);
                        }
                    }
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "absolute -bottom-10 right-0 z-10 flex gap-x-1",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_3__/* .Button */ .z, {
                            className: "mt-2 aspect-square bg-gray-50 p-2.5 shadow-md transition-all hover:bg-gray-100",
                            onClick: (e)=>{
                                e.stopPropagation();
                                setIsEditing(false);
                            },
                            customColors: true,
                            customPadding: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_6__/* .MdClose */ .FU5, {
                                className: "text-sm"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_3__/* .Button */ .z, {
                            className: "mt-2 aspect-square bg-gray-50 p-2.5 shadow-md transition-all hover:bg-gray-100",
                            onClick: handleNameChange,
                            customColors: true,
                            customPadding: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_6__/* .MdCheck */ .HhX, {
                                className: "text-sm"
                            })
                        })
                    ]
                })
            ]
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full overflow-x-hidden",
            children: useTooltip ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_tooltip__WEBPACK_IMPORTED_MODULE_4__/* .TooltipWrapper */ .pf, {
                text: issue.name,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: className,
                    children: issue.name
                })
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: className,
                children: issue.name
            })
        })
    });
});
IssueTitle.displayName = "IssueTitle";



/***/ }),

/***/ 5801:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   i: () => (/* binding */ Members)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _context_use_filters_context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57165);
/* harmony import */ var _hooks_query_hooks_use_project__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5663);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(38546);
/* harmony import */ var _avatar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(76628);
/* harmony import */ var _not_implemented__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(14782);
/* harmony import */ var _svgs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(16206);







const Members = ()=>{
    const { members } = (0,_hooks_query_hooks_use_project__WEBPACK_IMPORTED_MODULE_2__/* .useProject */ .P)();
    const { assignees, setAssignees } = (0,_context_use_filters_context__WEBPACK_IMPORTED_MODULE_1__/* .useFiltersContext */ .P)();
    const unassigned = {
        id: "unassigned",
        name: "Unassigned",
        avatar: undefined,
        email: ""
    };
    function handleAssigneeFilter(id) {
        setAssignees((prev)=>{
            if (prev.includes(id)) return prev.filter((a)=>a !== id);
            return [
                ...prev,
                id
            ];
        });
    }
    if (!members) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {});
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex items-center",
        children: [
            [
                ...members,
                unassigned
            ].map((member, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    style: {
                        zIndex: 10 - index
                    },
                    className: "hover:!z-10",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_3__/* .Button */ .z, {
                        onClick: ()=>handleAssigneeFilter(member.id),
                        customColors: true,
                        customPadding: true,
                        "data-state": assignees.includes(member.id) ? "selected" : "not-selected",
                        className: "-mx-1 flex border-spacing-2 rounded-full border-2 border-transparent bg-white p-0.5 transition-all duration-75 hover:-mt-1.5 [&[data-state=selected]]:border-inprogress",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_avatar__WEBPACK_IMPORTED_MODULE_4__/* .Avatar */ .q, {
                            src: member.avatar,
                            alt: `${member.name}`
                        })
                    })
                }, member.id);
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_not_implemented__WEBPACK_IMPORTED_MODULE_5__/* .NotImplemented */ .r, {
                feature: "add people",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_svgs__WEBPACK_IMPORTED_MODULE_6__/* .AddPeopleIcon */ .Xk, {
                        className: "ml-3 rounded-full bg-gray-200 p-1 text-gray-500",
                        size: 35
                    })
                })
            })
        ]
    });
};



/***/ }),

/***/ 14782:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  r: () => (/* binding */ NotImplemented)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-popover/dist/index.js
var dist = __webpack_require__(12088);
;// CONCATENATED MODULE: ./components/ui/pop-over.tsx



const Popover = dist.Root;
const PopoverTrigger = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Trigger, {
        className: className,
        ...props,
        ref: forwardedRef,
        children: children
    }));
PopoverTrigger.displayName = "PopoverTrigger";
const PopoverAnchor = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Anchor, {
        className: className,
        ...props,
        ref: forwardedRef,
        children: children
    }));
PopoverAnchor.displayName = "PopoverAnchor";
const PopoverPortal = ({ children, className, ...props })=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Portal, {
        className: className,
        ...props,
        children: children
    });
PopoverPortal.displayName = "PopoverPortal";
const PopoverContent = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Content, {
        className: className,
        ...props,
        ref: forwardedRef,
        children: children
    }));
PopoverContent.displayName = "PopoverContent";
const PopoverClose = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Close, {
        className: className,
        ...props,
        ref: forwardedRef,
        children: children
    }));
PopoverClose.displayName = "PopoverClose";
const PopoverArrow = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Arrow, {
        className: className,
        ...props,
        ref: forwardedRef,
        children: children
    }));
PopoverArrow.displayName = "PopoverArrow";


// EXTERNAL MODULE: ./node_modules/react-icons/ai/index.esm.js
var index_esm = __webpack_require__(19722);
;// CONCATENATED MODULE: ./components/not-implemented.tsx



const NotImplemented = ({ children, feature })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Popover, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(PopoverTrigger, {
                asChild: true,
                className: " hover:cursor-not-allowed",
                onClick: (e)=>e.stopPropagation(),
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(PopoverPortal, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(PopoverContent, {
                    className: "z-50",
                    side: "left",
                    align: "end",
                    sideOffset: 5,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "rounded-md border-2 bg-white px-6 py-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-sm font-semibold",
                                children: "Not implemented"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "max-w-32 flex text-xs text-gray-500",
                                children: feature ? `This is a simplified Jira Clone. The ${feature} feature is not implemented.` : "This is a simplified Jira Clone. This feature is not implemented."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mt-2 flex items-center gap-x-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* AiFillGithub */.RrF, {
                                        className: "text-2xl"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-sm",
                                        children: "Find the repo "
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://github.com/sebastianfdz/jira_clone",
                                        target: "_blank",
                                        className: "text-sm font-semibold text-blue-600 hover:underline",
                                        children: "here"
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
};



/***/ }),

/***/ 40796:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   k: () => (/* binding */ ProgressBar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(89602);
/* harmony import */ var _components_ui_tooltip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45197);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);





const ProgressBar = ({ issues, variant = "lg" })=>{
    const memoizedCount = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(_utils_helpers__WEBPACK_IMPORTED_MODULE_4__/* .getIssueCountByStatus */ .Z, []);
    const [statusCount, setStatusCount] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(()=>memoizedCount(issues ?? []));
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setStatusCount(()=>memoizedCount(issues ?? []));
    }, [
        issues,
        memoizedCount
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex items-center gap-x-5",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: {
                    width: "100%"
                },
                className: clsx__WEBPACK_IMPORTED_MODULE_3___default()(variant === "sm" ? "h-1" : "h-2.5", "flex  gap-x-0.5 overflow-hidden rounded-full bg-white"),
                children: [
                    statusCount.DONE ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_tooltip__WEBPACK_IMPORTED_MODULE_2__/* .TooltipWrapper */ .pf, {
                        text: `Done: ${statusCount.DONE} of ${issues.length} issues`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: {
                                width: `${statusCount.DONE / issues.length * 100}%`
                            },
                            className: "float-left h-full bg-done"
                        })
                    }) : null,
                    statusCount.IN_PROGRESS ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_tooltip__WEBPACK_IMPORTED_MODULE_2__/* .TooltipWrapper */ .pf, {
                        text: `In Progress: ${statusCount.IN_PROGRESS} of ${issues.length} issues`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: {
                                width: `${statusCount.IN_PROGRESS / issues.length * 100}%`
                            },
                            className: "float-left h-full bg-inprogress"
                        })
                    }) : null,
                    statusCount.TODO ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_tooltip__WEBPACK_IMPORTED_MODULE_2__/* .TooltipWrapper */ .pf, {
                        text: `To Do: ${statusCount.TODO} of ${issues.length} issues`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: {
                                width: `${statusCount.TODO / issues.length * 100}%`
                            },
                            className: "float-left h-full bg-todo"
                        })
                    }) : null
                ]
            }),
            variant === "lg" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "whitespace-nowrap text-sm text-gray-500",
                children: [
                    (statusCount.DONE / issues.length * 100).toFixed(0),
                    "% Done"
                ]
            }) : null
        ]
    });
};



/***/ }),

/***/ 16206:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Bk: () => (/* binding */ LightningIcon),
/* harmony export */   JK: () => (/* binding */ DevelopmentIcon),
/* harmony export */   Lq: () => (/* binding */ BoardIcon),
/* harmony export */   Mi: () => (/* binding */ BacklogIcon),
/* harmony export */   Qe: () => (/* binding */ RoadmapIcon),
/* harmony export */   SW: () => (/* binding */ SprintTrophy),
/* harmony export */   Xk: () => (/* binding */ AddPeopleIcon),
/* harmony export */   dv: () => (/* binding */ SubTaskIcon),
/* harmony export */   eS: () => (/* binding */ ChildrenTreeIcon),
/* harmony export */   lP: () => (/* binding */ UnassignedUser)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);


const ChildrenTreeIcon = ({ className })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        className: clsx__WEBPACK_IMPORTED_MODULE_1___default()("h-5 w-5", className),
        viewBox: "0 0 24 24",
        role: "presentation",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
            fill: "currentColor",
            fillRule: "evenodd",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M11 7h2v5h-2zm5 6h2v3h-2zM6 13h2v3H6z"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M7 11h10a1 1 0 011 1v1H6v-1a1 1 0 011-1z"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M5 18v1h4v-1H5zm0-2h4a2 2 0 012 2v1a2 2 0 01-2 2H5a2 2 0 01-2-2v-1a2 2 0 012-2zm10 2v1h4v-1h-4zm0-2h4a2 2 0 012 2v1a2 2 0 01-2 2h-4a2 2 0 01-2-2v-1a2 2 0 012-2zM10 5v1h4V5h-4zm0-2h4a2 2 0 012 2v1a2 2 0 01-2 2h-4a2 2 0 01-2-2V5a2 2 0 012-2z",
                    fillRule: "nonzero"
                })
            ]
        })
    });
};
const BoardIcon = ({ className, size })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        className: className,
        width: size ?? 24,
        height: size ?? 24,
        viewBox: "0 0 24 24",
        role: "presentation",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
            fill: "currentColor",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M4 18h16.008C20 18 20 6 20 6H3.992C4 6 4 18 4 18zM2 5.994C2 4.893 2.898 4 3.99 4h16.02C21.108 4 22 4.895 22 5.994v12.012A1.997 1.997 0 0120.01 20H3.99A1.994 1.994 0 012 18.006V5.994z"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M8 6v12h2V6zm6 0v12h2V6z"
                })
            ]
        })
    });
};
const BacklogIcon = ({ className, size })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        className: className,
        width: size ?? 24,
        height: size ?? 24,
        viewBox: "0 0 24 24",
        role: "presentation",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
            fill: "currentColor",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M5 19.002C5 19 17 19 17 19v-2.002C17 17 5 17 5 17v2.002zm-2-2.004C3 15.894 3.895 15 4.994 15h12.012c1.101 0 1.994.898 1.994 1.998v2.004A1.997 1.997 0 0117.006 21H4.994A1.998 1.998 0 013 19.002v-2.004z"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M5 15h12v-2H5v2zm-2-4h16v6H3v-6z"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M7 11.002C7 11 19 11 19 11V8.998C19 9 7 9 7 9v2.002zM5 8.998C5 7.894 5.895 7 6.994 7h12.012C20.107 7 21 7.898 21 8.998v2.004A1.997 1.997 0 0119.006 13H6.994A1.998 1.998 0 015 11.002V8.998z"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M5 5v2h12V5H5zm-2-.002C3 3.894 3.895 3 4.994 3h12.012C18.107 3 19 3.898 19 4.998V9H3V4.998z"
                })
            ]
        })
    });
};
const RoadmapIcon = ({ className, size })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        className: className,
        width: size ?? 24,
        height: size ?? 24,
        viewBox: "0 0 24 24",
        role: "presentation",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M6 2h10a3 3 0 010 6H6a3 3 0 110-6zm0 2a1 1 0 100 2h10a1 1 0 000-2H6zm4 5h8a3 3 0 010 6h-8a3 3 0 010-6zm0 2a1 1 0 000 2h8a1 1 0 000-2h-8zm-4 5h6a3 3 0 010 6H6a3 3 0 010-6zm0 2a1 1 0 000 2h6a1 1 0 000-2H6z",
            fill: "currentColor",
            fillRule: "evenodd"
        })
    });
};
const LightningIcon = ({ className, size })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        role: "presentation",
        className: className,
        width: size ?? 24,
        height: size ?? 24,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M10.3789 4.62256C9.99914 4.62173 9.65331 4.84087 9.49192 5.18458L6.11523 12.3762C5.97308 12.679 5.9956 13.0334 6.17494 13.3157C6.35428 13.598 6.66553 13.7691 7 13.7691H8.79182L6.40251 18.1304C6.17135 18.5523 6.28163 19.0798 6.66249 19.3738C7.04335 19.6677 7.58152 19.6408 7.93117 19.3103L16.8269 10.902C17.1178 10.6269 17.2117 10.2023 17.0637 9.83032C16.9157 9.45832 16.5558 9.21418 16.1555 9.21418H14.547L17.0353 6.24031C17.2787 5.94947 17.3319 5.5441 17.1717 5.20034C17.0116 4.85658 16.6671 4.63646 16.2879 4.63562L10.3789 4.62256Z",
            stroke: "currentColor",
            strokeWidth: "1.95489",
            strokeLinejoin: "round"
        })
    });
};
const DevelopmentIcon = ({ className, size })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        className: className,
        width: size ?? 24,
        height: size ?? 24,
        viewBox: "0 0 24 24",
        role: "presentation",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M14.155 4.055a1 1 0 00-1.271.62l-4.83 14.046a1 1 0 001.891.65l4.83-14.045a1 1 0 00-.62-1.271m-6.138 8.21l-2.58-2.501L8.236 7.05a.999.999 0 10-1.392-1.436l-3.54 3.432a1 1 0 000 1.436l3.32 3.219a1 1 0 101.393-1.436m12.219 1.568l-3.32-3.22a.999.999 0 10-1.393 1.437l2.58 2.5-2.799 2.715a.999.999 0 101.392 1.436l3.54-3.432a1 1 0 000-1.436",
            fill: "currentColor",
            fillRule: "evenodd"
        })
    });
};
const SprintTrophy = ({ className, size })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        className: className,
        width: size ?? 540,
        height: "140",
        viewBox: "0 0 540 140",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                width: "540",
                height: "120",
                fill: "white",
                fillOpacity: "0.01"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M540 0H0V120H540V0Z",
                fill: "#00C7E5"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                opacity: "0.7",
                d: "M0 67.2222H540V26.2778C511.369 28.3778 486.056 28.7778 464.231 28.3667C373.331 26.6444 305.916 10.1111 221.766 0H0V67.2222Z",
                fill: "url(#paint0_linear_1123_201949)"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                opacity: "0.6",
                d: "M0 117.889H540V49.8111C453.094 36.6778 375.666 20.8333 260.972 40.2889C180.619 53.9222 98.7469 82.0333 1.88437 63.5333C1.26562 63.4111 0.61875 63.2889 0 63.1667V117.889Z",
                fill: "url(#paint1_linear_1123_201949)"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                opacity: "0.6",
                d: "M540 73.2444C418.922 89.3111 321.834 116.556 158.4 114.056C95.625 113.1 41.5406 108.033 0 102.667V120H540V73.2444Z",
                fill: "url(#paint2_linear_1123_201949)"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                width: "97.0213",
                height: "80",
                transform: "translate(222 60)",
                fill: "white",
                fillOpacity: "0.01"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M239.617 109.234C240.209 111.087 241.247 112.768 242.638 114.128C242.731 114.224 242.849 114.293 242.979 114.326C243.109 114.359 243.245 114.356 243.373 114.316C243.501 114.277 243.616 114.202 243.704 114.101C243.792 114 243.85 113.877 243.872 113.745C244.33 111.855 244.316 109.882 243.83 108C243.283 106.259 242.336 104.67 241.064 103.362C240.952 103.227 240.803 103.129 240.636 103.078C240.468 103.027 240.29 103.027 240.122 103.077C239.955 103.127 239.805 103.225 239.693 103.358C239.58 103.492 239.51 103.656 239.489 103.83C239.109 105.617 239.153 107.467 239.617 109.234V109.234Z",
                fill: "#0065FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M232.596 94.7234C232.24 95.9733 232.225 97.2957 232.553 98.5532C232.565 98.6414 232.601 98.7244 232.659 98.7926C232.716 98.8607 232.791 98.9111 232.876 98.9379C232.961 98.9647 233.052 98.9668 233.138 98.9439C233.224 98.9209 233.301 98.874 233.362 98.8085C234.276 97.8966 234.974 96.7915 235.404 95.5744C235.706 94.4053 235.736 93.1822 235.489 92C235.362 91.4468 234.851 91.2766 234.468 91.7021C233.607 92.5411 232.964 93.5785 232.596 94.7234V94.7234Z",
                fill: "#3384FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M231.191 86.6383C230.938 87.8325 230.754 89.0401 230.638 90.2553C230.525 91.5036 230.44 92.7376 230.383 93.9575C230.326 96.3943 230.73 98.8199 231.574 101.106C232.36 103.429 233.432 105.645 234.766 107.702C235.404 108.766 236.128 109.745 236.851 110.723C237.574 111.702 238.468 112.553 239.319 113.404C242.839 116.808 247.027 119.444 251.617 121.149C253.905 122.042 256.269 122.726 258.681 123.192C259.875 123.455 261.082 123.654 262.298 123.787L264.085 123.957H265.872C266.001 123.952 266.129 123.971 266.25 124.015C266.371 124.059 266.482 124.127 266.577 124.214C266.672 124.301 266.749 124.406 266.803 124.522C266.857 124.639 266.888 124.765 266.894 124.894C266.894 125.15 266.799 125.398 266.625 125.587C266.452 125.777 266.213 125.894 265.957 125.915H265.915L263.957 125.83L262.042 125.617C260.766 125.447 259.532 125.192 258.298 124.936C255.808 124.39 253.373 123.621 251.021 122.638C246.264 120.782 241.946 117.956 238.34 114.34C237.45 113.436 236.625 112.469 235.872 111.447C235.086 110.442 234.362 109.39 233.702 108.298C232.396 106.126 231.34 103.813 230.553 101.404C230.167 100.208 229.869 98.9845 229.66 97.7447C229.497 96.475 229.44 95.194 229.489 93.9149C229.532 92.6383 229.66 91.4043 229.787 90.1702C229.915 88.9362 229.957 88.8936 230.085 88.2979C230.172 87.6661 230.3 87.0406 230.468 86.4256C230.478 86.3746 230.498 86.3263 230.528 86.2834C230.557 86.2406 230.594 86.2041 230.638 86.1763C230.682 86.1484 230.731 86.1297 230.782 86.1214C230.833 86.113 230.886 86.1152 230.936 86.1277C231.026 86.1649 231.1 86.2317 231.146 86.3168C231.193 86.4019 231.209 86.5003 231.191 86.5958V86.6383Z",
                fill: "url(#paint3_linear_1123_201949)"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M308.425 94.7234C308.76 95.9763 308.775 97.2931 308.468 98.5532C308.456 98.6414 308.42 98.7244 308.363 98.7926C308.305 98.8607 308.23 98.9111 308.145 98.9379C308.06 98.9647 307.969 98.9668 307.883 98.9439C307.797 98.9209 307.72 98.874 307.66 98.8085C306.731 97.9083 306.031 96.7996 305.617 95.5744C305.315 94.4053 305.286 93.1822 305.532 92C305.66 91.4468 306.17 91.2766 306.553 91.7021C307.415 92.5411 308.058 93.5785 308.425 94.7234V94.7234Z",
                fill: "#3384FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M310.553 86.4256C310.723 87.0639 310.809 87.6596 310.936 88.2979C311.064 88.9362 311.149 89.5319 311.192 90.1702C311.37 91.4117 311.484 92.6616 311.532 93.9149C311.581 95.194 311.524 96.475 311.362 97.7447C311.154 98.9989 310.856 100.236 310.468 101.447C309.681 103.856 308.625 106.168 307.319 108.34C306.638 109.447 305.915 110.468 305.149 111.489C304.383 112.501 303.559 113.467 302.681 114.383C299.075 117.999 294.757 120.824 290 122.681C287.646 123.657 285.211 124.426 282.723 124.979C281.489 125.234 280.255 125.489 278.979 125.66L277.064 125.872L275.106 125.957C274.843 125.946 274.594 125.834 274.412 125.644C274.229 125.453 274.127 125.2 274.128 124.936C274.127 124.806 274.154 124.677 274.206 124.557C274.258 124.438 274.335 124.33 274.431 124.242C274.527 124.154 274.641 124.087 274.765 124.045C274.888 124.004 275.019 123.988 275.149 124H276.936L278.723 123.83C279.939 123.697 281.146 123.498 282.34 123.234C284.752 122.768 287.116 122.084 289.404 121.192C293.994 119.487 298.182 116.85 301.702 113.447C302.553 112.596 303.362 111.702 304.128 110.766C304.899 109.804 305.61 108.795 306.255 107.745C307.589 105.687 308.661 103.472 309.447 101.149C309.863 100.002 310.176 98.8198 310.383 97.617C310.582 96.4223 310.653 95.2098 310.596 94C310.589 92.7631 310.517 91.5275 310.383 90.2979C310.267 89.0827 310.083 87.8751 309.83 86.6809V86.6809C309.817 86.6305 309.815 86.5781 309.824 86.5269C309.832 86.4757 309.851 86.4268 309.878 86.383C309.906 86.3392 309.943 86.3015 309.986 86.2723C310.028 86.243 310.077 86.2228 310.128 86.2128C310.212 86.1951 310.3 86.2065 310.378 86.2451C310.455 86.2837 310.517 86.3473 310.553 86.4256V86.4256Z",
                fill: "url(#paint4_linear_1123_201949)"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M301.277 109.234C300.654 111.083 299.604 112.76 298.213 114.128C298.125 114.228 298.01 114.301 297.882 114.337C297.754 114.372 297.618 114.37 297.491 114.329C297.364 114.288 297.252 114.211 297.168 114.107C297.085 114.003 297.034 113.877 297.021 113.745C296.541 111.858 296.556 109.879 297.064 108C297.593 106.251 298.543 104.659 299.83 103.362C299.935 103.221 300.08 103.117 300.247 103.062C300.413 103.008 300.593 103.006 300.76 103.057C300.928 103.108 301.076 103.21 301.183 103.348C301.291 103.487 301.353 103.655 301.362 103.83C301.779 105.611 301.75 107.467 301.277 109.234V109.234Z",
                fill: "#0065FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M301.702 108C301.058 108.062 300.409 107.988 299.796 107.785C299.182 107.581 298.618 107.251 298.139 106.816C297.661 106.381 297.278 105.851 297.017 105.26C296.755 104.669 296.62 104.029 296.62 103.383C296.62 102.736 296.755 102.097 297.017 101.506C297.278 100.915 297.661 100.385 298.139 99.9499C298.618 99.5151 299.182 99.1852 299.796 98.9814C300.409 98.7775 301.058 98.7041 301.702 98.7659H302.34C304.269 98.8716 306.2 98.5829 308.013 97.9175C309.827 97.252 311.486 96.2238 312.889 94.8956C314.292 93.5674 315.409 91.9672 316.173 90.1926C316.937 88.418 317.331 86.5064 317.331 84.5745C317.331 82.6425 316.937 80.7309 316.173 78.9563C315.409 77.1818 314.292 75.5815 312.889 74.2533C311.486 72.9251 309.827 71.8969 308.013 71.2315C306.2 70.566 304.269 70.2773 302.34 70.383C300.822 70.3809 299.313 70.6252 297.872 71.1064",
                stroke: "#FFC400",
                strokeWidth: "3.26383",
                strokeMiterlimit: "10",
                strokeLinecap: "round"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M239.319 108C239.963 108.062 240.612 107.988 241.226 107.785C241.839 107.581 242.403 107.251 242.882 106.816C243.36 106.381 243.743 105.851 244.004 105.26C244.266 104.669 244.401 104.029 244.401 103.383C244.401 102.736 244.266 102.097 244.004 101.506C243.743 100.915 243.36 100.385 242.882 99.9499C242.403 99.5151 241.839 99.1852 241.226 98.9814C240.612 98.7775 239.963 98.7041 239.319 98.7659H238.681C236.752 98.8716 234.822 98.5829 233.008 97.9175C231.194 97.252 229.535 96.2238 228.132 94.8956C226.729 93.5674 225.612 91.9672 224.848 90.1926C224.085 88.418 223.691 86.5064 223.691 84.5745C223.691 82.6425 224.085 80.7309 224.848 78.9563C225.612 77.1818 226.729 75.5815 228.132 74.2533C229.535 72.9251 231.194 71.8969 233.008 71.2315C234.822 70.566 236.752 70.2773 238.681 70.383C240.186 70.381 241.681 70.6254 243.106 71.1064",
                stroke: "#FFC400",
                strokeWidth: "3.26383",
                strokeMiterlimit: "10",
                strokeLinecap: "round"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M272.511 124.979C272.511 127.913 273.676 130.727 275.751 132.802C277.826 134.877 280.64 136.043 283.574 136.043H257.745C260.302 136.043 262.781 135.156 264.759 133.535C266.737 131.913 268.092 129.657 268.594 127.148C269.095 124.64 268.712 122.036 267.51 119.779C266.308 117.521 264.361 115.75 262 114.766C261.382 114.496 260.741 114.283 260.085 114.128C255.243 112.452 250.868 109.652 247.319 105.957C243.769 102.261 241.148 97.7765 239.669 92.8709C238.19 87.9653 237.897 82.7788 238.812 77.7377C239.728 72.6965 241.827 67.9446 244.936 63.8723H296.383C299.484 67.9448 301.577 72.6936 302.49 77.7301C303.403 82.7667 303.111 87.9479 301.638 92.8499C300.164 97.7519 297.551 102.235 294.012 105.934C290.473 109.632 286.109 112.44 281.277 114.128C280.617 114.269 279.975 114.484 279.362 114.766C277.331 115.59 275.593 117.003 274.372 118.823C273.151 120.643 272.503 122.787 272.511 124.979V124.979Z",
                fill: "url(#paint5_linear_1123_201949)"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M296.383 60H244.894V63.8936H296.383V60Z",
                fill: "#FF991F"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M284.298 136.043H257.277V139.936H284.298V136.043Z",
                fill: "#FF991F"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M308.17 117.745C306.288 118.294 304.3 118.367 302.383 117.957C302.25 117.945 302.124 117.894 302.02 117.81C301.917 117.727 301.839 117.615 301.799 117.488C301.758 117.361 301.755 117.225 301.791 117.097C301.827 116.968 301.899 116.853 302 116.766C303.314 115.32 304.966 114.223 306.808 113.574C308.542 113.024 310.386 112.921 312.17 113.277C312.349 113.277 312.523 113.333 312.668 113.437C312.813 113.542 312.921 113.689 312.978 113.859C313.034 114.028 313.036 114.211 312.982 114.381C312.929 114.552 312.824 114.701 312.681 114.808C311.427 116.126 309.882 117.131 308.17 117.745V117.745Z",
                fill: "#0065FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M312.766 109.745C311.561 110.632 310.159 111.216 308.681 111.447C308.17 111.489 307.872 111.106 308.085 110.681C308.638 109.291 309.53 108.062 310.681 107.106C311.788 106.259 313.09 105.703 314.468 105.489C314.599 105.429 314.746 105.414 314.886 105.448C315.026 105.482 315.15 105.562 315.239 105.675C315.328 105.789 315.375 105.929 315.374 106.072C315.374 106.216 315.324 106.356 315.234 106.468C314.688 107.743 313.841 108.868 312.766 109.745V109.745Z",
                fill: "#0065FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M315.957 102.298C314.861 103.324 313.532 104.069 312.085 104.468C311.99 104.514 311.883 104.528 311.779 104.511C311.675 104.493 311.579 104.443 311.504 104.368C311.429 104.294 311.38 104.198 311.362 104.094C311.344 103.99 311.359 103.883 311.404 103.787C311.785 102.341 312.516 101.011 313.532 99.9149C314.552 98.9512 315.773 98.2247 317.106 97.7872C317.231 97.7338 317.37 97.7191 317.503 97.7448C317.636 97.7706 317.759 97.8358 317.855 97.9319C317.951 98.028 318.017 98.1507 318.042 98.2842C318.068 98.4177 318.053 98.5558 318 98.6809C317.608 100.028 316.909 101.267 315.957 102.298Z",
                fill: "#3384FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M313.574 84.9787C313.535 85.8403 313.271 86.6766 312.808 87.4043C312.638 87.6596 312.383 87.6596 312.255 87.4043C311.838 86.635 311.632 85.7685 311.66 84.8936C311.693 84.0831 311.926 83.2934 312.34 82.5958C312.371 82.5219 312.423 82.4593 312.491 82.4168C312.558 82.3742 312.638 82.3539 312.717 82.3586C312.797 82.3633 312.873 82.3927 312.935 82.4429C312.998 82.4931 313.042 82.5614 313.064 82.6383C313.416 83.3675 313.591 84.1693 313.574 84.9787V84.9787Z",
                fill: "#66A3FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M308.213 88.9787C308.708 89.7318 309.014 90.5929 309.106 91.4894C309.132 91.5511 309.136 91.6195 309.117 91.6837C309.099 91.7479 309.06 91.8042 309.006 91.8434C308.952 91.8826 308.886 91.9026 308.82 91.9002C308.753 91.8977 308.689 91.8729 308.638 91.8298C307.822 91.4491 307.107 90.8803 306.553 90.1702C306.062 89.4623 305.755 88.6434 305.66 87.7872C305.648 87.7078 305.66 87.6269 305.693 87.5538C305.725 87.4806 305.778 87.4182 305.845 87.3737C305.912 87.3292 305.989 87.3045 306.07 87.3024C306.15 87.3003 306.229 87.3208 306.298 87.3617C307.054 87.7432 307.71 88.2971 308.213 88.9787V88.9787Z",
                fill: "#66A3FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M308.383 85.1915C308.784 85.8237 309.046 86.5348 309.149 87.2766C309.154 87.3292 309.145 87.3823 309.123 87.4304C309.101 87.4784 309.067 87.5198 309.023 87.5501C308.98 87.5804 308.929 87.5987 308.877 87.603C308.824 87.6072 308.771 87.5974 308.723 87.5745C308.063 87.2316 307.483 86.7531 307.021 86.1702C306.628 85.6039 306.393 84.9429 306.34 84.2553C306.298 83.9149 306.553 83.7447 306.808 83.9149C307.43 84.2045 307.971 84.643 308.383 85.1915Z",
                fill: "#99C1FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M309.745 81.7872C309.97 82.5902 310.014 83.4333 309.872 84.2553C309.866 84.3113 309.843 84.3641 309.807 84.4078C309.772 84.4514 309.724 84.4841 309.671 84.5019C309.617 84.5197 309.56 84.522 309.505 84.5085C309.45 84.495 309.401 84.4662 309.362 84.4255C308.74 83.8812 308.258 83.1952 307.957 82.4255C307.719 81.684 307.66 80.8962 307.787 80.1277C307.774 80.0475 307.789 79.9652 307.831 79.8955C307.873 79.8259 307.938 79.7734 308.015 79.7478C308.092 79.7221 308.176 79.7248 308.251 79.7554C308.327 79.7861 308.388 79.8426 308.426 79.9149C309 80.432 309.451 81.072 309.745 81.7872V81.7872Z",
                fill: "#99C1FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M306.511 103.362C306.399 104.861 305.917 106.308 305.106 107.574C305.056 107.662 304.982 107.733 304.894 107.782C304.805 107.83 304.705 107.853 304.604 107.849C304.503 107.845 304.406 107.813 304.322 107.757C304.238 107.701 304.171 107.623 304.128 107.532C303.466 106.197 303.13 104.724 303.149 103.234C303.249 101.837 303.671 100.483 304.383 99.2766C304.723 98.7234 305.362 98.7234 305.617 99.3192C306.248 100.571 306.555 101.961 306.511 103.362V103.362Z",
                fill: "#0065FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M224.894 95.4468C225.477 96.3356 226.284 97.0549 227.234 97.5319C227.574 97.7021 227.872 97.5319 227.83 97.1915C227.796 96.1184 227.472 95.0746 226.894 94.1702C226.352 93.3297 225.605 92.6413 224.723 92.1702C224.647 92.1188 224.558 92.0908 224.466 92.0899C224.374 92.0889 224.284 92.115 224.207 92.1649C224.13 92.2148 224.069 92.2863 224.032 92.3705C223.995 92.4547 223.984 92.5478 224 92.6383C224.051 93.6359 224.358 94.6035 224.894 95.4468V95.4468Z",
                fill: "#3384FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M232.851 117.745C234.718 118.294 236.693 118.367 238.596 117.957C238.732 117.953 238.864 117.907 238.974 117.826C239.083 117.746 239.167 117.634 239.213 117.506C239.258 117.378 239.265 117.239 239.231 117.107C239.196 116.975 239.124 116.856 239.021 116.766C237.7 115.329 236.05 114.234 234.213 113.574C232.479 113.024 230.635 112.921 228.851 113.277C228.672 113.277 228.498 113.333 228.353 113.437C228.209 113.542 228.1 113.689 228.044 113.859C227.987 114.028 227.985 114.211 228.039 114.381C228.092 114.552 228.198 114.701 228.34 114.808C229.594 116.126 231.139 117.131 232.851 117.745V117.745Z",
                fill: "#0065FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M228.255 109.745C229.461 110.632 230.862 111.216 232.34 111.447C232.851 111.489 233.149 111.106 232.936 110.681C232.384 109.291 231.491 108.062 230.34 107.106C229.218 106.258 227.902 105.702 226.511 105.489C226.383 105.458 226.249 105.464 226.125 105.507C226.001 105.549 225.892 105.627 225.811 105.731C225.73 105.834 225.68 105.959 225.669 106.09C225.657 106.22 225.683 106.352 225.745 106.468C226.309 107.745 227.17 108.868 228.255 109.745V109.745Z",
                fill: "#0065FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M225.064 102.298C226.16 103.324 227.489 104.069 228.936 104.468C229.031 104.514 229.139 104.528 229.243 104.511C229.347 104.493 229.443 104.443 229.517 104.368C229.592 104.294 229.642 104.198 229.66 104.094C229.677 103.99 229.663 103.883 229.617 103.787C229.218 102.349 228.49 101.023 227.489 99.9149C226.469 98.9512 225.249 98.2247 223.915 97.7872C223.79 97.7338 223.652 97.7191 223.518 97.7448C223.385 97.7706 223.262 97.8358 223.166 97.9319C223.07 98.028 223.005 98.1507 222.979 98.2842C222.953 98.4177 222.968 98.5558 223.021 98.6809C223.413 100.028 224.112 101.267 225.064 102.298V102.298Z",
                fill: "#3384FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M227.404 84.9787C227.476 85.8403 227.753 86.6721 228.213 87.4043C228.235 87.4596 228.273 87.507 228.322 87.5404C228.372 87.5737 228.43 87.5916 228.489 87.5916C228.549 87.5916 228.607 87.5737 228.656 87.5404C228.706 87.507 228.744 87.4596 228.766 87.4043C229.163 86.6272 229.367 85.7662 229.362 84.8936C229.329 84.0831 229.095 83.2934 228.681 82.5958C228.651 82.5219 228.598 82.4593 228.53 82.4168C228.463 82.3742 228.384 82.3539 228.304 82.3586C228.224 82.3633 228.148 82.3927 228.086 82.4429C228.024 82.4931 227.979 82.5614 227.957 82.6383C227.61 83.3707 227.422 84.1683 227.404 84.9787V84.9787Z",
                fill: "#66A3FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M232.809 88.9787C232.294 89.7217 231.985 90.5881 231.915 91.4894C231.89 91.5511 231.886 91.6195 231.904 91.6837C231.922 91.7479 231.961 91.8042 232.015 91.8434C232.069 91.8826 232.135 91.9026 232.201 91.9002C232.268 91.8977 232.332 91.8729 232.383 91.8298C233.199 91.4491 233.914 90.8803 234.468 90.1702C234.94 89.4527 235.246 88.6384 235.362 87.7872C235.373 87.7078 235.361 87.6269 235.329 87.5538C235.296 87.4806 235.243 87.4182 235.176 87.3737C235.11 87.3292 235.032 87.3045 234.952 87.3024C234.871 87.3003 234.792 87.3208 234.723 87.3617C233.967 87.7432 233.311 88.2971 232.809 88.9787V88.9787Z",
                fill: "#66A3FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M232.596 85.1915C232.204 85.8249 231.957 86.5369 231.872 87.2766C231.867 87.3292 231.876 87.3823 231.898 87.4304C231.92 87.4784 231.955 87.5198 231.998 87.5501C232.041 87.5804 232.092 87.5987 232.145 87.603C232.197 87.6072 232.25 87.5974 232.298 87.5745C232.958 87.2316 233.538 86.7531 234 86.1702C234.375 85.5948 234.609 84.9385 234.681 84.2553C234.723 83.9149 234.468 83.7447 234.17 83.9149C233.555 84.2155 233.017 84.652 232.596 85.1915V85.1915Z",
                fill: "#99C1FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M231.277 81.7872C231.029 82.5864 230.985 83.4348 231.149 84.2553C231.156 84.3113 231.178 84.3641 231.214 84.4078C231.25 84.4514 231.297 84.4841 231.35 84.5019C231.404 84.5197 231.461 84.522 231.516 84.5085C231.571 84.495 231.621 84.4662 231.66 84.4255C232.281 83.8812 232.763 83.1952 233.064 82.4255C233.303 81.684 233.361 80.8962 233.234 80.1277C233.248 80.0475 233.232 79.9652 233.19 79.8955C233.149 79.8259 233.083 79.7734 233.006 79.7478C232.929 79.7221 232.845 79.7248 232.77 79.7554C232.695 79.7861 232.633 79.8426 232.596 79.9149C232.008 80.4201 231.555 81.0635 231.277 81.7872V81.7872Z",
                fill: "#99C1FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M234.511 103.362C234.622 104.861 235.105 106.308 235.915 107.574C235.959 107.664 236.027 107.739 236.113 107.79C236.199 107.84 236.297 107.865 236.397 107.861C236.496 107.856 236.592 107.823 236.673 107.764C236.754 107.706 236.816 107.625 236.851 107.532C237.549 106.209 237.901 104.73 237.872 103.234C237.772 101.837 237.35 100.483 236.638 99.2766C236.298 98.7234 235.66 98.7234 235.404 99.3192C234.773 100.571 234.466 101.961 234.511 103.362V103.362Z",
                fill: "#0065FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M316.128 95.4468C315.541 96.3484 314.716 97.07 313.745 97.5319C313.447 97.7021 313.149 97.5319 313.191 97.1915C313.197 96.1497 313.49 95.1296 314.038 94.2437C314.586 93.3577 315.368 92.6402 316.298 92.1702C316.374 92.1188 316.463 92.0908 316.555 92.0899C316.647 92.0889 316.737 92.115 316.814 92.1649C316.892 92.2148 316.952 92.2863 316.989 92.3705C317.026 92.4547 317.037 92.5478 317.021 92.6383C316.971 93.6359 316.663 94.6035 316.128 95.4468V95.4468Z",
                fill: "#3384FF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M264.298 98.5532L264.085 98.4681C264.015 98.425 263.96 98.3603 263.929 98.2836C263.899 98.2069 263.894 98.1224 263.915 98.0426L265.064 91.1915L260.085 86.3404C260.04 86.2801 260.01 86.2107 259.995 86.1372C259.98 86.0636 259.982 85.9877 260 85.9149C260.01 85.8322 260.051 85.7562 260.114 85.7013C260.176 85.6463 260.257 85.6164 260.34 85.617L267.191 84.5958L270.298 78.383C270.333 78.311 270.387 78.2504 270.455 78.2079C270.523 78.1655 270.601 78.1429 270.681 78.1429C270.761 78.1429 270.839 78.1655 270.907 78.2079C270.975 78.2504 271.029 78.311 271.064 78.383L274.128 84.5958L281.021 85.617C281.149 85.617 281.277 85.7447 281.362 85.9149C281.382 85.9907 281.38 86.0706 281.358 86.1457C281.335 86.2207 281.292 86.2882 281.234 86.3404L276.255 91.1915L277.447 98.0426C277.45 98.1215 277.437 98.2004 277.408 98.2738C277.378 98.3472 277.334 98.4135 277.277 98.4681C277.205 98.5092 277.125 98.5308 277.042 98.5308C276.96 98.5308 276.88 98.5092 276.808 98.4681L270.681 95.2341L264.511 98.4681L264.298 98.5532ZM270.681 94.3404H270.851L276.468 97.3192L275.404 91.1064C275.387 91.0404 275.385 90.9712 275.4 90.9045C275.415 90.8379 275.445 90.7757 275.489 90.7234L280.042 86.3404L273.787 85.4043C273.717 85.3996 273.65 85.3777 273.59 85.3406C273.531 85.3034 273.482 85.2522 273.447 85.1915L270.681 79.5319L267.872 85.1915C267.848 85.2517 267.807 85.3036 267.754 85.3413C267.702 85.379 267.639 85.4009 267.574 85.4043L261.319 86.3404L265.83 90.7234C265.916 90.8323 265.961 90.9678 265.957 91.1064L264.894 97.3192L270.468 94.383L270.681 94.3404Z",
                fill: "white"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("defs", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                        id: "paint0_linear_1123_201949",
                        x1: "270",
                        y1: "5.49803",
                        x2: "270",
                        y2: "39.4262",
                        gradientUnits: "userSpaceOnUse",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                stopColor: "#00A3BF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "1",
                                stopColor: "#00A3BF",
                                stopOpacity: "0"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                        id: "paint1_linear_1123_201949",
                        x1: "249.472",
                        y1: "37.8594",
                        x2: "256.423",
                        y2: "137.643",
                        gradientUnits: "userSpaceOnUse",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                stopColor: "#00A3BF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "0.1395",
                                stopColor: "#00A3BF",
                                stopOpacity: "0.8605"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "1",
                                stopColor: "#00A3BF",
                                stopOpacity: "0"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                        id: "paint2_linear_1123_201949",
                        x1: "270",
                        y1: "120",
                        x2: "270",
                        y2: "73.2429",
                        gradientUnits: "userSpaceOnUse",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                stopColor: "#00A3BF",
                                stopOpacity: "0"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "0.8605",
                                stopColor: "#00A3BF",
                                stopOpacity: "0.8605"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "1",
                                stopColor: "#00A3BF"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                        id: "paint3_linear_1123_201949",
                        x1: "266.885",
                        y1: "106.038",
                        x2: "228.983",
                        y2: "106.038",
                        gradientUnits: "userSpaceOnUse",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                stopColor: "#0065FF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "0.41",
                                stopColor: "#0266FF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "0.56",
                                stopColor: "#096AFF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "0.67",
                                stopColor: "#1471FF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "0.75",
                                stopColor: "#257BFF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "0.83",
                                stopColor: "#3B89FF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "0.89",
                                stopColor: "#5799FF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "0.95",
                                stopColor: "#76ACFF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "1",
                                stopColor: "#99C1FF"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                        id: "paint4_linear_1123_201949",
                        x1: "274.128",
                        y1: "106.038",
                        x2: "312.034",
                        y2: "106.038",
                        gradientUnits: "userSpaceOnUse",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                stopColor: "#0065FF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "0.36",
                                stopColor: "#0266FF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "0.52",
                                stopColor: "#096BFF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "0.63",
                                stopColor: "#1672FF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "0.73",
                                stopColor: "#277DFF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "0.81",
                                stopColor: "#3F8BFF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "0.88",
                                stopColor: "#5B9CFF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "0.95",
                                stopColor: "#7CB0FF"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "1",
                                stopColor: "#99C1FF"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                        id: "paint5_linear_1123_201949",
                        x1: "242.979",
                        y1: "121.255",
                        x2: "298.357",
                        y2: "65.8723",
                        gradientUnits: "userSpaceOnUse",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                stopColor: "#FFAB00"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "0.82",
                                stopColor: "#FFC400"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
const AddPeopleIcon = ({ className, size })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        className: className,
        width: size ?? 24,
        height: size ?? 24,
        viewBox: "0 0 24 24",
        role: "presentation",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
            fill: "currentColor",
            fillRule: "evenodd",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                    x: "18",
                    y: "5",
                    width: "2",
                    height: "6",
                    rx: "1"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                    x: "16",
                    y: "7",
                    width: "6",
                    height: "2",
                    rx: "1"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M5 14c0-1.105.902-2 2.009-2h7.982c1.11 0 2.009.894 2.009 2.006v4.44c0 3.405-12 3.405-12 0V14z"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                    cx: "11",
                    cy: "7",
                    r: "4"
                })
            ]
        })
    });
};
const SubTaskIcon = ({ className, size })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        className: className,
        xmlns: "http://www.w3.org/2000/svg",
        width: size ?? 14,
        height: size ?? 14,
        viewBox: "0 0 14 14",
        version: "1.1",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                children: "subtask"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("desc", {
                children: "Created with Sketch."
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "Page-1",
                stroke: "none",
                strokeWidth: "1",
                fill: "none",
                fillRule: "evenodd",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                    id: "subtask",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                        id: "Subtask",
                        transform: "translate(1.000000, 1.000000)",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                id: "Rectangle-36",
                                fill: "#4BAEE8",
                                x: "0",
                                y: "0",
                                width: "14",
                                height: "14"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                id: "Rectangle-80",
                                stroke: "#FFFFFF",
                                x: "2",
                                y: "2",
                                width: "5",
                                height: "5"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                id: "Rectangle-80-Copy",
                                stroke: "#FFFFFF",
                                fill: "#FFFFFF",
                                x: "5",
                                y: "5",
                                width: "5",
                                height: "5"
                            })
                        ]
                    })
                })
            })
        ]
    });
};
const UnassignedUser = ({ className, size })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        className: className,
        xmlns: "http://www.w3.org/2000/svg",
        width: size ?? 14,
        height: size ?? 14,
        viewBox: "0 0 24 24",
        role: "presentation",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
            fill: "currentColor",
            fillRule: "evenodd",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M6 14c0-1.105.902-2 2.009-2h7.982c1.11 0 2.009.894 2.009 2.006v4.44c0 3.405-12 3.405-12 0V14z"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                    cx: "12",
                    cy: "7",
                    r: "4"
                })
            ]
        })
    });
};



/***/ }),

/***/ 74887:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Qd: () => (/* binding */ AccordionItem),
/* harmony export */   UQ: () => (/* binding */ Accordion),
/* harmony export */   o4: () => (/* binding */ AccordionTrigger),
/* harmony export */   vF: () => (/* binding */ AccordionContent)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_accordion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(34975);
/* harmony import */ var _radix_ui_react_accordion__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_accordion__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);




const AccordionTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_accordion__WEBPACK_IMPORTED_MODULE_3__.Header, {
        className: "flex",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_accordion__WEBPACK_IMPORTED_MODULE_3__.Trigger, {
            ref: forwardedRef,
            className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
            ...props,
            children: children
        })
    }));
AccordionTrigger.displayName = "AccordionTrigger";
const AccordionContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_accordion__WEBPACK_IMPORTED_MODULE_3__.Content, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "",
            children: children
        })
    }));
AccordionContent.displayName = "AccordionContent";
const AccordionItem = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_accordion__WEBPACK_IMPORTED_MODULE_3__.Item, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
AccordionItem.displayName = "AccordionItem";
const Accordion = _radix_ui_react_accordion__WEBPACK_IMPORTED_MODULE_3__.Root;



/***/ }),

/***/ 38546:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   z: () => (/* binding */ Button)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31621);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);




const Button = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_3___default().forwardRef(({ children, className, customColors, customPadding, href, target, ...props }, ref)=>{
    if (href) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
        href: href,
        target: target ?? "_self",
        className: clsx__WEBPACK_IMPORTED_MODULE_1___default()(!customColors && "bg-gray-200 hover:bg-gray-300", !customPadding && "p-1.5", "inline-flex items-center rounded-[3px] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2", className),
        children: children
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        className: clsx__WEBPACK_IMPORTED_MODULE_1___default()(!customColors && "bg-gray-200 font-medium text-gray-600 hover:bg-gray-300", !customPadding && "p-1.5", "inline-flex items-center rounded-[3px] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-1", className),
        ref: ref,
        ...props,
        children: children
    });
});
Button.displayName = "Button";



/***/ }),

/***/ 72463:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FI: () => (/* binding */ ContextPortal),
/* harmony export */   Fb: () => (/* binding */ ContextLabel),
/* harmony export */   Ph: () => (/* binding */ ContextItem),
/* harmony export */   QT: () => (/* binding */ ContextContent),
/* harmony export */   _y: () => (/* binding */ Context),
/* harmony export */   c5: () => (/* binding */ ContextGroup),
/* harmony export */   ud: () => (/* binding */ ContextTrigger)
/* harmony export */ });
/* unused harmony exports ContextSub, ContextSubTrigger, ContextSubContent, ContextSeparator */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(77751);
/* harmony import */ var _radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);




const Context = _radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_3__.Root;
const ContextTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_3__.Trigger, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ContextTrigger.displayName = "ContextTrigger";
const ContextPortal = ({ children, className, ...props })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_3__.Portal, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        children: children
    });
ContextPortal.displayName = "ContextPortal";
const ContextContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_3__.Content, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ContextContent.displayName = "ContextContent";
const ContextLabel = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_3__.Label, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ContextLabel.displayName = "ContextLabel";
const ContextItem = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_3__.Item, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ContextItem.displayName = "ContextItem";
const ContextGroup = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_3__.Group, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ContextGroup.displayName = "ContextGroup";
const ContextSub = ({ children, ...props })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_3__.Sub, {
        ...props,
        children: children
    });
ContextSub.displayName = "ContextSub";
const ContextSubTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_3__.SubTrigger, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ContextSubTrigger.displayName = "ContextSubTrigger";
const ContextSubContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_3__.SubContent, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ContextSubContent.displayName = "ContextSubContent";
const ContextSeparator = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_3__.Separator, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ContextSeparator.displayName = "ContextSeparator";



/***/ }),

/***/ 41772:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HF: () => (/* binding */ DropdownLabel),
/* harmony export */   Lt: () => (/* binding */ Dropdown),
/* harmony export */   Nv: () => (/* binding */ DropdownContent),
/* harmony export */   WA: () => (/* binding */ DropdownTrigger),
/* harmony export */   hP: () => (/* binding */ DropdownItem),
/* harmony export */   nI: () => (/* binding */ DropdownPortal),
/* harmony export */   pb: () => (/* binding */ DropdownGroup)
/* harmony export */ });
/* unused harmony exports DropdownSub, DropdownSubTrigger, DropdownSubContent, DropdownSeparator */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(71284);
/* harmony import */ var _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);




const Dropdown = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Root;
const DropdownTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Trigger, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
DropdownTrigger.displayName = "DropdownTrigger";
const DropdownPortal = ({ children, className, ...props })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Portal, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        children: children
    });
DropdownPortal.displayName = "DropdownPortal";
const DropdownContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Content, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
DropdownContent.displayName = "DropdownContent";
const DropdownLabel = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Label, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
DropdownLabel.displayName = "DropdownLabel";
const DropdownItem = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Item, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
DropdownItem.displayName = "DropdownItem";
const DropdownGroup = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Group, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
DropdownGroup.displayName = "DropdownGroup";
const DropdownSub = ({ children, ...props })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Sub, {
        ...props,
        children: children
    });
DropdownSub.displayName = "DropdownSub";
const DropdownSubTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.SubTrigger, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
DropdownSubTrigger.displayName = "DropdownSubTrigger";
const DropdownSubContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.SubContent, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
DropdownSubContent.displayName = "DropdownSubContent";
const DropdownSeparator = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Separator, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
DropdownSeparator.displayName = "DropdownSeparator";



/***/ }),

/***/ 13785:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Bw: () => (/* binding */ SelectContent),
/* harmony export */   DI: () => (/* binding */ SelectGroup),
/* harmony export */   GV: () => (/* binding */ SelectIcon),
/* harmony export */   Ph: () => (/* binding */ Select),
/* harmony export */   Q_: () => (/* binding */ SelectViewport),
/* harmony export */   Ql: () => (/* binding */ SelectItem),
/* harmony export */   U$: () => (/* binding */ SelectSeparator),
/* harmony export */   i4: () => (/* binding */ SelectTrigger),
/* harmony export */   ki: () => (/* binding */ SelectValue),
/* harmony export */   ue: () => (/* binding */ SelectPortal)
/* harmony export */ });
/* unused harmony exports SelectScrollDownButton, SelectScrollUpButton */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20085);
/* harmony import */ var _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);




const Select = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__.Root;
const SelectTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__.Trigger, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
SelectTrigger.displayName = "SelectTrigger";
const SelectValue = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__.Value, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
SelectValue.displayName = "SelectValue";
const SelectIcon = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__.Icon, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
SelectIcon.displayName = "SelectIcon";
const SelectPortal = ({ children, className, ...props })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__.Portal, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        children: children
    });
SelectPortal.displayName = "SelectPortal";
const SelectContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__.Content, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
SelectContent.displayName = "SelectContent";
const SelectScrollUpButton = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__.ScrollUpButton, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
SelectScrollUpButton.displayName = "SelectScrollUpButton";
const SelectScrollDownButton = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__.ScrollDownButton, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
SelectScrollDownButton.displayName = "SelectScrollDownButton";
const SelectViewport = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__.Viewport, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
SelectViewport.displayName = "SelectViewport";
const SelectGroup = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__.Group, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
SelectGroup.displayName = "SelectGroup";
const SelectItem = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, noBorder, ...props }, forwardedRef)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__.Item, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()(noBorder ? "" : "border-l-[3px] border-transparent", "[&[data-state=checked]]:bg-gray-100", className),
        ...props,
        ref: forwardedRef,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__.ItemText, {
            children: children
        })
    });
});
SelectItem.displayName = "SelectItem";
const SelectSeparator = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__.Separator, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
SelectSeparator.displayName = "SelectSeparator";



/***/ }),

/***/ 35215:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ Spinner)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);


const Spinner = ({ size = "md", white })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        "aria-label": "loading",
        className: clsx__WEBPACK_IMPORTED_MODULE_1___default()(size === "sm" && "h-4 w-4", size === "md" && "h-8 w-8", size === "lg" && "h-12 w-12", white ? "border-white" : "border-blue-900", "animate-spin rounded-full border-2 border-solid border-t-transparent")
    });
};



/***/ }),

/***/ 45197:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   pf: () => (/* binding */ TooltipWrapper)
/* harmony export */ });
/* unused harmony exports Tooltip, TooltipContent, TooltipPortal, TooltipTrigger, TooltipArrow */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_tooltip__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74112);
/* harmony import */ var _radix_ui_react_tooltip__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_tooltip__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);




const Tooltip = _radix_ui_react_tooltip__WEBPACK_IMPORTED_MODULE_3__.Root;
const TooltipTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_tooltip__WEBPACK_IMPORTED_MODULE_3__.Trigger, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
TooltipTrigger.displayName = "TooltipTrigger";
const TooltipPortal = ({ children, className, ...props })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_tooltip__WEBPACK_IMPORTED_MODULE_3__.Portal, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        children: children
    });
TooltipPortal.displayName = "TooltipPortal";
const TooltipContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_tooltip__WEBPACK_IMPORTED_MODULE_3__.Content, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
TooltipContent.displayName = "TooltipContent";
const TooltipArrow = ({ children, ...props })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_tooltip__WEBPACK_IMPORTED_MODULE_3__.Arrow, {
        ...props,
        children: children
    });
TooltipArrow.displayName = "TooltipArrow";
const TooltipWrapper = ({ children, text, side = "bottom" })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_tooltip__WEBPACK_IMPORTED_MODULE_3__.Provider, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Tooltip, {
            delayDuration: 100,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TooltipTrigger, {
                    asChild: true,
                    children: children
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TooltipPortal, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TooltipContent, {
                        side: side,
                        sideOffset: 4,
                        className: "z-50 max-w-2xl rounded-sm bg-gray-700 px-1.5 py-0.5 text-xs text-white",
                        children: text
                    })
                })
            ]
        })
    });
};



/***/ }),

/***/ 57165:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P: () => (/* binding */ useFiltersContext),
/* harmony export */   W: () => (/* binding */ FiltersProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ FiltersProvider,useFiltersContext auto */ 

const FiltersContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
    assignees: [],
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    setAssignees: ()=>{},
    search: "",
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    setSearch: ()=>{},
    epics: [],
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    setEpics: ()=>{},
    issueTypes: [],
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    setIssueTypes: ()=>{},
    sprints: [],
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    setSprints: ()=>{}
});
const FiltersProvider = ({ children })=>{
    const [assignees, setAssignees] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [search, setSearch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [epics, setEpics] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [issueTypes, setIssueTypes] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [sprints, setSprints] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FiltersContext.Provider, {
        value: {
            assignees,
            setAssignees,
            search,
            setSearch,
            epics,
            setEpics,
            issueTypes,
            setIssueTypes,
            sprints,
            setSprints
        },
        children: children
    });
};
const useFiltersContext = ()=>(0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(FiltersContext);


/***/ }),

/***/ 90779:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectedIssueProvider: () => (/* binding */ SelectedIssueProvider),
/* harmony export */   useSelectedIssueContext: () => (/* binding */ useSelectedIssueContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* __next_internal_client_entry_do_not_use__ SelectedIssueProvider,useSelectedIssueContext auto */ 


const SelectedIssueContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_2__.createContext)({
    issueKey: null,
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    setIssueKey: ()=>{}
});
const SelectedIssueProvider = ({ children })=>{
    const searchParams = (0,next_navigation__WEBPACK_IMPORTED_MODULE_1__.useSearchParams)();
    const pathname = (0,next_navigation__WEBPACK_IMPORTED_MODULE_1__.usePathname)();
    const [issueKey, setIssueKey] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const setSelectedIssueUrl = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((key)=>{
        const urlWithQuery = pathname + (key ? `?selectedIssue=${key}` : "");
        window.history.pushState(null, "", urlWithQuery);
    }, [
        pathname
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        setIssueKey(searchParams.get("selectedIssue"));
    }, [
        searchParams
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        setSelectedIssueUrl(issueKey);
    }, [
        issueKey,
        setSelectedIssueUrl
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SelectedIssueContext.Provider, {
        value: {
            issueKey,
            setIssueKey
        },
        children: children
    });
};
const useSelectedIssueContext = ()=>(0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(SelectedIssueContext);


/***/ }),

/***/ 14184:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ TOO_MANY_REQUESTS),
  g: () => (/* binding */ useIssues)
});

// EXTERNAL MODULE: ./utils/api/index.ts + 3 modules
var api = __webpack_require__(27932);
// EXTERNAL MODULE: ./node_modules/@tanstack/react-query/build/lib/useQuery.mjs
var useQuery = __webpack_require__(19329);
// EXTERNAL MODULE: ./components/toast.tsx
var toast = __webpack_require__(34825);
// EXTERNAL MODULE: ./node_modules/@tanstack/react-query/build/lib/QueryClientProvider.mjs
var QueryClientProvider = __webpack_require__(98417);
// EXTERNAL MODULE: ./node_modules/@tanstack/react-query/build/lib/useMutation.mjs + 1 modules
var useMutation = __webpack_require__(33369);
;// CONCATENATED MODULE: ./hooks/query-hooks/use-issues/use-update-issue.ts
/* __next_internal_client_entry_do_not_use__ useUpdateIssue auto */ 



const useUpdateIssue = ()=>{
    const queryClient = (0,QueryClientProvider.useQueryClient)();
    const { mutate: updateIssue, isLoading: isUpdating } = (0,useMutation.useMutation)([
        "issues"
    ], api/* api */.h.issues.patchIssue, {
        // OPTIMISTIC UPDATE
        onMutate: async (newIssue)=>{
            // Cancel any outgoing refetches (so they don't overwrite our optimistic update)
            await queryClient.cancelQueries([
                "issues"
            ]);
            // Snapshot the previous value
            const previousIssues = queryClient.getQueryData([
                "issues"
            ]);
            queryClient.setQueryData([
                "issues"
            ], (old)=>{
                const newIssues = (old ?? []).map((issue)=>{
                    const { issueId, ...updatedProps } = newIssue;
                    if (issue.id === issueId) {
                        // Assign the new prop values to the issue
                        return Object.assign(issue, updatedProps);
                    }
                    return issue;
                });
                return newIssues;
            });
            // }
            // Return a context object with the snapshotted value
            return {
                previousIssues
            };
        },
        onError: (err, newIssue, context)=>{
            // If the mutation fails, use the context returned from onMutate to roll back
            queryClient.setQueryData([
                "issues"
            ], context?.previousIssues);
            if (err?.response?.data == "Too many requests") {
                toast.toast.error(TOO_MANY_REQUESTS);
                return;
            }
            toast.toast.error({
                message: `Something went wrong while updating the issue ${newIssue.issueId}`,
                description: "Please try again later."
            });
        },
        onSettled: ()=>{
            // Always refetch after error or success
            // eslint-disable-next-line @typescript-eslint/no-floating-promises
            queryClient.invalidateQueries([
                "issues"
            ]);
        }
    });
    return {
        updateIssue,
        isUpdating
    };
};


;// CONCATENATED MODULE: ./hooks/query-hooks/use-issues/use-update-batch.ts
/* __next_internal_client_entry_do_not_use__ useUpdateIssuesBatch auto */ 



const useUpdateIssuesBatch = ()=>{
    const queryClient = (0,QueryClientProvider.useQueryClient)();
    const { mutate: updateIssuesBatch, isLoading: batchUpdating } = (0,useMutation.useMutation)(api/* api */.h.issues.updateBatchIssues, {
        // OPTIMISTIC UPDATE
        onMutate: async (newIssue)=>{
            // Cancel any outgoing refetches (so they don't overwrite our optimistic update)
            await queryClient.cancelQueries([
                "issues"
            ]);
            // Snapshot the previous value
            const previousIssues = queryClient.getQueryData([
                "issues"
            ]);
            // Optimistically updating the issues
            queryClient.setQueryData([
                "issues"
            ], (old)=>{
                const newIssues = (old ?? []).map((issue)=>{
                    const { ids, ...updatedProps } = newIssue;
                    if (ids.includes(issue.id)) {
                        // Assign the new prop values to the issue
                        return Object.assign(issue, updatedProps);
                    }
                    return issue;
                });
                return newIssues;
            });
            // Return a context object with the snapshotted value
            return {
                previousIssues
            };
        },
        onError: (err, newIssue, context)=>{
            // If the mutation fails, use the context returned from onMutate to roll back
            queryClient.setQueryData([
                "issues"
            ], context?.previousIssues);
            if (err?.response?.data == "Too many requests") {
                toast.toast.error(TOO_MANY_REQUESTS);
                return;
            }
            toast.toast.error({
                message: `Something went wrong while batch updating issues`,
                description: "Please try again later."
            });
        },
        onSettled: ()=>{
            // Always refetch after error or success
            // eslint-disable-next-line @typescript-eslint/no-floating-promises
            queryClient.invalidateQueries([
                "issues"
            ]);
        }
    });
    return {
        updateIssuesBatch,
        batchUpdating
    };
};


;// CONCATENATED MODULE: ./hooks/query-hooks/use-issues/use-post-issue.ts
/* __next_internal_client_entry_do_not_use__ usePostIssue auto */ 



const usePostIssue = ()=>{
    const queryClient = (0,QueryClientProvider.useQueryClient)();
    const { mutate: createIssue, isLoading: isCreating } = (0,useMutation.useMutation)(api/* api */.h.issues.postIssue, {
        // NO OPTIMISTIC UPDATE BECAUSE WE DON'T KNOW THE KEY OF THE NEW ISSUE
        onError: (err, createdIssue)=>{
            // If the mutation fails, use the context returned from onMutate to roll back
            if (err?.response?.data == "Too many requests") {
                toast.toast.error(TOO_MANY_REQUESTS);
                return;
            }
            toast.toast.error({
                message: `Something went wrong while creating the issue ${createdIssue.name}`,
                description: "Please try again later."
            });
        },
        onSettled: ()=>{
            // Always refetch after error or success
            // eslint-disable-next-line @typescript-eslint/no-floating-promises
            queryClient.invalidateQueries([
                "issues"
            ]);
        }
    });
    return {
        createIssue,
        isCreating
    };
};


// EXTERNAL MODULE: ./context/use-selected-issue-context.tsx
var use_selected_issue_context = __webpack_require__(90779);
;// CONCATENATED MODULE: ./hooks/query-hooks/use-issues/use-delete-issue.ts
/* __next_internal_client_entry_do_not_use__ useDeleteIssue auto */ 




const useDeleteIssue = ()=>{
    const { issueKey, setIssueKey } = (0,use_selected_issue_context.useSelectedIssueContext)();
    const queryClient = (0,QueryClientProvider.useQueryClient)();
    const { mutate: deleteIssue, isLoading: isDeleting } = (0,useMutation.useMutation)(api/* api */.h.issues.deleteIssue, {
        // OPTIMISTIC UPDATE
        onMutate: async (deletedIssue)=>{
            // Cancel any outgoing refetches (so they don't overwrite our optimistic update)
            await queryClient.cancelQueries({
                queryKey: [
                    "issues"
                ]
            });
            // Snapshot the previous value
            const previousIssues = queryClient.getQueryData([
                "issues"
            ]);
            // Optimistically delete the issue
            queryClient.setQueryData([
                "issues"
            ], (old)=>{
                return old?.filter((issue)=>issue.id !== deletedIssue.issueId);
            });
            // Return a context object with the snapshotted value
            return {
                previousIssues
            };
        },
        onError: (err, deletedIssue, context)=>{
            // If the mutation fails, use the context returned from onMutate to roll back
            if (err?.response?.data == "Too many requests") {
                toast.toast.error(TOO_MANY_REQUESTS);
                return;
            }
            toast.toast.error({
                message: `Something went wrong while deleting the issue ${deletedIssue.issueId}`,
                description: "Please try again later."
            });
            queryClient.setQueryData([
                "issues"
            ], context?.previousIssues);
        },
        onSettled: (deletedIssue)=>{
            // Always refetch after error or success
            // eslint-disable-next-line @typescript-eslint/no-floating-promises
            queryClient.invalidateQueries([
                "issues"
            ]);
            // Unselect the deleted issue if it is currently selected
            if (issueKey == deletedIssue?.key) {
                setIssueKey(null);
            }
        }
    });
    return {
        deleteIssue,
        isDeleting
    };
};


;// CONCATENATED MODULE: ./hooks/query-hooks/use-issues/index.ts
/* __next_internal_client_entry_do_not_use__ TOO_MANY_REQUESTS,useIssues auto */ 





const TOO_MANY_REQUESTS = {
    message: `You have exceeded the number of requests allowed per minute.`,
    description: "Please try again later."
};
const useIssues = ()=>{
    const { data: issues, isLoading: issuesLoading } = (0,useQuery.useQuery)([
        "issues"
    ], ({ signal })=>api/* api */.h.issues.getIssues({
            signal
        }), {
        refetchOnMount: false
    });
    const { updateIssuesBatch, batchUpdating } = useUpdateIssuesBatch();
    const { updateIssue, isUpdating } = useUpdateIssue();
    const { createIssue, isCreating } = usePostIssue();
    const { deleteIssue, isDeleting } = useDeleteIssue();
    return {
        issues,
        issuesLoading,
        updateIssue,
        isUpdating,
        updateIssuesBatch,
        batchUpdating,
        createIssue,
        isCreating,
        deleteIssue,
        isDeleting
    };
};


/***/ }),

/***/ 5663:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P: () => (/* binding */ useProject)
/* harmony export */ });
/* harmony import */ var _utils_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(27932);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19329);
/* __next_internal_client_entry_do_not_use__ useProject auto */ 

const useProject = ()=>{
    const { data: project, isLoading: projectIsLoading } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)([
        "project"
    ], _utils_api__WEBPACK_IMPORTED_MODULE_0__/* .api */ .h.project.getProject);
    const { data: members } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)([
        "project-members"
    ], ()=>_utils_api__WEBPACK_IMPORTED_MODULE_0__/* .api */ .h.project.getMembers({
            project_id: project?.id ?? ""
        }), {
        enabled: !!project?.id
    });
    return {
        project,
        projectIsLoading,
        members
    };
};


/***/ }),

/***/ 75589:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   D: () => (/* binding */ useSprints)
/* harmony export */ });
/* harmony import */ var _components_toast__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(34825);
/* harmony import */ var _utils_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(27932);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(98417);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(19329);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(33369);
/* harmony import */ var _use_issues__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14184);
/* __next_internal_client_entry_do_not_use__ useSprints auto */ 



const useSprints = ()=>{
    const queryClient = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__.useQueryClient)();
    // GET
    const { data: sprints, isLoading: sprintsLoading } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_4__.useQuery)([
        "sprints"
    ], _utils_api__WEBPACK_IMPORTED_MODULE_1__/* .api */ .h.sprints.getSprints, {
        refetchOnMount: false
    });
    // UPDATE
    const { mutate: updateSprint, isLoading: isUpdating } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_5__.useMutation)(_utils_api__WEBPACK_IMPORTED_MODULE_1__/* .api */ .h.sprints.patchSprint, {
        // OPTIMISTIC UPDATE
        onMutate: async (newSprint)=>{
            // Cancel any outgoing refetches (so they don't overwrite our optimistic update)
            await queryClient.cancelQueries([
                "sprints"
            ]);
            // Snapshot the previous value
            const previousSprints = queryClient.getQueryData([
                "sprints"
            ]);
            // Optimistically update the sprint
            // Otherwise, we are generically updating the sprint
            queryClient.setQueryData([
                "sprints"
            ], (old)=>{
                const newSprints = (old ?? []).map((sprint)=>{
                    const { sprintId, ...updatedProps } = newSprint;
                    if (sprint.id === sprintId) {
                        // Assign the new prop values to the sprint
                        return Object.assign(sprint, updatedProps);
                    }
                    return sprint;
                });
                return newSprints;
            });
            // Return a context object with the snapshotted value
            return {
                previousSprints
            };
        },
        onError: (err, newSprint, context)=>{
            // If the mutation fails, use the context returned from onMutate to roll back
            queryClient.setQueryData([
                "sprints"
            ], context?.previousSprints);
            if (err?.response?.data == "Too many requests") {
                _components_toast__WEBPACK_IMPORTED_MODULE_0__.toast.error(_use_issues__WEBPACK_IMPORTED_MODULE_2__/* .TOO_MANY_REQUESTS */ .Z);
                return;
            }
            _components_toast__WEBPACK_IMPORTED_MODULE_0__.toast.error({
                message: `Something went wrong while updating sprint ${newSprint.sprintId}`,
                description: "Please try again later."
            });
        },
        onSettled: ()=>{
            // Always refetch after error or success
            // eslint-disable-next-line @typescript-eslint/no-floating-promises
            queryClient.invalidateQueries([
                "sprints"
            ]);
        }
    });
    // POST
    const { mutate: createSprint, isLoading: isCreating } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_5__.useMutation)(_utils_api__WEBPACK_IMPORTED_MODULE_1__/* .api */ .h.sprints.postSprint, {
        // NO OPTIMISTIC UPDATE BECAUSE WE DON'T KNOW THE KEY OF THE NEW SPRINT
        onError: (err)=>{
            // If the mutation fails, use the context returned from onMutate to roll back
            if (err?.response?.data == "Too many requests") {
                _components_toast__WEBPACK_IMPORTED_MODULE_0__.toast.error(_use_issues__WEBPACK_IMPORTED_MODULE_2__/* .TOO_MANY_REQUESTS */ .Z);
                return;
            }
            _components_toast__WEBPACK_IMPORTED_MODULE_0__.toast.error({
                message: `Something went wrong while creating sprint`,
                description: "Please try again later."
            });
        },
        onSettled: ()=>{
            // Always refetch after error or success
            // eslint-disable-next-line @typescript-eslint/no-floating-promises
            queryClient.invalidateQueries([
                "sprints"
            ]);
        }
    });
    // DELETE
    const { mutate: deleteSprint, isLoading: isDeleting } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_5__.useMutation)(_utils_api__WEBPACK_IMPORTED_MODULE_1__/* .api */ .h.sprints.deleteSprint, {
        // OPTIMISTIC UPDATE
        onMutate: async (deletedSprint)=>{
            // Cancel any outgoing refetches (so they don't overwrite our optimistic update)
            await queryClient.cancelQueries({
                queryKey: [
                    "sprints"
                ]
            });
            // Snapshot the previous value
            const previousSprints = queryClient.getQueryData([
                "sprints"
            ]);
            // Optimistically delete the sprint
            queryClient.setQueryData([
                "sprints"
            ], (old)=>{
                return old?.filter((sprint)=>sprint.id !== deletedSprint.sprintId);
            });
            // Return a context object with the snapshotted value
            return {
                previousSprints
            };
        },
        onError: (err, deletedSprint, context)=>{
            // If the mutation fails, use the context returned from onMutate to roll back
            if (err?.response?.data == "Too many requests") {
                _components_toast__WEBPACK_IMPORTED_MODULE_0__.toast.error(_use_issues__WEBPACK_IMPORTED_MODULE_2__/* .TOO_MANY_REQUESTS */ .Z);
                return;
            }
            _components_toast__WEBPACK_IMPORTED_MODULE_0__.toast.error({
                message: `Something went wrong while deleting the sprint ${deletedSprint.sprintId}`,
                description: "Please try again later."
            });
            queryClient.setQueryData([
                "sprints"
            ], context?.previousSprints);
        },
        onSettled: ()=>{
            // Always refetch after error or success
            // eslint-disable-next-line @typescript-eslint/no-floating-promises
            queryClient.invalidateQueries([
                "sprints"
            ]);
        }
    });
    return {
        sprints,
        sprintsLoading,
        updateSprint,
        isUpdating,
        createSprint,
        isCreating,
        deleteSprint,
        isDeleting
    };
};


/***/ }),

/***/ 30660:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   k: () => (/* binding */ useIsAuthenticated)
/* harmony export */ });
/* harmony import */ var _context_use_auth_modal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(27987);
/* harmony import */ var _clerk_clerk_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48751);
/* __next_internal_client_entry_do_not_use__ useIsAuthenticated auto */ 

const useIsAuthenticated = ()=>{
    const { user } = (0,_clerk_clerk_react__WEBPACK_IMPORTED_MODULE_1__/* .useUser */ .aF)();
    const { setAuthModalIsOpen } = (0,_context_use_auth_modal__WEBPACK_IMPORTED_MODULE_0__.useAuthModalContext)();
    function openAuthModal() {
        setAuthModalIsOpen(true);
    }
    return [
        user?.id,
        openAuthModal
    ];
};


/***/ }),

/***/ 27932:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  h: () => (/* binding */ api)
});

// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(40248);
// EXTERNAL MODULE: ./utils/helpers.ts
var helpers = __webpack_require__(89602);
;// CONCATENATED MODULE: ./utils/api/project.ts


const baseUrl = (0,helpers/* getBaseUrl */.SV)();
const projectRoutes = {
    getProject: async ()=>{
        const { data } = await axios/* default */.Z.get(`${baseUrl}/api/project`);
        return data?.project;
    },
    getMembers: async ({ project_id })=>{
        const { data } = await axios/* default */.Z.get(`${baseUrl}/api/project/${project_id}/members`);
        return data?.members;
    }
};

;// CONCATENATED MODULE: ./utils/api/issues.ts


const issues_baseUrl = (0,helpers/* getBaseUrl */.SV)();
const issuesRoutes = {
    getIssues: async ({ signal })=>{
        const { data } = await axios/* default */.Z.get(`${issues_baseUrl}/api/issues`, {
            signal
        });
        return data?.issues;
    },
    updateBatchIssues: async (body)=>{
        const { data } = await axios/* default */.Z.patch(`${issues_baseUrl}/api/issues`, body, {
            headers: (0,helpers/* getHeaders */.wU)()
        });
        return data?.issues;
    },
    getIssueDetails: async ({ issueId })=>{
        const { data } = await axios/* default */.Z.get(`${issues_baseUrl}/api/issues/${issueId}`);
        return data?.issue;
    },
    postIssue: async (body)=>{
        const { data } = await axios/* default */.Z.post(`${issues_baseUrl}/api/issues`, body, {
            headers: (0,helpers/* getHeaders */.wU)()
        });
        return data?.issue;
    },
    patchIssue: async ({ issueId, ...body })=>{
        const { data } = await axios/* default */.Z.patch(`${issues_baseUrl}/api/issues/${issueId}`, body, {
            headers: (0,helpers/* getHeaders */.wU)()
        });
        return data?.issue;
    },
    deleteIssue: async ({ issueId })=>{
        const { data } = await axios/* default */.Z.delete(`${issues_baseUrl}/api/issues/${issueId}`, {
            headers: (0,helpers/* getHeaders */.wU)()
        });
        return data?.issue;
    },
    addCommentToIssue: async (payload)=>{
        const { issueId, content, authorId } = payload;
        const { data } = await axios/* default */.Z.post(`${issues_baseUrl}/api/issues/${issueId}/comments`, {
            content,
            authorId
        }, {
            headers: (0,helpers/* getHeaders */.wU)()
        });
        return data?.comment;
    },
    getIssueComments: async ({ issueId })=>{
        const { data } = await axios/* default */.Z.get(`${issues_baseUrl}/api/issues/${issueId}/comments`);
        return data?.comments;
    },
    updateIssueComment: async ({ issueId, content, commentId })=>{
        const { data } = await axios/* default */.Z.patch(`${issues_baseUrl}/api/issues/${issueId}/comments/${commentId}`, {
            content
        }, {
            headers: (0,helpers/* getHeaders */.wU)()
        });
        return data?.comment;
    }
};

;// CONCATENATED MODULE: ./utils/api/sprints.ts


const sprints_baseUrl = (0,helpers/* getBaseUrl */.SV)();
const sprintsRoutes = {
    postSprint: async ()=>{
        try {
            const { data } = await axios/* default */.Z.post(`${sprints_baseUrl}/api/sprints`, {
                headers: (0,helpers/* getHeaders */.wU)()
            });
            return data.sprint;
        } catch (error) {
            console.error(error);
        }
    },
    getSprints: async ()=>{
        const { data } = await axios/* default */.Z.get(`${sprints_baseUrl}/api/sprints`, {
            headers: (0,helpers/* getHeaders */.wU)()
        });
        return data.sprints;
    },
    patchSprint: async ({ sprintId, ...body })=>{
        const { data } = await axios/* default */.Z.patch(`${sprints_baseUrl}/api/sprints/${sprintId}`, body, {
            headers: (0,helpers/* getHeaders */.wU)()
        });
        return data.sprint;
    },
    deleteSprint: async ({ sprintId })=>{
        const { data } = await axios/* default */.Z.delete(`${sprints_baseUrl}/api/sprints/${sprintId}`, {
            headers: (0,helpers/* getHeaders */.wU)()
        });
        return data.sprint;
    }
};

;// CONCATENATED MODULE: ./utils/api/index.ts



const api = {
    project: projectRoutes,
    issues: issuesRoutes,
    sprints: sprintsRoutes
};


/***/ }),

/***/ 89602:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CD: () => (/* binding */ dateToLongString),
/* harmony export */   F3: () => (/* binding */ moveItemWithinArray),
/* harmony export */   I0: () => (/* binding */ sprintId),
/* harmony export */   Po: () => (/* binding */ issueNotInSearch),
/* harmony export */   Rw: () => (/* binding */ isNullish),
/* harmony export */   SV: () => (/* binding */ getBaseUrl),
/* harmony export */   UH: () => (/* binding */ issueSprintNotInFilters),
/* harmony export */   UU: () => (/* binding */ isSubtask),
/* harmony export */   Z: () => (/* binding */ getIssueCountByStatus),
/* harmony export */   _b: () => (/* binding */ isDone),
/* harmony export */   a7: () => (/* binding */ hexToRgba),
/* harmony export */   bs: () => (/* binding */ capitalizeMany),
/* harmony export */   eV: () => (/* binding */ insertItemIntoArray),
/* harmony export */   g8: () => (/* binding */ hasChildren),
/* harmony export */   kC: () => (/* binding */ capitalize),
/* harmony export */   ks: () => (/* binding */ getPluralEnd),
/* harmony export */   pQ: () => (/* binding */ isEpic),
/* harmony export */   rg: () => (/* binding */ epicNotInFilters),
/* harmony export */   tf: () => (/* binding */ assigneeNotInFilters),
/* harmony export */   wU: () => (/* binding */ getHeaders),
/* harmony export */   x2: () => (/* binding */ issueTypeNotInFilters)
/* harmony export */ });
/* unused harmony exports filterUserForClient, generateIssuesForClient, calculateInsertPosition */
function getBaseUrl() {
    if (false) {} // browser should use relative url
    if (process.env.VERCEL_URL) return `https://${process.env.VERCEL_URL}`; // SSR should use vercel url
    return `http://localhost:${process.env.PORT ?? 3000}`; // dev SSR should use localhost
}
function getHeaders() {
    return {
        "Content-type": "application/json"
    };
}
function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}
function capitalizeMany(str) {
    return str.split(" ").map((word)=>capitalize(word)).join(" ");
}
function getIssueCountByStatus(issues) {
    return issues.reduce((acc, issue)=>{
        acc[issue.status]++;
        return acc;
    }, {
        TODO: 0,
        IN_PROGRESS: 0,
        DONE: 0
    });
}
function isEpic(issue) {
    if (!issue) return false;
    return issue.type == "EPIC";
}
function isSubtask(issue) {
    if (!issue) return false;
    return issue.type == "SUBTASK";
}
function hasChildren(issue) {
    if (!issue) return false;
    return issue.children.length > 0;
}
function sprintId(id) {
    return id == "backlog" ? null : id;
}
function isNullish(value) {
    return value == null || value == undefined;
}
function filterUserForClient(user) {
    return {
        id: user.id,
        name: `${user.firstName ?? ""} ${user.lastName ?? ""}`,
        email: user?.emailAddresses[0]?.emailAddress ?? "",
        avatar: user.imageUrl
    };
}
function issueNotInSearch({ issue, search }) {
    return search.length && !(issue.name.toLowerCase().includes(search.toLowerCase()) || issue.assignee?.name.toLowerCase().includes(search.toLowerCase()) || issue.key.toLowerCase().includes(search.toLowerCase()));
}
function assigneeNotInFilters({ issue, assignees }) {
    return assignees.length && !assignees.includes(issue.assignee?.id ?? "unassigned");
}
function epicNotInFilters({ issue, epics }) {
    return epics.length && (!issue.parentId || !epics.includes(issue.parentId));
}
function issueTypeNotInFilters({ issue, issueTypes }) {
    return issueTypes.length && !issueTypes.includes(issue.type);
}
function issueSprintNotInFilters({ issue, sprintIds, excludeBacklog = false }) {
    if (isNullish(issue.sprintId)) {
        if (sprintIds.length && excludeBacklog) return true;
        return false;
    }
    return sprintIds.length && !sprintIds.includes(issue.sprintId);
}
function dateToLongString(date) {
    const dateString = new Date(date).toDateString();
    const timeStirng = new Date(date).toLocaleTimeString();
    return dateString + " at " + timeStirng;
}
function isDone(issue) {
    return issue.status == "DONE";
}
function hexToRgba(hex, opacity) {
    if (!hex) return "rgba(0, 0, 0, 0)";
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${opacity ?? 1})`;
}
function generateIssuesForClient(issues, users, activeSprintIds) {
    // Maps are used to make lookups faster
    const userMap = new Map(users.map((user)=>[
            user.id,
            user
        ]));
    const parentMap = new Map(issues.map((issue)=>[
            issue.id,
            issue
        ]));
    const issuesForClient = issues.map((issue)=>{
        const parent = parentMap.get(issue.parentId ?? "") ?? null;
        const assignee = userMap.get(issue.assigneeId ?? "") ?? null;
        const reporter = userMap.get(issue.reporterId) ?? null;
        const children = issues.filter((i)=>i.parentId === issue.id).map((issue)=>{
            const assignee = userMap.get(issue.assigneeId ?? "") ?? null;
            return Object.assign(issue, {
                assignee
            });
        });
        const sprintIsActive = activeSprintIds?.includes(issue.sprintId ?? "");
        return {
            ...issue,
            sprintIsActive,
            parent,
            assignee,
            reporter,
            children
        };
    });
    return issuesForClient;
}
function calculateInsertPosition(issues) {
    return Math.max(...issues.map((issue)=>issue.sprintPosition), 0) + 1;
}
function moveItemWithinArray(arr, item, newIndex) {
    const arrClone = [
        ...arr
    ];
    const oldIndex = arrClone.indexOf(item);
    const oldItem = arrClone.splice(oldIndex, 1)[0];
    if (oldItem) arrClone.splice(newIndex, 0, oldItem);
    return arrClone;
}
function insertItemIntoArray(arr, item, index) {
    const arrClone = [
        ...arr
    ];
    arrClone.splice(index, 0, item);
    return arrClone;
}
function getPluralEnd(arr) {
    if (arr.length == 0) return "s";
    return arr.length > 1 ? "s" : "";
}


/***/ }),

/***/ 41380:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Hydrate: () => (/* binding */ Hydrate)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(46158);
/* __next_internal_client_entry_do_not_use__ Hydrate auto */ 

function Hydrate(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.Hydrate, {
        ...props
    });
}



/***/ }),

/***/ 8730:
/***/ ((module) => {

// Exports
module.exports = {
	"PlaygroundEditorTheme__ltr": "theme_PlaygroundEditorTheme__ltr__UoT0e",
	"PlaygroundEditorTheme__rtl": "theme_PlaygroundEditorTheme__rtl__xeooF",
	"PlaygroundEditorTheme__paragraph": "theme_PlaygroundEditorTheme__paragraph__FAdcy",
	"PlaygroundEditorTheme__quote": "theme_PlaygroundEditorTheme__quote__rjJbt",
	"PlaygroundEditorTheme__h1": "theme_PlaygroundEditorTheme__h1__IUFcG",
	"PlaygroundEditorTheme__h2": "theme_PlaygroundEditorTheme__h2__mdmdH",
	"PlaygroundEditorTheme__h3": "theme_PlaygroundEditorTheme__h3__Gahaq",
	"PlaygroundEditorTheme__textBold": "theme_PlaygroundEditorTheme__textBold__UOc0K",
	"PlaygroundEditorTheme__textItalic": "theme_PlaygroundEditorTheme__textItalic__AuGT1",
	"PlaygroundEditorTheme__textUnderline": "theme_PlaygroundEditorTheme__textUnderline__pA_I1",
	"PlaygroundEditorTheme__textStrikethrough": "theme_PlaygroundEditorTheme__textStrikethrough__XmxX7",
	"PlaygroundEditorTheme__textUnderlineStrikethrough": "theme_PlaygroundEditorTheme__textUnderlineStrikethrough___Adeg",
	"PlaygroundEditorTheme__textSubscript": "theme_PlaygroundEditorTheme__textSubscript__yjTdJ",
	"PlaygroundEditorTheme__textSuperscript": "theme_PlaygroundEditorTheme__textSuperscript__FHdJv",
	"PlaygroundEditorTheme__textCode": "theme_PlaygroundEditorTheme__textCode__XpT_Z",
	"PlaygroundEditorTheme__hashtag": "theme_PlaygroundEditorTheme__hashtag__1E2Se",
	"PlaygroundEditorTheme__link": "theme_PlaygroundEditorTheme__link__Jto_y",
	"PlaygroundEditorTheme__code": "theme_PlaygroundEditorTheme__code__Acf7x",
	"PlaygroundEditorTheme__table": "theme_PlaygroundEditorTheme__table__lSqMK",
	"PlaygroundEditorTheme__tableSelected": "theme_PlaygroundEditorTheme__tableSelected__elBK_",
	"PlaygroundEditorTheme__tableCell": "theme_PlaygroundEditorTheme__tableCell__DbHIf",
	"PlaygroundEditorTheme__tableCellSortedIndicator": "theme_PlaygroundEditorTheme__tableCellSortedIndicator__o2zJe",
	"PlaygroundEditorTheme__tableCellResizer": "theme_PlaygroundEditorTheme__tableCellResizer__B9zuw",
	"PlaygroundEditorTheme__tableCellHeader": "theme_PlaygroundEditorTheme__tableCellHeader__OYb_w",
	"PlaygroundEditorTheme__tableCellSelected": "theme_PlaygroundEditorTheme__tableCellSelected__mmdfc",
	"PlaygroundEditorTheme__tableCellPrimarySelected": "theme_PlaygroundEditorTheme__tableCellPrimarySelected__s6QBT",
	"PlaygroundEditorTheme__tableCellEditing": "theme_PlaygroundEditorTheme__tableCellEditing__jRUYV",
	"PlaygroundEditorTheme__tableAddColumns": "theme_PlaygroundEditorTheme__tableAddColumns__4fKzm",
	"table-controls": "theme_table-controls__jxzj2",
	"PlaygroundEditorTheme__tableAddRows": "theme_PlaygroundEditorTheme__tableAddRows__wD8xi",
	"PlaygroundEditorTheme__tableCellResizeRuler": "theme_PlaygroundEditorTheme__tableCellResizeRuler__Jpo96",
	"PlaygroundEditorTheme__tableCellActionButtonContainer": "theme_PlaygroundEditorTheme__tableCellActionButtonContainer__v4LuK",
	"PlaygroundEditorTheme__tableCellActionButton": "theme_PlaygroundEditorTheme__tableCellActionButton__6ZA_d",
	"PlaygroundEditorTheme__characterLimit": "theme_PlaygroundEditorTheme__characterLimit__U7BQ3",
	"PlaygroundEditorTheme__ol1": "theme_PlaygroundEditorTheme__ol1__ok_m3",
	"PlaygroundEditorTheme__ol2": "theme_PlaygroundEditorTheme__ol2__HgqjM",
	"PlaygroundEditorTheme__ol3": "theme_PlaygroundEditorTheme__ol3__35ivo",
	"PlaygroundEditorTheme__ol4": "theme_PlaygroundEditorTheme__ol4__fUgjP",
	"PlaygroundEditorTheme__ol5": "theme_PlaygroundEditorTheme__ol5__u0phj",
	"PlaygroundEditorTheme__ul": "theme_PlaygroundEditorTheme__ul__xQmpf",
	"PlaygroundEditorTheme__listItem": "theme_PlaygroundEditorTheme__listItem__6ivzD",
	"PlaygroundEditorTheme__listItemChecked": "theme_PlaygroundEditorTheme__listItemChecked__RXWzM",
	"PlaygroundEditorTheme__listItemUnchecked": "theme_PlaygroundEditorTheme__listItemUnchecked__k2G_x",
	"PlaygroundEditorTheme__nestedListItem": "theme_PlaygroundEditorTheme__nestedListItem__GoCjw",
	"PlaygroundEditorTheme__tokenComment": "theme_PlaygroundEditorTheme__tokenComment__f8c9M",
	"PlaygroundEditorTheme__tokenPunctuation": "theme_PlaygroundEditorTheme__tokenPunctuation__FvZzO",
	"PlaygroundEditorTheme__tokenProperty": "theme_PlaygroundEditorTheme__tokenProperty__Qq2ix",
	"PlaygroundEditorTheme__tokenSelector": "theme_PlaygroundEditorTheme__tokenSelector__hUEbc",
	"PlaygroundEditorTheme__tokenOperator": "theme_PlaygroundEditorTheme__tokenOperator__BWWqz",
	"PlaygroundEditorTheme__tokenAttr": "theme_PlaygroundEditorTheme__tokenAttr__nqKjH",
	"PlaygroundEditorTheme__tokenVariable": "theme_PlaygroundEditorTheme__tokenVariable__bqeZr",
	"PlaygroundEditorTheme__tokenFunction": "theme_PlaygroundEditorTheme__tokenFunction__QkSGM",
	"PlaygroundEditorTheme__mark": "theme_PlaygroundEditorTheme__mark__vtI3J",
	"PlaygroundEditorTheme__markOverlap": "theme_PlaygroundEditorTheme__markOverlap__G7zOx",
	"selected": "theme_selected__BvvB1",
	"PlaygroundEditorTheme__embedBlock": "theme_PlaygroundEditorTheme__embedBlock__CcZEG",
	"PlaygroundEditorTheme__embedBlockFocus": "theme_PlaygroundEditorTheme__embedBlockFocus__7zgEw"
};


/***/ }),

/***/ 86484:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/home/oleksii/Documents/Projects/SoftServe/vagrant-test/app/app/project/layout.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 57042:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Kl: () => (/* binding */ IssueSkeleton),
/* harmony export */   Li: () => (/* binding */ TitleSkeleton),
/* harmony export */   St: () => (/* binding */ BreadCrumbSkeleton),
/* harmony export */   UL: () => (/* binding */ SprintSearchSkeleton),
/* harmony export */   Xg: () => (/* binding */ SprintHeaderSkeleton),
/* harmony export */   iM: () => (/* binding */ BoardColumnSkeleton),
/* harmony export */   jr: () => (/* binding */ RoadmapTableSkeleton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const IssueSkeleton = ({ size })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex w-full items-center justify-between",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex items-center gap-x-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-3 w-4 rounded-md bg-gray-100"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-3 w-14 rounded-md bg-gray-100"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: {
                            width: size
                        },
                        className: "h-3 rounded-md bg-gray-100"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex items-center gap-x-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: {
                            width: size * 0.7
                        },
                        className: "h-4 rounded-md bg-gray-100"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-6 w-6 rounded-full bg-gray-100"
                    })
                ]
            })
        ]
    });
};
const BreadCrumbSkeleton = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "mb-3 flex items-center gap-x-4",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "h-3 w-16 rounded-full bg-gray-100 "
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "h-3 w-28 rounded-full bg-gray-100 "
            })
        ]
    });
};
const TitleSkeleton = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex items-center justify-between",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "h-4 w-40 rounded-md bg-gray-100 "
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex gap-x-2",
                children: [
                    ...Array(3).keys()
                ].map((el, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-8 w-8 rounded-md bg-gray-100"
                    }, index))
            })
        ]
    });
};
const SprintHeaderSkeleton = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex items-center justify-between",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "h-4 w-48 rounded-md bg-gray-100 "
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex gap-x-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-8 w-16 rounded-md bg-gray-100"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-8 w-8 rounded-md bg-gray-100"
                    })
                ]
            })
        ]
    });
};
const SprintSearchSkeleton = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "mb-3 flex items-center justify-between py-2",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex items-center gap-x-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-10 w-32 rounded-md bg-gray-100"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-8 w-8 rounded-full bg-gray-100"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-8 w-8 rounded-full bg-gray-100"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "ml-2 h-3 w-12 rounded-lg bg-gray-100"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "ml-2 h-3 w-12 rounded-lg bg-gray-100"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "h-8 w-32 rounded-md bg-gray-100"
            })
        ]
    });
};
const BoardColumnSkeleton = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "h-[550px] w-64 rounded-md bg-gray-100"
    });
};
const RoadmapTableSkeleton = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "relative h-fit rounded-md border-2 border-gray-100",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "h-12 border-b-2 border-gray-100 bg-gray-100"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-col",
                children: [
                    ...Array(12).keys()
                ].map((el, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex items-center gap-x-4 border-b px-6 py-2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(IssueSkeleton, {
                            size: index % 2 === 0 ? 300 : 400
                        })
                    }, index))
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "sticky bottom-0 h-12 border-b-2 border-gray-100 bg-gray-100"
            })
        ]
    });
};



/***/ }),

/***/ 7431:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   W: () => (/* binding */ Container)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(28922);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);


const Container = ({ className, screen, children })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_1___default()(screen ? "item flex h-screen w-screen items-center justify-center" : "max-w-9xl mx-auto px-4 sm:px-6 sm:py-4 lg:px-8", className),
        children: children
    });
};



/***/ }),

/***/ 74960:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   V: () => (/* binding */ e0)
/* harmony export */ });
/* unused harmony export useSelectedIssueContext */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/home/oleksii/Documents/Projects/SoftServe/vagrant-test/app/context/use-selected-issue-context.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["SelectedIssueProvider"];

const e1 = proxy["useSelectedIssueContext"];


/***/ }),

/***/ 84305:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Xp: () => (/* binding */ getInitialIssuesFromServer),
  v1: () => (/* binding */ getInitialProjectFromServer),
  hq: () => (/* binding */ getInitialSprintsFromServer)
});

// UNUSED EXPORTS: initDefaultIssueComments, initDefaultIssues, initDefaultProjectMembers, initDefaultSprints, initDefaultUsers, initProject

// EXTERNAL MODULE: ./utils/helpers.ts
var helpers = __webpack_require__(29688);
;// CONCATENATED MODULE: ./prisma/seed-data.ts
function generateInitialUserComments(userId) {
    const now = new Date();
    const slicedUserId = userId ? userId.slice(5, 12) : "init";
    return [
        {
            id: "3c076895-c356-43d8-" + slicedUserId,
            content: '{"root":{"children":[{"children":[{"detail":0,"format":0,"mode":"normal","style":"","text":"I must express my astonishment at the sheer lack of scientific rigor in your proposed solution. It appears to be nothing more than a fanciful flight of fancy, devoid of any logical foundation. I implore you to reconsider and approach the problem with the intellect it deserves. Sincerely, Dr. Sheldon Cooper.","type":"text","version":1}],"direction":"ltr","format":"","indent":0,"type":"paragraph","version":1}],"direction":"ltr","format":"","indent":0,"type":"root","version":1}}',
            authorId: "user_2PvBRngdvenUlFvQNAWbXIvYVy5",
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            isEdited: false,
            issueId: "cd44dff4-d69b-4724-" + slicedUserId,
            logId: null
        },
        {
            id: "87423726-9cdb-4e03-" + slicedUserId,
            content: '{"root":{"children":[{"children":[{"detail":0,"format":0,"mode":"normal","style":"","text":"Thank you for your concerns, but innovation knows no boundaries. We will persist in exploring new possibilities.","type":"text","version":1}],"direction":"ltr","format":"","indent":0,"type":"paragraph","version":1}],"direction":"ltr","format":"","indent":0,"type":"root","version":1}}',
            authorId: "user_2PwYvTgm6kvgJIbWwN0xsei8izu",
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            isEdited: false,
            issueId: "55a7d19e-844c-40fd-" + slicedUserId,
            logId: null
        },
        {
            id: "eef0aeb3-9407-4836-" + slicedUserId,
            content: '{"root":{"children":[{"children":[{"detail":0,"format":0,"mode":"normal","style":"","text":"It has come to my attention that your proposed solution violates the fundamental laws of physics, rendering it completely untenable. As an intellectual of superior intellect, it is my obligation to point out such grave errors in your approach. I suggest you reconsider your strategy and consult with me, Dr. Sheldon Cooper, before making any further attempts. Rest assured, I will be available to guide you toward the correct path of logical reasoning and scientific principles. Thank you.","type":"text","version":1}],"direction":"ltr","format":"","indent":0,"type":"paragraph","version":1}],"direction":"ltr","format":"","indent":0,"type":"root","version":1}}',
            authorId: "user_2PvBRngdvenUlFvQNAWbXIvYVy5",
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            isEdited: false,
            issueId: "55a7d19e-844c-40fd-" + slicedUserId,
            logId: null
        }
    ];
}
function generateInitialUserSprints(userId) {
    const now = new Date();
    const oneWeekFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    const slicedUserId = userId ? userId.slice(5, 12) : "init";
    return [
        {
            id: "edd0e2b1-b230-4f02-" + slicedUserId,
            name: "Bazinga Blitz",
            description: "",
            duration: "1 week",
            startDate: now,
            endDate: oneWeekFromNow,
            creatorId: userId,
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            status: "ACTIVE"
        },
        {
            id: "880ececc-f628-4de3-" + slicedUserId,
            name: "Cognitive Conundrum",
            description: "Lets figure out this conundrum together.",
            duration: "3 weeks",
            startDate: null,
            endDate: null,
            creatorId: userId,
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            status: "PENDING"
        }
    ];
}
function generateInitialUserIssues(userId) {
    const now = new Date();
    const slicedUserId = userId ? userId.slice(5, 12) : "init";
    return [
        {
            id: "1c5818e1-b920-45b2-" + slicedUserId,
            key: "ISSUE-12",
            name: "Issue types can be changed, click here and try it out!",
            description: null,
            status: "TODO",
            type: "STORY",
            sprintPosition: 1,
            boardPosition: -1,
            reporterId: "user_2PwZmH2xP5aE0svR6hDH4AwDlcu",
            assigneeId: null,
            parentId: "b6e4ace2-6911-40c6-" + slicedUserId,
            sprintId: "880ececc-f628-4de3-" + slicedUserId,
            isDeleted: false,
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            sprintColor: null,
            creatorId: userId
        },
        {
            id: "2f04b476-5a2b-4073-" + slicedUserId,
            key: "ISSUE-8",
            name: "This is also a child issue",
            description: null,
            status: "TODO",
            type: "SUBTASK",
            sprintPosition: 4,
            boardPosition: -1,
            reporterId: "user_2PwZmH2xP5aE0svR6hDH4AwDlcu",
            assigneeId: null,
            parentId: "6f139401-d32e-4386-" + slicedUserId,
            sprintId: null,
            isDeleted: false,
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            sprintColor: null,
            creatorId: userId
        },
        {
            id: "5521fc5a-af0b-4905-" + slicedUserId,
            key: "ISSUE-11",
            name: "Try editing the title of this bug!",
            description: null,
            status: "IN_PROGRESS",
            type: "BUG",
            sprintPosition: 7,
            boardPosition: -1,
            reporterId: "user_2PwZmH2xP5aE0svR6hDH4AwDlcu",
            assigneeId: null,
            parentId: "70c4152c-2063-47ad-" + slicedUserId,
            sprintId: null,
            isDeleted: false,
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            sprintColor: null,
            creatorId: userId
        },
        {
            id: "55a7d19e-844c-40fd-" + slicedUserId,
            key: "ISSUE-3",
            name: "Each issue can contain comments by the project's members",
            description: null,
            status: "DONE",
            type: "TASK",
            sprintPosition: 2,
            boardPosition: -1,
            reporterId: "user_2PwZmH2xP5aE0svR6hDH4AwDlcu",
            assigneeId: "user_2PvBRngdvenUlFvQNAWbXIvYVy5",
            parentId: null,
            sprintId: "edd0e2b1-b230-4f02-" + slicedUserId,
            isDeleted: false,
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            sprintColor: null,
            creatorId: userId
        },
        {
            id: "6f139401-d32e-4386-" + slicedUserId,
            key: "ISSUE-6",
            name: "Click here to see the child issues of this task",
            description: null,
            status: "TODO",
            type: "TASK",
            sprintPosition: 4,
            boardPosition: 1,
            reporterId: "user_2PwZmH2xP5aE0svR6hDH4AwDlcu",
            assigneeId: "user_2PvBRngdvenUlFvQNAWbXIvYVy5",
            parentId: null,
            sprintId: "edd0e2b1-b230-4f02-" + slicedUserId,
            isDeleted: false,
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            sprintColor: null,
            creatorId: userId
        },
        {
            id: "70c4152c-2063-47ad-" + slicedUserId,
            key: "ISSUE-10",
            name: "Visionary Ventures",
            description: null,
            status: "TODO",
            type: "EPIC",
            sprintPosition: 6,
            boardPosition: -1,
            reporterId: "user_2PwZmH2xP5aE0svR6hDH4AwDlcu",
            assigneeId: null,
            parentId: null,
            sprintId: null,
            isDeleted: false,
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            sprintColor: "#f97463",
            creatorId: userId
        },
        {
            id: "7f9b5dba-6017-4e56-" + slicedUserId,
            key: "ISSUE-1",
            name: "Issue descriptions can contain code snippets",
            description: '{"root":{"children":[{"children":[{"detail":0,"format":0,"mode":"normal","style":"","text":"Find the bug...","type":"text","version":1}],"direction":"ltr","format":"","indent":0,"type":"heading","version":1,"tag":"h1"},{"children":[{"detail":0,"format":0,"mode":"normal","style":"","text":"function","type":"code-highlight","version":1,"highlightType":"keyword"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"numIsInArray","type":"code-highlight","version":1,"highlightType":"function"},{"detail":0,"format":0,"mode":"normal","style":"","text":"(","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":"arr","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":",","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":" num","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":")","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"{","type":"code-highlight","version":1,"highlightType":"punctuation"},{"type":"linebreak","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"  ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"let","type":"code-highlight","version":1,"highlightType":"keyword"},{"detail":0,"format":0,"mode":"normal","style":"","text":" start ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"=","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"0","type":"code-highlight","version":1,"highlightType":"number"},{"detail":0,"format":0,"mode":"normal","style":"","text":";","type":"code-highlight","version":1,"highlightType":"punctuation"},{"type":"linebreak","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"  ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"let","type":"code-highlight","version":1,"highlightType":"keyword"},{"detail":0,"format":0,"mode":"normal","style":"","text":" end ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"=","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" arr","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":".","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":"length ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"-","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"1","type":"code-highlight","version":1,"highlightType":"number"},{"detail":0,"format":0,"mode":"normal","style":"","text":";","type":"code-highlight","version":1,"highlightType":"punctuation"},{"type":"linebreak","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"  ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"const","type":"code-highlight","version":1,"highlightType":"keyword"},{"detail":0,"format":0,"mode":"normal","style":"","text":" middle ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"=","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" Math","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":".","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":"floor","type":"code-highlight","version":1,"highlightType":"function"},{"detail":0,"format":0,"mode":"normal","style":"","text":"(","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":"(","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":"start ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"+","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" end","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":")","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"/","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"2","type":"code-highlight","version":1,"highlightType":"number"},{"detail":0,"format":0,"mode":"normal","style":"","text":")","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":";","type":"code-highlight","version":1,"highlightType":"punctuation"},{"type":"linebreak","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"  ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"let","type":"code-highlight","version":1,"highlightType":"keyword"},{"detail":0,"format":0,"mode":"normal","style":"","text":" found ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"=","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"false","type":"code-highlight","version":1,"highlightType":"boolean"},{"detail":0,"format":0,"mode":"normal","style":"","text":";","type":"code-highlight","version":1,"highlightType":"punctuation"},{"type":"linebreak","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"  ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"while","type":"code-highlight","version":1,"highlightType":"keyword"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"(","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":"start ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"<=","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" end ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"&&","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"!","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":"found","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":")","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"{","type":"code-highlight","version":1,"highlightType":"punctuation"},{"type":"linebreak","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"    ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"if","type":"code-highlight","version":1,"highlightType":"keyword"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"(","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":"arr","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"[","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":"middle","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"]","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"===","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" num","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":")","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"{","type":"code-highlight","version":1,"highlightType":"punctuation"},{"type":"linebreak","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"      found ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"=","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"true","type":"code-highlight","version":1,"highlightType":"boolean"},{"detail":0,"format":0,"mode":"normal","style":"","text":";","type":"code-highlight","version":1,"highlightType":"punctuation"},{"type":"linebreak","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"    ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"}","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"else","type":"code-highlight","version":1,"highlightType":"keyword"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"if","type":"code-highlight","version":1,"highlightType":"keyword"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"(","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":"num ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"<","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" arr","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"[","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":"middle","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"]","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":")","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"{","type":"code-highlight","version":1,"highlightType":"punctuation"},{"type":"linebreak","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"      end ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"=","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" middle ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"-","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"1","type":"code-highlight","version":1,"highlightType":"number"},{"detail":0,"format":0,"mode":"normal","style":"","text":";","type":"code-highlight","version":1,"highlightType":"punctuation"},{"type":"linebreak","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"    ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"}","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"else","type":"code-highlight","version":1,"highlightType":"keyword"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"{","type":"code-highlight","version":1,"highlightType":"punctuation"},{"type":"linebreak","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"      start ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"=","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" middle ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"+","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"1","type":"code-highlight","version":1,"highlightType":"number"},{"detail":0,"format":0,"mode":"normal","style":"","text":";","type":"code-highlight","version":1,"highlightType":"punctuation"},{"type":"linebreak","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"    ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"}","type":"code-highlight","version":1,"highlightType":"punctuation"},{"type":"linebreak","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"    middle ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"=","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" Math","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":".","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":"floor","type":"code-highlight","version":1,"highlightType":"function"},{"detail":0,"format":0,"mode":"normal","style":"","text":"(","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":"(","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":"start ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"+","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" end","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":")","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"/","type":"code-highlight","version":1,"highlightType":"operator"},{"detail":0,"format":0,"mode":"normal","style":"","text":" ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"2","type":"code-highlight","version":1,"highlightType":"number"},{"detail":0,"format":0,"mode":"normal","style":"","text":")","type":"code-highlight","version":1,"highlightType":"punctuation"},{"detail":0,"format":0,"mode":"normal","style":"","text":";","type":"code-highlight","version":1,"highlightType":"punctuation"},{"type":"linebreak","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"  ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"}","type":"code-highlight","version":1,"highlightType":"punctuation"},{"type":"linebreak","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"  ","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"return","type":"code-highlight","version":1,"highlightType":"keyword"},{"detail":0,"format":0,"mode":"normal","style":"","text":" found","type":"code-highlight","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":";","type":"code-highlight","version":1,"highlightType":"punctuation"},{"type":"linebreak","version":1},{"detail":0,"format":0,"mode":"normal","style":"","text":"}","type":"code-highlight","version":1,"highlightType":"punctuation"}],"direction":"ltr","format":"","indent":0,"type":"code","version":1,"language":"javascript"}],"direction":"ltr","format":"","indent":0,"type":"root","version":1}}',
            status: "IN_PROGRESS",
            type: "BUG",
            sprintPosition: 1,
            boardPosition: 0,
            reporterId: "user_2PwZmH2xP5aE0svR6hDH4AwDlcu",
            assigneeId: "user_2PwYvTgm6kvgJIbWwN0xsei8izu",
            parentId: null,
            sprintId: "edd0e2b1-b230-4f02-" + slicedUserId,
            isDeleted: false,
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            sprintColor: null,
            creatorId: userId
        },
        {
            id: "af3dde63-3ddb-4e72-" + slicedUserId,
            key: "ISSUE-4",
            name: "Issues can belong to an Epic",
            description: null,
            status: "IN_PROGRESS",
            type: "TASK",
            sprintPosition: 3,
            boardPosition: -1,
            reporterId: "user_2PwZmH2xP5aE0svR6hDH4AwDlcu",
            assigneeId: "user_2PwYvTgm6kvgJIbWwN0xsei8izu",
            parentId: "b6e4ace2-6911-40c6-" + slicedUserId,
            sprintId: "edd0e2b1-b230-4f02-" + slicedUserId,
            isDeleted: false,
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            sprintColor: null,
            creatorId: userId
        },
        {
            id: "b6e4ace2-6911-40c6-" + slicedUserId,
            key: "ISSUE-5",
            name: "Think Different Odyssey",
            description: null,
            status: "TODO",
            type: "EPIC",
            sprintPosition: 2,
            boardPosition: -1,
            reporterId: "user_2PwZmH2xP5aE0svR6hDH4AwDlcu",
            assigneeId: null,
            parentId: null,
            sprintId: null,
            isDeleted: false,
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            sprintColor: "#0b66e4",
            creatorId: userId
        },
        {
            id: "cd44dff4-d69b-4724-" + slicedUserId,
            key: "ISSUE-2",
            name: "This is an issue of type: STORY",
            description: '{"root":{"children":[{"children":[{"detail":0,"format":1,"mode":"normal","style":"","text":"Comments can have emojis..","type":"text","version":1}],"direction":"ltr","format":"","indent":0,"type":"paragraph","version":1},{"children":[{"detail":0,"format":0,"mode":"normal","style":"","text":"\uD83D\uDCA9\uD83E\uDD78\uD83D\uDE21\uD83E\uDD8A\uD83D\uDC22\uD83E\uDD5D\uD83C\uDFC8\uD83E\uDDE8\uD83C\uDF63","type":"text","version":1}],"direction":"ltr","format":"","indent":0,"type":"heading","version":1,"tag":"h1"}],"direction":"ltr","format":"","indent":0,"type":"root","version":1}}',
            status: "DONE",
            type: "STORY",
            sprintPosition: 1,
            boardPosition: -1,
            reporterId: "user_2PwZmH2xP5aE0svR6hDH4AwDlcu",
            assigneeId: "user_2PwZmH2xP5aE0svR6hDH4AwDlcu",
            parentId: "70c4152c-2063-47ad-" + slicedUserId,
            sprintId: null,
            isDeleted: false,
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            sprintColor: null,
            creatorId: userId
        },
        {
            id: "ecab71cf-a4d7-4416-" + slicedUserId,
            key: "ISSUE-9",
            name: "Child issues have statuses as well",
            description: null,
            status: "DONE",
            type: "SUBTASK",
            sprintPosition: 5,
            boardPosition: -1,
            reporterId: "user_2PwZmH2xP5aE0svR6hDH4AwDlcu",
            assigneeId: null,
            parentId: "6f139401-d32e-4386-" + slicedUserId,
            sprintId: null,
            isDeleted: false,
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            sprintColor: null,
            creatorId: userId
        },
        {
            id: "fd552347-0e93-4c98-" + slicedUserId,
            key: "ISSUE-7",
            name: "This is a child issue",
            description: null,
            status: "TODO",
            type: "SUBTASK",
            sprintPosition: 3,
            boardPosition: -1,
            reporterId: "user_2PwZmH2xP5aE0svR6hDH4AwDlcu",
            assigneeId: null,
            parentId: "6f139401-d32e-4386-" + slicedUserId,
            sprintId: null,
            isDeleted: false,
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            sprintColor: null,
            creatorId: userId
        }
    ];
}
const seed_data_defaultUsers = [
    {
        id: "user_2PwZmH2xP5aE0svR6hDH4AwDlcu",
        name: "Joe Rogan",
        email: "joe.rogan@jira.com",
        avatar: "https://images.clerk.dev/uploaded/img_2PwZslOi493tjduHiBADgDxhHlg.png"
    },
    {
        id: "user_2PwYvTgm6kvgJIbWwN0xsei8izu",
        name: "Steve Jobs",
        email: "steve.jobs@jira.com",
        avatar: "https://images.clerk.dev/uploaded/img_2PwjGSsR9nGqEhAyt5nydgXhBI1.webp"
    },
    {
        id: "user_2PvBRngdvenUlFvQNAWbXIvYVy5",
        name: "Sheldon Cooper",
        email: "sheldon.cooper@jira.com",
        avatar: "https://images.clerk.dev/uploaded/img_2Pwinee7Eg6qoSgqailCZSJt3uS.webp"
    }
];

// EXTERNAL MODULE: ./server/db.ts + 1 modules
var db = __webpack_require__(84952);
// EXTERNAL MODULE: external "@prisma/client"
var client_ = __webpack_require__(53524);
;// CONCATENATED MODULE: ./server/functions.ts




async function getInitialIssuesFromServer(userId) {
    let activeIssues = await db/* prisma */._.issue.findMany({
        where: {
            isDeleted: false,
            creatorId: userId ?? "init"
        }
    });
    if (userId && (!activeIssues || activeIssues.length === 0)) {
        // New user, create default issues
        await initDefaultIssues(userId);
        // Create comments for default issues
        await initDefaultIssueComments(userId);
        const newActiveIssues = await db/* prisma */._.issue.findMany({
            where: {
                creatorId: userId,
                isDeleted: false
            }
        });
        activeIssues = newActiveIssues;
    }
    if (!activeIssues || activeIssues.length === 0) {
        return [];
    }
    const activeSprints = await db/* prisma */._.sprint.findMany({
        where: {
            status: "ACTIVE"
        }
    });
    const userIds = activeIssues.flatMap((issue)=>[
            issue.assigneeId,
            issue.reporterId
        ]).filter(Boolean);
    // USE THIS IF RUNNING LOCALLY ----------------------
    const users = await db/* prisma */._.defaultUser.findMany({
        where: {
            id: {
                in: userIds
            }
        }
    });
    // --------------------------------------------------
    // COMMENT THIS IF RUNNING LOCALLY ------------------
    // const users = (
    //   await clerkClient.users.getUserList({
    //     userId: userIds,
    //     limit: 20,
    //   })
    // ).map(filterUserForClient);
    // --------------------------------------------------
    const issues = (0,helpers/* generateIssuesForClient */.Iw)(activeIssues, users, activeSprints.map((sprint)=>sprint.id));
    return issues;
}
async function getInitialProjectFromServer() {
    const project = await db/* prisma */._.project.findUnique({
        where: {
            key: "JIRA-CLONE"
        }
    });
    return project;
}
async function getInitialSprintsFromServer(userId) {
    let sprints = await db/* prisma */._.sprint.findMany({
        where: {
            OR: [
                {
                    status: client_.SprintStatus.ACTIVE
                },
                {
                    status: client_.SprintStatus.PENDING
                }
            ],
            creatorId: userId ?? "init"
        },
        orderBy: {
            createdAt: "asc"
        }
    });
    if (userId && (!sprints || sprints.length === 0)) {
        // New user, create default sprints
        await initDefaultSprints(userId);
        const newSprints = await db/* prisma */._.sprint.findMany({
            where: {
                creatorId: userId
            }
        });
        sprints = newSprints;
    }
    return sprints;
}
async function initProject() {
    await prisma.project.upsert({
        where: {
            id: "init-project-id-dq8yh-d0as89hjd"
        },
        update: {},
        create: {
            id: "init-project-id-dq8yh-d0as89hjd",
            name: "Jira Clone Project",
            key: "JIRA-CLONE"
        }
    });
}
async function initDefaultUsers() {
    await Promise.all(defaultUsers.map(async (user)=>await prisma.defaultUser.upsert({
            where: {
                id: user.id
            },
            update: {
                avatar: user.avatar
            },
            create: {
                id: user.id,
                email: user.email,
                name: user.name,
                avatar: user.avatar
            }
        })));
}
async function initDefaultProjectMembers() {
    await Promise.all(defaultUsers.map(async (user)=>await prisma.member.upsert({
            where: {
                id: user.id
            },
            update: {},
            create: {
                id: user.id,
                projectId: "init-project-id-dq8yh-d0as89hjd"
            }
        })));
}
async function initDefaultIssues(userId) {
    const initialIssues = generateInitialUserIssues(userId);
    await Promise.all(initialIssues.map(async (issue)=>await db/* prisma */._.issue.upsert({
            where: {
                id: issue.id
            },
            update: {},
            create: {
                ...issue
            }
        })));
}
async function initDefaultIssueComments(userId) {
    const initialComments = generateInitialUserComments(userId);
    await Promise.all(initialComments.map(async (comment)=>await db/* prisma */._.comment.upsert({
            where: {
                id: comment.id
            },
            update: {},
            create: {
                ...comment
            }
        })));
}
async function initDefaultSprints(userId) {
    const initialSprints = generateInitialUserSprints(userId);
    await Promise.all(initialSprints.map(async (sprint)=>await db/* prisma */._.sprint.upsert({
            where: {
                id: sprint.id
            },
            update: {},
            create: {
                ...sprint
            }
        })));
}


/***/ }),

/***/ 77615:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   g: () => (/* binding */ getQueryClient)
/* harmony export */ });
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(97717);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7887);


const getQueryClient = (0,react__WEBPACK_IMPORTED_MODULE_0__.cache)(()=>new _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__/* .QueryClient */ .S());



/***/ }),

/***/ 85517:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   p: () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/home/oleksii/Documents/Projects/SoftServe/vagrant-test/app/utils/hydrate.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["Hydrate"];


/***/ }),

/***/ 19746:
/***/ (() => {



/***/ })

};
;