"use strict";
exports.id = 669;
exports.ids = [669];
exports.modules = {

/***/ 14669:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   rl: () => (/* binding */ createGetAuth),
/* harmony export */   v0: () => (/* binding */ getAuth)
/* harmony export */ });
/* unused harmony export parseJwt */
/* harmony import */ var _clerk_backend__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(50646);
/* harmony import */ var _clerk_backend__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_clerk_backend__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _clerk_shared_deprecated__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87351);
/* harmony import */ var _utils_debugLogger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(28857);
/* harmony import */ var _clerkClient__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4823);
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(19611);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(90057);






const createGetAuth = ({ debugLoggerName, noAuthStatusMessage })=>(0,_utils_debugLogger__WEBPACK_IMPORTED_MODULE_2__/* .withLogger */ .n)(debugLoggerName, (logger)=>{
        return (req, opts)=>{
            if ((0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .getHeader */ .Pg)(req, _clerk_backend__WEBPACK_IMPORTED_MODULE_0__.constants.Headers.EnableDebug) === "true") {
                logger.enable();
            }
            const authToken = (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .getAuthKeyFromRequest */ .to)(req, "AuthToken");
            const authStatus = (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .getAuthKeyFromRequest */ .to)(req, "AuthStatus");
            const authMessage = (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .getAuthKeyFromRequest */ .to)(req, "AuthMessage");
            const authReason = (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .getAuthKeyFromRequest */ .to)(req, "AuthReason");
            logger.debug("Debug", {
                authReason,
                authMessage,
                authStatus,
                authToken
            });
            if (!authStatus) {
                throw new Error(noAuthStatusMessage);
            }
            const options = {
                apiKey: opts?.apiKey || _clerkClient__WEBPACK_IMPORTED_MODULE_4__/* .API_KEY */ .$h,
                authStatus,
                authMessage,
                secretKey: opts?.secretKey || _clerkClient__WEBPACK_IMPORTED_MODULE_4__/* .SECRET_KEY */ .Cn,
                authReason,
                authToken,
                apiUrl: _clerkClient__WEBPACK_IMPORTED_MODULE_4__/* .API_URL */ .T5,
                apiVersion: _clerkClient__WEBPACK_IMPORTED_MODULE_4__/* .API_VERSION */ .Gn
            };
            logger.debug("Options debug", options);
            if (authStatus !== _clerk_backend__WEBPACK_IMPORTED_MODULE_0__.AuthStatus.SignedIn) {
                return (0,_clerk_backend__WEBPACK_IMPORTED_MODULE_0__.signedOutAuthObject)(options);
            }
            const jwt = (0,_clerk_backend__WEBPACK_IMPORTED_MODULE_0__.decodeJwt)(authToken);
            logger.debug("JWT debug", jwt.raw.text);
            const signedIn = (0,_clerk_backend__WEBPACK_IMPORTED_MODULE_0__.signedInAuthObject)(jwt.payload, {
                ...options,
                token: jwt.raw.text
            });
            if (signedIn) {
                if (signedIn.user) {
                    (0,_clerk_shared_deprecated__WEBPACK_IMPORTED_MODULE_1__/* .deprecatedObjectProperty */ .x6)(signedIn, "user", "Use `clerkClient.users.getUser` instead.");
                }
                if (signedIn.organization) {
                    (0,_clerk_shared_deprecated__WEBPACK_IMPORTED_MODULE_1__/* .deprecatedObjectProperty */ .x6)(signedIn, "organization", "Use `clerkClient.organizations.getOrganization` instead.");
                }
                if (signedIn.session) {
                    (0,_clerk_shared_deprecated__WEBPACK_IMPORTED_MODULE_1__/* .deprecatedObjectProperty */ .x6)(signedIn, "session", "Use `clerkClient.sessions.getSession` instead.");
                }
            }
            return signedIn;
        };
    });
const parseJwt = (req)=>{
    const cookieToken = getCookie(req, constants.Cookies.Session);
    const headerToken = getHeader(req, "authorization")?.replace("Bearer ", "");
    return decodeJwt(cookieToken || headerToken || "");
};
const getAuth = createGetAuth({
    debugLoggerName: "getAuth()",
    noAuthStatusMessage: (0,_errors__WEBPACK_IMPORTED_MODULE_5__/* .getAuthAuthHeaderMissing */ .PL)()
});
 //# sourceMappingURL=createGetAuth.js.map


/***/ }),

/***/ 28857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  n: () => (/* binding */ withLogger)
});

// UNUSED EXPORTS: createDebugLogger

;// CONCATENATED MODULE: ./node_modules/next/package.json
const package_namespaceObject = {"i8":"13.4.6"};
;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/utils/logFormatter.js
const maskSecretKey = (str)=>{
    if (!str || typeof str !== "string") {
        return str;
    }
    try {
        return (str || "").replace(/^(sk_(live|test)_)(.+?)(.{3})$/, "$1*********$4");
    } catch (e) {
        return "";
    }
};
const logFormatter = (entry)=>{
    return (Array.isArray(entry) ? entry : [
        entry
    ]).map((entry2)=>{
        if (typeof entry2 === "string") {
            return maskSecretKey(entry2);
        }
        const masked = Object.fromEntries(Object.entries(entry2).map(([k, v])=>[
                k,
                maskSecretKey(v)
            ]));
        return JSON.stringify(masked, null, 2);
    }).join(", ");
};
 //# sourceMappingURL=logFormatter.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/utils/debugLogger.js


const createDebugLogger = (name, formatter)=>()=>{
        const entries = [];
        let isEnabled = false;
        return {
            enable: ()=>{
                isEnabled = true;
            },
            debug: (...args)=>{
                if (isEnabled) {
                    entries.push(args.map((arg)=>typeof arg === "function" ? arg() : arg));
                }
            },
            commit: ()=>{
                if (isEnabled) {
                    console.log(debugLogHeader(name));
                    for (const log of entries){
                        let output = formatter(log);
                        output = output.split("\n").map((l)=>`  ${l}`).join("\n");
                        if (process.env.VERCEL) {
                            output = truncate(output, 4096);
                        }
                        console.log(output);
                    }
                    console.log(debugLogFooter(name));
                }
            }
        };
    };
const withLogger = (loggerFactoryOrName, handlerCtor)=>{
    return (...args)=>{
        const factory = typeof loggerFactoryOrName === "string" ? createDebugLogger(loggerFactoryOrName, logFormatter) : loggerFactoryOrName;
        const logger = factory();
        const handler = handlerCtor(logger);
        try {
            const res = handler(...args);
            if (typeof res === "object" && "then" in res && typeof res.then === "function") {
                return res.then((val)=>{
                    logger.commit();
                    return val;
                }).catch((err)=>{
                    logger.commit();
                    throw err;
                });
            }
            logger.commit();
            return res;
        } catch (err) {
            logger.commit();
            throw err;
        }
    };
};
function debugLogHeader(name) {
    return `[clerk debug start: ${name}]`;
}
function debugLogFooter(name) {
    return `[clerk debug end: ${name}] (@clerk/nextjs=${"4.29.5"},next=${package_namespaceObject.i8})`;
}
function truncate(str, maxLength) {
    const encoder = new TextEncoder();
    const decoder = new TextDecoder("utf-8");
    const encodedString = encoder.encode(str);
    const truncatedString = encodedString.slice(0, maxLength);
    return decoder.decode(truncatedString).replace(/\uFFFD/g, "");
}
 //# sourceMappingURL=debugLogger.js.map


/***/ })

};
;