exports.id = 846;
exports.ids = [846];
exports.modules = {

/***/ 75387:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 90125, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 86249, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 97844, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 61522, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 13100, 23))

/***/ }),

/***/ 49711:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3280, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 69274, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3349, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 90701, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 495));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2332));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 34825));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 90181));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 27987));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 50882))

/***/ }),

/***/ 50882:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthModal: () => (/* binding */ AuthModal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45977);
/* harmony import */ var _context_use_auth_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(27987);
/* harmony import */ var _clerk_clerk_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(48751);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(64348);
/* __next_internal_client_entry_do_not_use__ AuthModal auto */ 






const AuthModal = ()=>{
    const { authModalIsOpen, setAuthModalIsOpen } = (0,_context_use_auth_modal__WEBPACK_IMPORTED_MODULE_2__.useAuthModalContext)();
    const pathname = (0,next_navigation__WEBPACK_IMPORTED_MODULE_4__.usePathname)();
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        if (pathname === "/sign-up") {
            setAuthModalIsOpen(false);
        }
    }, [
        pathname,
        setAuthModalIsOpen
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_modal__WEBPACK_IMPORTED_MODULE_1__/* .Modal */ .u_, {
        open: authModalIsOpen,
        onOpenChange: setAuthModalIsOpen,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_modal__WEBPACK_IMPORTED_MODULE_1__/* .ModalPortal */ .Hv, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_modal__WEBPACK_IMPORTED_MODULE_1__/* .ModalOverlay */ .ZA, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_modal__WEBPACK_IMPORTED_MODULE_1__/* .ModalContent */ .hz, {
                    customStyle: true,
                    className: "top-1/2 h-fit w-fit -translate-y-1/2 overflow-hidden",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_modal__WEBPACK_IMPORTED_MODULE_1__/* .ModalClose */ .A3, {
                            className: "absolute right-10 top-5 z-50",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_6__/* .MdClose */ .FU5, {})
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_clerk_clerk_react__WEBPACK_IMPORTED_MODULE_3__/* .SignIn */ .cL, {
                            // path="/sign-in"
                            redirectUrl: "/project/backlog",
                            signUpUrl: "/sign-up",
                            appearance: {
                                elements: {
                                    formButtonPrimary: "bg-inprogress hover:bg-inprogress hover:brightness-95 text-sm normal-case",
                                    formButtonSecondary: "bg-inprogress text-sm normal-case",
                                    footerActionText: " text-md",
                                    footerActionLink: "text-inprogress hover:text-inprogress hover:brightness-95 font-semibold text-md"
                                }
                            }
                        })
                    ]
                })
            ]
        })
    });
};



/***/ }),

/***/ 34825:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   toast: () => (/* binding */ toast)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(33518);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(75484);
/* __next_internal_client_entry_do_not_use__ default,toast auto */ 


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react_hot_toast__WEBPACK_IMPORTED_MODULE_1__/* .Toaster */ .x7);
const toast = {
    success: (props)=>{
        react_hot_toast__WEBPACK_IMPORTED_MODULE_1__/* .toast */ .Am.custom(()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ToastContainer, {
                ...props,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__/* .BsCheckCircleFill */ .N9r, {
                    className: "w-fit pr-4 text-2xl text-green-600"
                })
            }));
    },
    error: (props)=>{
        react_hot_toast__WEBPACK_IMPORTED_MODULE_1__/* .toast */ .Am.custom(()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ToastContainer, {
                ...props,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__/* .BsFillExclamationCircleFill */ .STs, {
                    className: "w-fit pr-4 text-2xl text-red-600"
                })
            }));
    }
};
const ToastContainer = ({ children, message, description = "" })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex w-96 justify-between rounded-sm border-[0.3px] bg-white p-4 shadow-lg ",
        children: [
            children,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex w-full flex-col gap-y-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-sm font-semibold text-gray-600",
                        children: message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-sm text-gray-500",
                        children: description
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                onClick: ()=>react_hot_toast__WEBPACK_IMPORTED_MODULE_1__/* .toast */ .Am.remove(),
                className: "flex flex-col",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__/* .BsX */ .z3f, {
                    className: "text-3xl"
                })
            })
        ]
    });
};


/***/ }),

/***/ 45977:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A3: () => (/* binding */ ModalClose),
/* harmony export */   Hv: () => (/* binding */ ModalPortal),
/* harmony export */   ZA: () => (/* binding */ ModalOverlay),
/* harmony export */   hz: () => (/* binding */ ModalContent),
/* harmony export */   iq: () => (/* binding */ ModalTrigger),
/* harmony export */   k: () => (/* binding */ ModalDescription),
/* harmony export */   r6: () => (/* binding */ ModalTitle),
/* harmony export */   u_: () => (/* binding */ Modal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(35193);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);




const ModalTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_3__/* .Trigger */ .xz, {
        ref: forwardedRef,
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        children: children
    }));
ModalTrigger.displayName = "ModalTrigger";
const ModalContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, customStyle = false, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex justify-center",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_3__/* .Content */ .VY, {
            className: clsx__WEBPACK_IMPORTED_MODULE_2___default()(customStyle ? "" : "top-20 bg-white p-8 shadow-md", "fixed z-50 rounded-[3px] duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95  ", className),
            ...props,
            ref: forwardedRef,
            children: children
        })
    }));
ModalContent.displayName = "ModalContent";
const ModalPortal = ({ children, className, ...props })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_3__/* .Portal */ .h_, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        children: children
    });
ModalPortal.displayName = "ModalPortal";
const ModalOverlay = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_3__/* .Overlay */ .aV, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("fixed inset-0 z-50 bg-black bg-opacity-40 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ModalOverlay.displayName = "ModalOverlay";
const ModalTitle = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_3__/* .Title */ .Dx, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("text-2xl", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ModalTitle.displayName = "ModalTitle";
const ModalDescription = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_3__/* .Description */ .dk, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("text-sm text-gray-500", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ModalDescription.displayName = "ModalDescription";
const ModalClose = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_3__/* .Close */ .x8, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ModalClose.displayName = "ModalClose";
const Modal = _radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .fC;



/***/ }),

/***/ 27987:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthModalProvider: () => (/* binding */ AuthModalProvider),
/* harmony export */   useAuthModalContext: () => (/* binding */ useAuthModalContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ AuthModalProvider,useAuthModalContext auto */ 

const AuthModalContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
    authModalIsOpen: false,
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    setAuthModalIsOpen: ()=>{}
});
const AuthModalProvider = ({ children })=>{
    const [authModalIsOpen, setAuthModalIsOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AuthModalContext.Provider, {
        value: {
            authModalIsOpen,
            setAuthModalIsOpen
        },
        children: children
    });
};
const useAuthModalContext = ()=>(0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(AuthModalContext);


/***/ }),

/***/ 90181:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(38927);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(98417);
/* harmony import */ var _tanstack_react_query_devtools__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(64154);
/* __next_internal_client_entry_do_not_use__ default auto */ 



function Providers({ children }) {
    const [isBrowser, setIsBrowser] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (false) {}
    }, []);
    const [client] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(()=>new _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__/* .QueryClient */ .S());
    if (!isBrowser) return null;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__.QueryClientProvider, {
        client: client,
        children: [
            children,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tanstack_react_query_devtools__WEBPACK_IMPORTED_MODULE_4__/* .ReactQueryDevtools */ .t, {
                initialIsOpen: false
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Providers);


/***/ }),

/***/ 76770:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ layout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/@clerk/nextjs/dist/esm/app-beta/ClerkProvider.js + 2 modules
var ClerkProvider = __webpack_require__(85061);
;// CONCATENATED MODULE: ./config/site.ts
const siteConfig = {
    name: "Jira Clone \uD83D\uDE80",
    description: "An open source Jira clone built with Next.js 13, featuring React server components. Powered by tailwind, prisma, tanstack query, radix ui, lexical, axios, and zod. Efficient project management at your fingertips.",
    url: "https://jira.sebastianfdz.com",
    links: {
        github: "https://github.com/sebastianfdz/jira_clone"
    }
};

// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(46495);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./components/toast.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/home/oleksii/Documents/Projects/SoftServe/vagrant-test/app/components/toast.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const toast = (__default__);
const e0 = proxy["toast"];

;// CONCATENATED MODULE: ./utils/provider.tsx

const provider_proxy = (0,module_proxy.createProxy)(String.raw`/home/oleksii/Documents/Projects/SoftServe/vagrant-test/app/utils/provider.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: provider_esModule, $$typeof: provider_$$typeof } = provider_proxy;
const provider_default_ = provider_proxy.default;


/* harmony default export */ const provider = (provider_default_);
;// CONCATENATED MODULE: ./context/use-auth-modal.tsx

const use_auth_modal_proxy = (0,module_proxy.createProxy)(String.raw`/home/oleksii/Documents/Projects/SoftServe/vagrant-test/app/context/use-auth-modal.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: use_auth_modal_esModule, $$typeof: use_auth_modal_$$typeof } = use_auth_modal_proxy;
const use_auth_modal_default_ = use_auth_modal_proxy.default;

const use_auth_modal_e0 = use_auth_modal_proxy["AuthModalProvider"];

const e1 = use_auth_modal_proxy["useAuthModalContext"];

;// CONCATENATED MODULE: ./components/modals/auth/index.tsx

const auth_proxy = (0,module_proxy.createProxy)(String.raw`/home/oleksii/Documents/Projects/SoftServe/vagrant-test/app/components/modals/auth/index.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: auth_esModule, $$typeof: auth_$$typeof } = auth_proxy;
const auth_default_ = auth_proxy.default;

const auth_e0 = auth_proxy["AuthModal"];

;// CONCATENATED MODULE: ./app/layout.tsx








const metadata = {
    title: {
        default: siteConfig.name,
        template: `%s - ${siteConfig.name}`
    },
    description: siteConfig.description,
    keywords: [
        "Jira",
        "Next.js",
        "React",
        "Tailwind CSS",
        "Server Components",
        "Radix UI",
        "Clerk",
        "TanStack"
    ],
    authors: [
        {
            name: "Sebastian Fernandez",
            url: "https://sebastianfdz.com"
        }
    ],
    creator: "Sebastian Fernandez",
    openGraph: {
        type: "website",
        locale: "en_US",
        url: siteConfig.url,
        title: siteConfig.name,
        description: siteConfig.description,
        siteName: siteConfig.name
    }
};
const RootLayout = ({ children })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("html", {
        lang: "en",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("head", {}),
            /*#__PURE__*/ jsx_runtime_.jsx("body", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(ClerkProvider/* ClerkProvider */.E, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(provider, {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(use_auth_modal_e0, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(auth_e0, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(toast, {
                                    position: "bottom-left",
                                    reverseOrder: false,
                                    containerStyle: {
                                        height: "92vh",
                                        marginLeft: "3vw"
                                    }
                                }),
                                children
                            ]
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const layout = (RootLayout);


/***/ }),

/***/ 21701:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(93180);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/svg+xml","sizes":"2361x2500"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "icon.svg")

    return [{
      ...imageData,
      url: imageUrl + "?6f17f90003516013",
    }]
  });

/***/ }),

/***/ 46495:
/***/ (() => {



/***/ })

};
;