"use strict";
exports.id = 661;
exports.ids = [661];
exports.modules = {

/***/ 55370:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Y: () => (/* binding */ SprintFilter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(41772);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16775);
/* harmony import */ var _components_ui_tooltip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45197);
/* harmony import */ var _context_use_filters_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57165);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(38546);
/* harmony import */ var _issue_issue_status_count__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(14389);
/* harmony import */ var _hooks_query_hooks_use_sprints__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(75589);








const SprintFilter = ()=>{
    const { sprints: filterSprints, setSprints } = (0,_context_use_filters_context__WEBPACK_IMPORTED_MODULE_3__/* .useFiltersContext */ .P)();
    const { sprints } = (0,_hooks_query_hooks_use_sprints__WEBPACK_IMPORTED_MODULE_6__/* .useSprints */ .D)();
    function filterActiveSprints(sprint) {
        return sprint.status === "ACTIVE";
    }
    function onSelectChange(e, sprint) {
        if (e.target.checked) {
            setSprints((prev)=>[
                    ...prev,
                    sprint.id
                ]);
        } else {
            setSprints((prev)=>prev.filter((id)=>id !== sprint.id));
        }
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__/* .Dropdown */ .Lt, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__/* .DropdownTrigger */ .WA, {
                className: "rounded-[3px] [&[data-state=open]]:bg-gray-700 [&[data-state=open]]:text-white",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_button__WEBPACK_IMPORTED_MODULE_4__/* .Button */ .z, {
                    customColors: true,
                    className: "flex items-center gap-x-2 transition-all duration-200 hover:bg-gray-200",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-sm",
                            children: "Sprint"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_issue_issue_status_count__WEBPACK_IMPORTED_MODULE_5__/* .CountBall */ .N, {
                            count: filterSprints.length,
                            className: "bg-inprogress text-xs text-white",
                            hideOnZero: true
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_7__/* .FaChevronDown */ .RiI, {
                            className: "text-xs"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__/* .DropdownPortal */ .nI, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__/* .DropdownContent */ .Nv, {
                    side: "bottom",
                    align: "start",
                    className: "z-10 mt-2 w-64 rounded-[3px] border-[0.3px] bg-white py-2 shadow-md",
                    children: sprints?.filter(filterActiveSprints).map((sprint)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_1__/* .DropdownItem */ .hP, {
                            onSelect: (e)=>e.preventDefault(),
                            className: "px-3 py-1.5 text-sm hover:bg-gray-100",
                            onChange: (e)=>onSelectChange(e, sprint),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center gap-x-2 hover:cursor-default",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "checkbox",
                                        className: "form-checkbox h-3 w-3 rounded-sm text-inprogress",
                                        checked: filterSprints.includes(sprint.id)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_tooltip__WEBPACK_IMPORTED_MODULE_2__/* .TooltipWrapper */ .pf, {
                                        text: sprint.name,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "text-sm text-gray-700",
                                            children: sprint.name
                                        })
                                    })
                                ]
                            })
                        }, sprint.id))
                })
            })
        ]
    });
};



/***/ })

};
;