"use strict";
exports.id = 688;
exports.ids = [688];
exports.modules = {

/***/ 29688:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Iw: () => (/* binding */ generateIssuesForClient),
/* harmony export */   gx: () => (/* binding */ calculateInsertPosition),
/* harmony export */   w$: () => (/* binding */ filterUserForClient)
/* harmony export */ });
/* unused harmony exports getBaseUrl, getHeaders, capitalize, capitalizeMany, getIssueCountByStatus, isEpic, isSubtask, hasChildren, sprintId, isNullish, issueNotInSearch, assigneeNotInFilters, epicNotInFilters, issueTypeNotInFilters, issueSprintNotInFilters, dateToLongString, isDone, hexToRgba, moveItemWithinArray, insertItemIntoArray, getPluralEnd */
function getBaseUrl() {
    if (false) {} // browser should use relative url
    if (process.env.VERCEL_URL) return `https://${process.env.VERCEL_URL}`; // SSR should use vercel url
    return `http://localhost:${process.env.PORT ?? 3000}`; // dev SSR should use localhost
}
function getHeaders() {
    return {
        "Content-type": "application/json"
    };
}
function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}
function capitalizeMany(str) {
    return str.split(" ").map((word)=>capitalize(word)).join(" ");
}
function getIssueCountByStatus(issues) {
    return issues.reduce((acc, issue)=>{
        acc[issue.status]++;
        return acc;
    }, {
        TODO: 0,
        IN_PROGRESS: 0,
        DONE: 0
    });
}
function isEpic(issue) {
    if (!issue) return false;
    return issue.type == "EPIC";
}
function isSubtask(issue) {
    if (!issue) return false;
    return issue.type == "SUBTASK";
}
function hasChildren(issue) {
    if (!issue) return false;
    return issue.children.length > 0;
}
function sprintId(id) {
    return id == "backlog" ? null : id;
}
function isNullish(value) {
    return value == null || value == undefined;
}
function filterUserForClient(user) {
    return {
        id: user.id,
        name: `${user.firstName ?? ""} ${user.lastName ?? ""}`,
        email: user?.emailAddresses[0]?.emailAddress ?? "",
        avatar: user.imageUrl
    };
}
function issueNotInSearch({ issue, search }) {
    return search.length && !(issue.name.toLowerCase().includes(search.toLowerCase()) || issue.assignee?.name.toLowerCase().includes(search.toLowerCase()) || issue.key.toLowerCase().includes(search.toLowerCase()));
}
function assigneeNotInFilters({ issue, assignees }) {
    return assignees.length && !assignees.includes(issue.assignee?.id ?? "unassigned");
}
function epicNotInFilters({ issue, epics }) {
    return epics.length && (!issue.parentId || !epics.includes(issue.parentId));
}
function issueTypeNotInFilters({ issue, issueTypes }) {
    return issueTypes.length && !issueTypes.includes(issue.type);
}
function issueSprintNotInFilters({ issue, sprintIds, excludeBacklog = false }) {
    if (isNullish(issue.sprintId)) {
        if (sprintIds.length && excludeBacklog) return true;
        return false;
    }
    return sprintIds.length && !sprintIds.includes(issue.sprintId);
}
function dateToLongString(date) {
    const dateString = new Date(date).toDateString();
    const timeStirng = new Date(date).toLocaleTimeString();
    return dateString + " at " + timeStirng;
}
function isDone(issue) {
    return issue.status == "DONE";
}
function hexToRgba(hex, opacity) {
    if (!hex) return "rgba(0, 0, 0, 0)";
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${opacity ?? 1})`;
}
function generateIssuesForClient(issues, users, activeSprintIds) {
    // Maps are used to make lookups faster
    const userMap = new Map(users.map((user)=>[
            user.id,
            user
        ]));
    const parentMap = new Map(issues.map((issue)=>[
            issue.id,
            issue
        ]));
    const issuesForClient = issues.map((issue)=>{
        const parent = parentMap.get(issue.parentId ?? "") ?? null;
        const assignee = userMap.get(issue.assigneeId ?? "") ?? null;
        const reporter = userMap.get(issue.reporterId) ?? null;
        const children = issues.filter((i)=>i.parentId === issue.id).map((issue)=>{
            const assignee = userMap.get(issue.assigneeId ?? "") ?? null;
            return Object.assign(issue, {
                assignee
            });
        });
        const sprintIsActive = activeSprintIds?.includes(issue.sprintId ?? "");
        return {
            ...issue,
            sprintIsActive,
            parent,
            assignee,
            reporter,
            children
        };
    });
    return issuesForClient;
}
function calculateInsertPosition(issues) {
    return Math.max(...issues.map((issue)=>issue.sprintPosition), 0) + 1;
}
function moveItemWithinArray(arr, item, newIndex) {
    const arrClone = [
        ...arr
    ];
    const oldIndex = arrClone.indexOf(item);
    const oldItem = arrClone.splice(oldIndex, 1)[0];
    if (oldItem) arrClone.splice(newIndex, 0, oldItem);
    return arrClone;
}
function insertItemIntoArray(arr, item, index) {
    const arrClone = [
        ...arr
    ];
    arrClone.splice(index, 0, item);
    return arrClone;
}
function getPluralEnd(arr) {
    if (arr.length == 0) return "s";
    return arr.length > 1 ? "s" : "";
}


/***/ })

};
;