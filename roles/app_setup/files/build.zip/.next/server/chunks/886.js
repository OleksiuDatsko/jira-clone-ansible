"use strict";
exports.id = 886;
exports.ids = [886];
exports.modules = {

/***/ 36886:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Ns: () => (/* binding */ esm_clerkClient),
  ar: () => (/* binding */ esm_currentUser)
});

// UNUSED EXPORTS: AuthenticateWithRedirectCallback, ClerkLoaded, ClerkLoading, ClerkProvider, CreateOrganization, EmailLinkErrorCode, MagicLinkErrorCode, MultisessionAppSupport, OrganizationList, OrganizationProfile, OrganizationSwitcher, Protect, RedirectToCreateOrganization, RedirectToOrganizationProfile, RedirectToSignIn, RedirectToSignUp, RedirectToUserProfile, SignIn, SignInButton, SignInWithMetamaskButton, SignOutButton, SignUp, SignUpButton, SignedIn, SignedOut, UserButton, UserProfile, WithClerk, WithSession, WithUser, auth, authMiddleware, isClerkAPIResponseError, isEmailLinkError, isKnownError, isMagicLinkError, isMetamaskError, redirectToSignIn, redirectToSignUp, useAuth, useClerk, useEmailLink, useMagicLink, useOrganization, useOrganizationList, useOrganizations, useSession, useSessionList, useSignIn, useSignUp, useUser, withClerk, withClerkMiddleware, withSession, withUser

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(7887);
;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/utils/mergeNextClerkPropsWithEnv.js
const mergeNextClerkPropsWithEnv = (props)=>{
    return {
        ...props,
        frontendApi: props.frontendApi || process.env.NEXT_PUBLIC_CLERK_FRONTEND_API || "",
        publishableKey: props.publishableKey || process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY || "",
        clerkJSUrl: props.clerkJSUrl || process.env.NEXT_PUBLIC_CLERK_JS,
        clerkJSVersion: props.clerkJSVersion || process.env.NEXT_PUBLIC_CLERK_JS_VERSION,
        proxyUrl: props.proxyUrl || process.env.NEXT_PUBLIC_CLERK_PROXY_URL || "",
        domain: props.domain || process.env.NEXT_PUBLIC_CLERK_DOMAIN || "",
        isSatellite: props.isSatellite || process.env.NEXT_PUBLIC_CLERK_IS_SATELLITE === "true",
        signInUrl: props.signInUrl || process.env.NEXT_PUBLIC_CLERK_SIGN_IN_URL || "",
        signUpUrl: props.signUpUrl || process.env.NEXT_PUBLIC_CLERK_SIGN_UP_URL || "",
        afterSignInUrl: props.afterSignInUrl || process.env.NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL || "",
        afterSignUpUrl: props.afterSignUpUrl || process.env.NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL || "",
        sdkMetadata: {
            name: "@clerk/nextjs",
            version: "4.29.5"
        }
    };
};
 //# sourceMappingURL=mergeNextClerkPropsWithEnv.js.map

// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/app-router/client/ClerkProvider.js

const proxy = (0,module_proxy.createProxy)(String.raw`/home/vagrant/agent/workspace/jira_clone_PR-1/node_modules/@clerk/nextjs/dist/esm/app-router/client/ClerkProvider.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["ClientClerkProvider"];

// EXTERNAL MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/buildClerkProps.js
var buildClerkProps = __webpack_require__(64521);
// EXTERNAL MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/createGetAuth.js
var createGetAuth = __webpack_require__(14669);
// EXTERNAL MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/errors.js
var errors = __webpack_require__(19611);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/exports/next-request.js
var next_request = __webpack_require__(47301);
;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/app-router/server/utils.js

const buildRequestLike = ()=>{
    try {
        const { headers } = __webpack_require__(63919);
        return new next_request/* default */.Z("https://placeholder.com", {
            headers: headers()
        });
    } catch (e) {
        if (e && "message" in e && typeof e.message === "string" && e.message.toLowerCase().includes("Dynamic server usage".toLowerCase())) {
            throw e;
        }
        throw new Error(`Clerk: auth() and currentUser() are only supported in App Router (/app directory).
If you're using /pages, try getAuth() instead.
Original error: ${e}`);
    }
};
 //# sourceMappingURL=utils.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/app-router/server/auth.js




const auth = ()=>{
    const authObject = (0,createGetAuth/* createGetAuth */.rl)({
        debugLoggerName: "auth()",
        noAuthStatusMessage: (0,errors/* authAuthHeaderMissing */.It)()
    })(buildRequestLike());
    const { notFound, redirect } = __webpack_require__(78875);
    authObject.protect = (params, options)=>{
        const paramsOrFunction = params?.redirectUrl ? void 0 : params;
        const redirectUrl = params?.redirectUrl || options?.redirectUrl;
        const handleUnauthorized = ()=>{
            if (redirectUrl) {
                redirect(redirectUrl);
            }
            notFound();
        };
        if (!authObject.userId) {
            return handleUnauthorized();
        }
        if (!paramsOrFunction) {
            return {
                ...authObject
            };
        }
        if (typeof paramsOrFunction === "function") {
            if (paramsOrFunction(authObject.has)) {
                return {
                    ...authObject
                };
            }
            return handleUnauthorized();
        }
        if (authObject.has(paramsOrFunction)) {
            return {
                ...authObject
            };
        }
        return handleUnauthorized();
    };
    return authObject;
};
const initialState = ()=>{
    return (0,buildClerkProps/* buildClerkProps */.d)(buildRequestLike());
};
 //# sourceMappingURL=auth.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/app-router/server/ClerkProvider.js




function ClerkProvider(props) {
    const { children, ...rest } = props;
    const state = initialState()?.__clerk_ssr_state;
    return /* @__PURE__ */ /*#__PURE__*/ react_shared_subset.createElement(e0, {
        ...mergeNextClerkPropsWithEnv(rest),
        initialState: state
    }, children);
}
 //# sourceMappingURL=ClerkProvider.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/app-router/server/controlComponents.js


function SignedIn(props) {
    const { children } = props;
    const { userId } = auth();
    return userId ? /* @__PURE__ */ /*#__PURE__*/ react_shared_subset.createElement(react_shared_subset.Fragment, null, children) : null;
}
function SignedOut(props) {
    const { children } = props;
    const { userId } = auth();
    return userId ? null : /* @__PURE__ */ /*#__PURE__*/ react_shared_subset.createElement(react_shared_subset.Fragment, null, children);
}
function Protect(props) {
    const { children, fallback, ...restAuthorizedParams } = props;
    const { has, userId } = auth();
    const unauthorized = /* @__PURE__ */ /*#__PURE__*/ react_shared_subset.createElement(react_shared_subset.Fragment, null, fallback ?? null);
    const authorized = /* @__PURE__ */ /*#__PURE__*/ react_shared_subset.createElement(react_shared_subset.Fragment, null, children);
    if (!userId) {
        return unauthorized;
    }
    if (typeof restAuthorizedParams.condition === "function") {
        if (restAuthorizedParams.condition(has)) {
            return authorized;
        }
        return unauthorized;
    }
    if (restAuthorizedParams.role || restAuthorizedParams.permission) {
        if (has(restAuthorizedParams)) {
            return authorized;
        }
        return unauthorized;
    }
    return authorized;
}
 //# sourceMappingURL=controlComponents.js.map

// EXTERNAL MODULE: ./node_modules/@clerk/backend/dist/index.js
var dist = __webpack_require__(50646);
// EXTERNAL MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/constants.js
var constants = __webpack_require__(4823);
;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/clerkClient.js


const clerkClient = (0,dist.Clerk)({
    apiKey: constants/* API_KEY */.$h,
    secretKey: constants/* SECRET_KEY */.Cn,
    apiUrl: constants/* API_URL */.T5,
    apiVersion: constants/* API_VERSION */.Gn,
    userAgent: `${"@clerk/nextjs"}@${"4.29.5"}`,
    proxyUrl: constants/* PROXY_URL */.NM,
    domain: constants/* DOMAIN */.yK,
    isSatellite: constants/* IS_SATELLITE */.lo
});
const createClerkClient = (/* unused pure expression or super */ null && (Clerk));


 //# sourceMappingURL=clerkClient.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/app-router/server/currentUser.js


async function currentUser() {
    const { userId } = auth();
    return userId ? clerkClient.users.getUser(userId) : null;
}
 //# sourceMappingURL=currentUser.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/chunk-3S7ZLCXD.mjs
// src/devBrowser.ts
var DEV_BROWSER_SSO_JWT_PARAMETER = "__dev_session";
var DEV_BROWSER_JWT_MARKER = "__clerk_db_jwt";
var DEV_BROWSER_JWT_MARKER_REGEXP = /__clerk_db_jwt\[(.*)\]/;
function setDevBrowserJWTInURL(url, jwt, asQueryParam) {
    const resultURL = new URL(url);
    const jwtFromHash = extractDevBrowserJWTFromURLHash(resultURL);
    const jwtFromSearch = extractDevBrowserJWTFromURLSearchParams(resultURL);
    const jwtToSet = jwtFromHash || jwtFromSearch || jwt;
    if (jwtToSet) {
        if (asQueryParam) {
            resultURL.searchParams.append(DEV_BROWSER_SSO_JWT_PARAMETER, jwtToSet);
            resultURL.searchParams.append(DEV_BROWSER_JWT_MARKER, jwtToSet);
        } else {
            resultURL.hash = resultURL.hash + `${DEV_BROWSER_JWT_MARKER}[${jwtToSet}]`;
        }
    }
    return resultURL;
}
function extractDevBrowserJWTFromHash(hash) {
    const matches = hash.match(DEV_BROWSER_JWT_MARKER_REGEXP);
    return matches ? matches[1] : "";
}
function extractDevBrowserJWTFromURLHash(url) {
    const jwt = extractDevBrowserJWTFromHash(url.hash);
    url.hash = url.hash.replace(DEV_BROWSER_JWT_MARKER_REGEXP, "");
    if (url.href.endsWith("#")) {
        url.hash = "";
    }
    return jwt;
}
function extractDevBrowserJWTFromURLSearchParams(url) {
    const jwtFromDevSession = url.searchParams.get(DEV_BROWSER_SSO_JWT_PARAMETER);
    url.searchParams.delete(DEV_BROWSER_SSO_JWT_PARAMETER);
    const jwtFromClerkDbJwt = url.searchParams.get(DEV_BROWSER_JWT_MARKER);
    url.searchParams.delete(DEV_BROWSER_JWT_MARKER);
    return jwtFromDevSession || jwtFromClerkDbJwt || "";
}
 //# sourceMappingURL=chunk-3S7ZLCXD.mjs.map

// EXTERNAL MODULE: ./node_modules/@clerk/shared/dist/chunk-NDCDZYN6.mjs
var chunk_NDCDZYN6 = __webpack_require__(12940);
;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/devBrowser.mjs


 //# sourceMappingURL=devBrowser.mjs.map

// EXTERNAL MODULE: ./node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(32413);
// EXTERNAL MODULE: ./node_modules/@clerk/nextjs/dist/esm/constants.js
var esm_constants = __webpack_require__(71555);
;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/utils/response.js


const mergeResponses = (...responses)=>{
    const normalisedResponses = responses.filter(Boolean).map((res)=>{
        if (res instanceof next_response/* default */.Z) {
            return res;
        }
        return new next_response/* default */.Z(res.body, res);
    });
    if (normalisedResponses.length === 0) {
        return;
    }
    const lastResponse = normalisedResponses[normalisedResponses.length - 1];
    const finalResponse = new next_response/* default */.Z(lastResponse.body, lastResponse);
    for (const response of normalisedResponses){
        response.headers.forEach((value, name)=>{
            finalResponse.headers.set(name, value);
        });
        response.cookies.getAll().forEach((cookie)=>{
            const { name, value, ...options } = cookie;
            finalResponse.cookies.set(name, value, options);
        });
    }
    return finalResponse;
};
const isRedirect = (res)=>{
    return res.headers.get(esm_constants/* constants */._.Headers.NextRedirect);
};
const setHeader = (res, name, val)=>{
    res.headers.set(name, val);
    return res;
};
const stringifyHeaders = (headers)=>{
    if (!headers) {
        return JSON.stringify({});
    }
    const obj = {};
    headers.forEach((value, name)=>{
        obj[name] = value;
    });
    return JSON.stringify(obj);
};
 //# sourceMappingURL=response.js.map

// EXTERNAL MODULE: ./node_modules/path-to-regexp/dist/index.js
var path_to_regexp_dist = __webpack_require__(71383);
;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/utils/pathMatchers.js

const paths = {
    toRegexp: (path)=>{
        try {
            return (0,path_to_regexp_dist/* pathToRegexp */.Bo)(path);
        } catch (e) {
            throw new Error(`Invalid path: ${path}.
Consult the documentation of path-to-regexp here: https://github.com/pillarjs/path-to-regexp
${e.message}`);
        }
    }
};
 //# sourceMappingURL=pathMatchers.js.map

// EXTERNAL MODULE: ./node_modules/@clerk/nextjs/dist/esm/utils/debugLogger.js + 2 modules
var debugLogger = __webpack_require__(28857);
// EXTERNAL MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/utils.js + 4 modules
var utils = __webpack_require__(90057);
// EXTERNAL MODULE: ./node_modules/@clerk/shared/dist/deprecated.mjs
var deprecated = __webpack_require__(87351);
;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/withClerkMiddleware.js





const decorateResponseWithObservabilityHeaders = (res, requestState)=>{
    requestState.message && res.headers.set(dist.constants.Headers.AuthMessage, encodeURIComponent(requestState.message));
    requestState.reason && res.headers.set(dist.constants.Headers.AuthReason, encodeURIComponent(requestState.reason));
    requestState.status && res.headers.set(dist.constants.Headers.AuthStatus, encodeURIComponent(requestState.status));
};
const withClerkMiddleware = (...args)=>{
    const noop = ()=>void 0;
    const [handler = noop, opts = {}] = args;
    (0,deprecated/* deprecated */.x9)("withClerkMiddleware", "Use `authMiddleware` instead.\nFor more details, consult the middleware documentation: https://clerk.com/docs/nextjs/middleware");
    return async (req, event)=>{
        const { isSatellite, domain, signInUrl, proxyUrl } = (0,utils/* handleMultiDomainAndProxy */.cu)(req, opts);
        const requestState = await clerkClient.authenticateRequest({
            ...opts,
            apiKey: opts.apiKey || constants/* API_KEY */.$h,
            secretKey: opts.secretKey || constants/* SECRET_KEY */.Cn,
            frontendApi: opts.frontendApi || constants/* FRONTEND_API */.yM,
            publishableKey: opts.publishableKey || constants/* PUBLISHABLE_KEY */.Am,
            isSatellite,
            domain,
            signInUrl,
            proxyUrl,
            request: req
        });
        if (requestState.isUnknown) {
            const response = new next_response/* default */.Z(null, {
                status: 401,
                headers: {
                    "Content-Type": "text/html"
                }
            });
            decorateResponseWithObservabilityHeaders(response, requestState);
            return response;
        }
        if (requestState.isInterstitial) {
            const response = next_response/* default */.Z.rewrite(clerkClient.remotePublicInterstitialUrl({
                apiUrl: constants/* API_URL */.T5,
                frontendApi: opts.frontendApi || constants/* FRONTEND_API */.yM,
                publishableKey: opts.publishableKey || constants/* PUBLISHABLE_KEY */.Am,
                clerkJSUrl: constants/* CLERK_JS_URL */.YU,
                clerkJSVersion: constants/* CLERK_JS_VERSION */.cE,
                proxyUrl: requestState.proxyUrl,
                isSatellite: requestState.isSatellite,
                domain: requestState.domain,
                debugData: (0,dist.debugRequestState)(requestState),
                signInUrl: requestState.signInUrl
            }), {
                status: 401
            });
            decorateResponseWithObservabilityHeaders(response, requestState);
            return response;
        }
        (0,utils/* setCustomAttributeOnRequest */.u4)(req, dist.constants.Attributes.AuthStatus, requestState.status);
        (0,utils/* setCustomAttributeOnRequest */.u4)(req, dist.constants.Attributes.AuthToken, requestState.token || "");
        (0,utils/* setCustomAttributeOnRequest */.u4)(req, dist.constants.Attributes.AuthMessage, requestState.message || "");
        (0,utils/* setCustomAttributeOnRequest */.u4)(req, dist.constants.Attributes.AuthReason, requestState.reason || "");
        const res = await handler(req, event);
        return (0,utils/* decorateRequest */.oU)(req, res, requestState);
    };
};
 //# sourceMappingURL=withClerkMiddleware.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/authenticateRequest.js




const authenticateRequest = async (req, opts)=>{
    const { isSatellite, domain, signInUrl, proxyUrl } = (0,utils/* handleMultiDomainAndProxy */.cu)(req, opts);
    return await clerkClient.authenticateRequest({
        ...opts,
        apiKey: opts.apiKey || constants/* API_KEY */.$h,
        secretKey: opts.secretKey || constants/* SECRET_KEY */.Cn,
        frontendApi: opts.frontendApi || constants/* FRONTEND_API */.yM,
        publishableKey: opts.publishableKey || constants/* PUBLISHABLE_KEY */.Am,
        isSatellite,
        domain,
        signInUrl,
        proxyUrl,
        request: req
    });
};
const handleUnknownState = (requestState)=>{
    const response = (0,utils/* apiEndpointUnauthorizedNextResponse */.AI)();
    decorateResponseWithObservabilityHeaders(response, requestState);
    return response;
};
const handleInterstitialState = (requestState, opts)=>{
    const response = new next_response/* default */.Z(clerkClient.localInterstitial({
        frontendApi: opts.frontendApi || constants/* FRONTEND_API */.yM,
        publishableKey: opts.publishableKey || constants/* PUBLISHABLE_KEY */.Am,
        clerkJSUrl: constants/* CLERK_JS_URL */.YU,
        clerkJSVersion: constants/* CLERK_JS_VERSION */.cE,
        proxyUrl: requestState.proxyUrl,
        isSatellite: requestState.isSatellite,
        domain: requestState.domain,
        debugData: (0,dist.debugRequestState)(requestState),
        signInUrl: requestState.signInUrl
    }), {
        status: 401,
        headers: {
            "content-type": "text/html"
        }
    });
    decorateResponseWithObservabilityHeaders(response, requestState);
    return response;
};
 //# sourceMappingURL=authenticateRequest.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/redirect.js




const redirectAdapter = (url)=>{
    const res = next_response/* default */.Z.redirect(url);
    return setHeader(res, dist.constants.Headers.ClerkRedirectTo, "true");
};
const { redirectToSignIn, redirectToSignUp } = (0,dist.redirect)({
    redirectAdapter,
    signInUrl: constants/* SIGN_IN_URL */.O0,
    signUpUrl: constants/* SIGN_UP_URL */.Dt,
    publishableKey: constants/* PUBLISHABLE_KEY */.Am,
    frontendApi: constants/* FRONTEND_API */.yM
});
 //# sourceMappingURL=redirect.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/url.js
const LEGACY_DEV_SUFFIXES = [
    ".lcl.dev",
    ".lclstage.dev",
    ".lclclerk.com"
];
const CURRENT_DEV_SUFFIXES = [
    ".accounts.dev",
    ".accountsstage.dev",
    ".accounts.lclclerk.com"
];
const accountPortalCache = /* @__PURE__ */ new Map();
function isDevAccountPortalOrigin(hostname) {
    if (!hostname) {
        return false;
    }
    let res = accountPortalCache.get(hostname);
    if (res === void 0) {
        res = isLegacyDevAccountPortalOrigin(hostname) || isCurrentDevAccountPortalOrigin(hostname);
        accountPortalCache.set(hostname, res);
    }
    return res;
}
function isLegacyDevAccountPortalOrigin(host) {
    return LEGACY_DEV_SUFFIXES.some((legacyDevSuffix)=>{
        return host.startsWith("accounts.") && host.endsWith(legacyDevSuffix);
    });
}
function isCurrentDevAccountPortalOrigin(host) {
    return CURRENT_DEV_SUFFIXES.some((currentDevSuffix)=>{
        return host.endsWith(currentDevSuffix) && !host.endsWith(".clerk" + currentDevSuffix);
    });
}
 //# sourceMappingURL=url.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/authMiddleware.js











const INFINITE_REDIRECTION_LOOP_COOKIE = "__clerk_redirection_loop";
const DEFAULT_CONFIG_MATCHER = [
    "/((?!.+\\.[\\w]+$|_next).*)",
    "/",
    "/(api|trpc)(.*)"
];
const DEFAULT_IGNORED_ROUTES = [
    `/((?!api|trpc))(_next.*|.+\\.[\\w]+$)`
];
const DEFAULT_API_ROUTES = [
    "/api/(.*)",
    "/trpc/(.*)"
];
const authMiddleware = (...args)=>{
    const [params = {}] = args;
    const { beforeAuth, afterAuth, publicRoutes, ignoredRoutes, apiRoutes, ...options } = params;
    const isIgnoredRoute = createRouteMatcher(ignoredRoutes || DEFAULT_IGNORED_ROUTES);
    const isPublicRoute = createRouteMatcher(withDefaultPublicRoutes(publicRoutes));
    const isApiRoute = createApiRoutes(apiRoutes);
    const defaultAfterAuth = createDefaultAfterAuth(isPublicRoute, isApiRoute, params);
    return (0,debugLogger/* withLogger */.n)("authMiddleware", (logger)=>async (_req, evt)=>{
            if (options.debug) {
                logger.enable();
            }
            const req = withNormalizedClerkUrl(_req);
            logger.debug("URL debug", {
                url: req.nextUrl.href,
                method: req.method,
                headers: stringifyHeaders(req.headers),
                nextUrl: req.nextUrl.href,
                clerkUrl: req.experimental_clerkUrl.href
            });
            logger.debug("Options debug", {
                ...options,
                beforeAuth: !!beforeAuth,
                afterAuth: !!afterAuth
            });
            if (isIgnoredRoute(req)) {
                logger.debug({
                    isIgnoredRoute: true
                });
                if ((0,utils/* isDevelopmentFromApiKey */.RL)(options.secretKey || constants/* SECRET_KEY */.Cn) && !params.ignoredRoutes) {
                    console.warn((0,errors/* receivedRequestForIgnoredRoute */.iP)(req.experimental_clerkUrl.href, JSON.stringify(DEFAULT_CONFIG_MATCHER)));
                }
                return setHeader(next_response/* default */.Z.next(), dist.constants.Headers.AuthReason, "ignored-route");
            }
            const beforeAuthRes = await (beforeAuth && beforeAuth(req, evt));
            if (beforeAuthRes === false) {
                logger.debug("Before auth returned false, skipping");
                return setHeader(next_response/* default */.Z.next(), dist.constants.Headers.AuthReason, "skip");
            } else if (beforeAuthRes && isRedirect(beforeAuthRes)) {
                logger.debug("Before auth returned redirect, following redirect");
                return setHeader(beforeAuthRes, dist.constants.Headers.AuthReason, "redirect");
            }
            const requestState = await authenticateRequest(req, options);
            if (requestState.isUnknown) {
                logger.debug("authenticateRequest state is unknown", requestState);
                return handleUnknownState(requestState);
            } else if (requestState.isInterstitial && isApiRoute(req)) {
                logger.debug("authenticateRequest state is interstitial in an API route", requestState);
                return handleUnknownState(requestState);
            } else if (requestState.isInterstitial) {
                logger.debug("authenticateRequest state is interstitial", requestState);
                assertClockSkew(requestState, options);
                const res = handleInterstitialState(requestState, options);
                return assertInfiniteRedirectionLoop(req, res, options, requestState);
            }
            const auth = Object.assign(requestState.toAuth(), {
                isPublicRoute: isPublicRoute(req),
                isApiRoute: isApiRoute(req)
            });
            logger.debug(()=>({
                    auth: JSON.stringify(auth),
                    debug: auth.debug()
                }));
            const afterAuthRes = await (afterAuth || defaultAfterAuth)(auth, req, evt);
            const finalRes = mergeResponses(beforeAuthRes, afterAuthRes) || next_response/* default */.Z.next();
            logger.debug(()=>({
                    mergedHeaders: stringifyHeaders(finalRes.headers)
                }));
            if (isRedirect(finalRes)) {
                logger.debug("Final response is redirect, following redirect");
                const res = setHeader(finalRes, dist.constants.Headers.AuthReason, "redirect");
                return appendDevBrowserOnCrossOrigin(req, res, options);
            }
            if (options.debug) {
                (0,utils/* setRequestHeadersOnNextResponse */.Mp)(finalRes, req, {
                    [dist.constants.Headers.EnableDebug]: "true"
                });
                logger.debug(`Added ${dist.constants.Headers.EnableDebug} on request`);
            }
            return (0,utils/* decorateRequest */.oU)(req, finalRes, requestState);
        });
};
const createRouteMatcher = (routes)=>{
    if (typeof routes === "function") {
        return (req)=>routes(req);
    }
    const routePatterns = [
        routes || ""
    ].flat().filter(Boolean);
    const matchers = precomputePathRegex(routePatterns);
    return (req)=>matchers.some((matcher)=>matcher.test(req.nextUrl.pathname));
};
const createDefaultAfterAuth = (isPublicRoute, isApiRoute, params)=>{
    return (auth, req)=>{
        if (!auth.userId && !isPublicRoute(req)) {
            if (isApiRoute(req)) {
                informAboutProtectedRoute(req.experimental_clerkUrl.pathname, params, true);
                return (0,utils/* apiEndpointUnauthorizedNextResponse */.AI)();
            } else {
                informAboutProtectedRoute(req.experimental_clerkUrl.pathname, params, false);
            }
            return redirectToSignIn({
                returnBackUrl: req.experimental_clerkUrl.href
            });
        }
        return next_response/* default */.Z.next();
    };
};
const precomputePathRegex = (patterns)=>{
    return patterns.map((pattern)=>pattern instanceof RegExp ? pattern : paths.toRegexp(pattern));
};
const matchRoutesStartingWith = (path)=>{
    path = path.replace(/\/$/, "");
    return new RegExp(`^${path}(/.*)?$`);
};
const withDefaultPublicRoutes = (publicRoutes)=>{
    if (typeof publicRoutes === "function") {
        return publicRoutes;
    }
    const routes = [
        publicRoutes || ""
    ].flat().filter(Boolean);
    const signInUrl = process.env.NEXT_PUBLIC_CLERK_SIGN_IN_URL || "";
    if (signInUrl) {
        routes.push(matchRoutesStartingWith(signInUrl));
    }
    const signUpUrl = process.env.NEXT_PUBLIC_CLERK_SIGN_UP_URL || "";
    if (signUpUrl) {
        routes.push(matchRoutesStartingWith(signUpUrl));
    }
    return routes;
};
const appendDevBrowserOnCrossOrigin = (req, res, opts)=>{
    const location = res.headers.get("location");
    const shouldAppendDevBrowser = res.headers.get(dist.constants.Headers.ClerkRedirectTo) === "true";
    if (shouldAppendDevBrowser && !!location && (0,utils/* isDevelopmentFromApiKey */.RL)(opts.secretKey || constants/* SECRET_KEY */.Cn) && (0,utils/* isCrossOrigin */.xr)(req.experimental_clerkUrl, location)) {
        const dbJwt = req.cookies.get(DEV_BROWSER_JWT_MARKER)?.value || "";
        const url = new URL(location);
        const asQueryParam = isDevAccountPortalOrigin(url.hostname);
        const urlWithDevBrowser = setDevBrowserJWTInURL(url, dbJwt, asQueryParam);
        return next_response/* default */.Z.redirect(urlWithDevBrowser.href, res);
    }
    return res;
};
const createApiRoutes = (apiRoutes)=>{
    if (apiRoutes) {
        return createRouteMatcher(apiRoutes);
    }
    const isDefaultApiRoute = createRouteMatcher(DEFAULT_API_ROUTES);
    return (req)=>isDefaultApiRoute(req) || isRequestMethodIndicatingApiRoute(req) || isRequestContentTypeJson(req);
};
const isRequestContentTypeJson = (req)=>{
    const requestContentType = req.headers.get(dist.constants.Headers.ContentType);
    return requestContentType === dist.constants.ContentTypes.Json;
};
const isRequestMethodIndicatingApiRoute = (req)=>{
    const requestMethod = req.method.toLowerCase();
    return ![
        "get",
        "head",
        "options"
    ].includes(requestMethod);
};
const assertClockSkew = (requestState, opts)=>{
    if (!(0,utils/* isDevelopmentFromApiKey */.RL)(opts.secretKey || constants/* SECRET_KEY */.Cn)) {
        return;
    }
    if (requestState.reason === "token-not-active-yet") {
        throw new Error((0,errors/* clockSkewDetected */.Yf)(requestState.message));
    }
};
const assertInfiniteRedirectionLoop = (req, res, opts, requestState)=>{
    if (!(0,utils/* isDevelopmentFromApiKey */.RL)(opts.secretKey || constants/* SECRET_KEY */.Cn)) {
        return res;
    }
    const infiniteRedirectsCounter = Number(req.cookies.get(INFINITE_REDIRECTION_LOOP_COOKIE)?.value) || 0;
    if (infiniteRedirectsCounter === 6) {
        if (requestState.reason === "token-expired") {
            throw new Error((0,errors/* clockSkewDetected */.Yf)(requestState.message));
        }
        throw new Error((0,errors/* infiniteRedirectLoopDetected */.PN)());
    }
    if (req.headers.get("referer") === req.url) {
        res.cookies.set({
            name: INFINITE_REDIRECTION_LOOP_COOKIE,
            value: `${infiniteRedirectsCounter + 1}`,
            maxAge: 3
        });
    }
    return res;
};
const withNormalizedClerkUrl = (req)=>{
    const clerkUrl = req.nextUrl.clone();
    const originUrl = (0,dist.buildRequestUrl)(req);
    clerkUrl.port = originUrl.port;
    clerkUrl.protocol = originUrl.protocol;
    clerkUrl.host = originUrl.host;
    return Object.assign(req, {
        experimental_clerkUrl: clerkUrl
    });
};
const informAboutProtectedRoute = (path, params, isApiRoute)=>{
    if (params.debug || (0,utils/* isDevelopmentFromApiKey */.RL)(params.secretKey || constants/* SECRET_KEY */.Cn)) {
        console.warn((0,errors/* informAboutProtectedRouteInfo */.MV)(path, !!params.publicRoutes, !!params.ignoredRoutes, isApiRoute, DEFAULT_IGNORED_ROUTES));
    }
};
 //# sourceMappingURL=authMiddleware.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/index.js





const esm_ClerkProvider = ClerkProvider;
const esm_SignedIn = SignedIn;
const esm_SignedOut = SignedOut;
const esm_Protect = Protect;
const esm_auth = auth;
const esm_currentUser = currentUser;
const esm_clerkClient = clerkClient;
const esm_authMiddleware = authMiddleware;
const esm_redirectToSignIn = redirectToSignIn;
const esm_redirectToSignUp = redirectToSignUp;
const esm_withClerkMiddleware = withClerkMiddleware;
 //# sourceMappingURL=index.js.map


/***/ }),

/***/ 63304:
/***/ ((module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "bailoutToClientRendering", ({
    enumerable: true,
    get: function() {
        return bailoutToClientRendering;
    }
}));
const _dynamicnossr = __webpack_require__(31154);
const _staticgenerationasyncstorage = __webpack_require__(30094);
function bailoutToClientRendering() {
    const staticGenerationStore = _staticgenerationasyncstorage.staticGenerationAsyncStorage.getStore();
    if (staticGenerationStore == null ? void 0 : staticGenerationStore.forceStatic) {
        return true;
    }
    if (staticGenerationStore == null ? void 0 : staticGenerationStore.isStaticGeneration) {
        (0, _dynamicnossr.suspense)();
    }
    return false;
}
if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
    Object.defineProperty(exports.default, "__esModule", {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=bailout-to-client-rendering.js.map


/***/ }),

/***/ 88255:
/***/ ((module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "clientHookInServerComponentError", ({
    enumerable: true,
    get: function() {
        return clientHookInServerComponentError;
    }
}));
const _interop_require_default = __webpack_require__(21550);
const _react = /*#__PURE__*/ _interop_require_default._(__webpack_require__(7887));
function clientHookInServerComponentError(hookName) {
    if (false) {}
}
if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
    Object.defineProperty(exports.default, "__esModule", {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=client-hook-in-server-component-error.js.map


/***/ }),

/***/ 11477:
/***/ ((module, exports, __webpack_require__) => {

// useLayoutSegments() // Only the segments for the current place. ['children', 'dashboard', 'children', 'integrations'] -> /dashboard/integrations (/dashboard/layout.js would get ['children', 'dashboard', 'children', 'integrations'])

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
0 && (0);
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    ReadonlyURLSearchParams: function() {
        return ReadonlyURLSearchParams;
    },
    useSearchParams: function() {
        return useSearchParams;
    },
    usePathname: function() {
        return usePathname;
    },
    ServerInsertedHTMLContext: function() {
        return _serverinsertedhtml.ServerInsertedHTMLContext;
    },
    useServerInsertedHTML: function() {
        return _serverinsertedhtml.useServerInsertedHTML;
    },
    useRouter: function() {
        return useRouter;
    },
    useParams: function() {
        return useParams;
    },
    useSelectedLayoutSegments: function() {
        return useSelectedLayoutSegments;
    },
    useSelectedLayoutSegment: function() {
        return useSelectedLayoutSegment;
    },
    redirect: function() {
        return _redirect.redirect;
    },
    notFound: function() {
        return _notfound.notFound;
    }
});
const _react = __webpack_require__(7887);
const _approutercontext = __webpack_require__(47476);
const _hooksclientcontext = __webpack_require__(10524);
const _clienthookinservercomponenterror = __webpack_require__(88255);
const _getsegmentvalue = __webpack_require__(57665);
const _serverinsertedhtml = __webpack_require__(3728);
const _redirect = __webpack_require__(6552);
const _notfound = __webpack_require__(54399);
const INTERNAL_URLSEARCHPARAMS_INSTANCE = Symbol("internal for urlsearchparams readonly");
function readonlyURLSearchParamsError() {
    return new Error("ReadonlyURLSearchParams cannot be modified");
}
class ReadonlyURLSearchParams {
    [Symbol.iterator]() {
        return this[INTERNAL_URLSEARCHPARAMS_INSTANCE][Symbol.iterator]();
    }
    append() {
        throw readonlyURLSearchParamsError();
    }
    delete() {
        throw readonlyURLSearchParamsError();
    }
    set() {
        throw readonlyURLSearchParamsError();
    }
    sort() {
        throw readonlyURLSearchParamsError();
    }
    constructor(urlSearchParams){
        this[INTERNAL_URLSEARCHPARAMS_INSTANCE] = urlSearchParams;
        this.entries = urlSearchParams.entries.bind(urlSearchParams);
        this.forEach = urlSearchParams.forEach.bind(urlSearchParams);
        this.get = urlSearchParams.get.bind(urlSearchParams);
        this.getAll = urlSearchParams.getAll.bind(urlSearchParams);
        this.has = urlSearchParams.has.bind(urlSearchParams);
        this.keys = urlSearchParams.keys.bind(urlSearchParams);
        this.values = urlSearchParams.values.bind(urlSearchParams);
        this.toString = urlSearchParams.toString.bind(urlSearchParams);
    }
}
function useSearchParams() {
    (0, _clienthookinservercomponenterror.clientHookInServerComponentError)("useSearchParams");
    const searchParams = (0, _react.useContext)(_hooksclientcontext.SearchParamsContext);
    // In the case where this is `null`, the compat types added in
    // `next-env.d.ts` will add a new overload that changes the return type to
    // include `null`.
    const readonlySearchParams = (0, _react.useMemo)(()=>{
        if (!searchParams) {
            // When the router is not ready in pages, we won't have the search params
            // available.
            return null;
        }
        return new ReadonlyURLSearchParams(searchParams);
    }, [
        searchParams
    ]);
    if (true) {
        // AsyncLocalStorage should not be included in the client bundle.
        const { bailoutToClientRendering } = __webpack_require__(63304);
        if (bailoutToClientRendering()) {
            // TODO-APP: handle dynamic = 'force-static' here and on the client
            return readonlySearchParams;
        }
    }
    return readonlySearchParams;
}
function usePathname() {
    (0, _clienthookinservercomponenterror.clientHookInServerComponentError)("usePathname");
    // In the case where this is `null`, the compat types added in `next-env.d.ts`
    // will add a new overload that changes the return type to include `null`.
    return (0, _react.useContext)(_hooksclientcontext.PathnameContext);
}
function useRouter() {
    (0, _clienthookinservercomponenterror.clientHookInServerComponentError)("useRouter");
    const router = (0, _react.useContext)(_approutercontext.AppRouterContext);
    if (router === null) {
        throw new Error("invariant expected app router to be mounted");
    }
    return router;
}
// this function performs a depth-first search of the tree to find the selected
// params
function getSelectedParams(tree, params) {
    if (params === void 0) params = {};
    const parallelRoutes = tree[1];
    for (const parallelRoute of Object.values(parallelRoutes)){
        const segment = parallelRoute[0];
        const isDynamicParameter = Array.isArray(segment);
        const segmentValue = isDynamicParameter ? segment[1] : segment;
        if (!segmentValue || segmentValue.startsWith("__PAGE__")) continue;
        if (isDynamicParameter) {
            params[segment[0]] = segment[1];
        }
        params = getSelectedParams(parallelRoute, params);
    }
    return params;
}
function useParams() {
    (0, _clienthookinservercomponenterror.clientHookInServerComponentError)("useParams");
    const globalLayoutRouterContext = (0, _react.useContext)(_approutercontext.GlobalLayoutRouterContext);
    if (!globalLayoutRouterContext) {
        // This only happens in `pages`. Type is overwritten in navigation.d.ts
        return null;
    }
    return getSelectedParams(globalLayoutRouterContext.tree);
}
// TODO-APP: handle parallel routes
/**
 * Get the canonical parameters from the current level to the leaf node.
 */ function getSelectedLayoutSegmentPath(tree, parallelRouteKey, first, segmentPath) {
    if (first === void 0) first = true;
    if (segmentPath === void 0) segmentPath = [];
    let node;
    if (first) {
        // Use the provided parallel route key on the first parallel route
        node = tree[1][parallelRouteKey];
    } else {
        // After first parallel route prefer children, if there's no children pick the first parallel route.
        const parallelRoutes = tree[1];
        var _parallelRoutes_children;
        node = (_parallelRoutes_children = parallelRoutes.children) != null ? _parallelRoutes_children : Object.values(parallelRoutes)[0];
    }
    if (!node) return segmentPath;
    const segment = node[0];
    const segmentValue = (0, _getsegmentvalue.getSegmentValue)(segment);
    if (!segmentValue || segmentValue.startsWith("__PAGE__")) return segmentPath;
    segmentPath.push(segmentValue);
    return getSelectedLayoutSegmentPath(node, parallelRouteKey, false, segmentPath);
}
function useSelectedLayoutSegments(parallelRouteKey) {
    if (parallelRouteKey === void 0) parallelRouteKey = "children";
    (0, _clienthookinservercomponenterror.clientHookInServerComponentError)("useSelectedLayoutSegments");
    const { tree } = (0, _react.useContext)(_approutercontext.LayoutRouterContext);
    return getSelectedLayoutSegmentPath(tree, parallelRouteKey);
}
function useSelectedLayoutSegment(parallelRouteKey) {
    if (parallelRouteKey === void 0) parallelRouteKey = "children";
    (0, _clienthookinservercomponenterror.clientHookInServerComponentError)("useSelectedLayoutSegment");
    const selectedLayoutSegments = useSelectedLayoutSegments(parallelRouteKey);
    if (selectedLayoutSegments.length === 0) {
        return null;
    }
    return selectedLayoutSegments[0];
}
if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
    Object.defineProperty(exports.default, "__esModule", {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=navigation.js.map


/***/ }),

/***/ 57665:
/***/ ((module, exports) => {


Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "getSegmentValue", ({
    enumerable: true,
    get: function() {
        return getSegmentValue;
    }
}));
function getSegmentValue(segment) {
    return Array.isArray(segment) ? segment[1] : segment;
}
if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
    Object.defineProperty(exports.default, "__esModule", {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=get-segment-value.js.map


/***/ }),

/***/ 47476:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  cjs */ 
const { createProxy } = __webpack_require__(21313);
module.exports = createProxy("/home/vagrant/agent/workspace/jira_clone_PR-1/node_modules/next/dist/shared/lib/app-router-context.js");
 //# sourceMappingURL=app-router-context.js.map


/***/ }),

/***/ 10524:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  cjs */ 
const { createProxy } = __webpack_require__(21313);
module.exports = createProxy("/home/vagrant/agent/workspace/jira_clone_PR-1/node_modules/next/dist/shared/lib/hooks-client-context.js");
 //# sourceMappingURL=hooks-client-context.js.map


/***/ }),

/***/ 31154:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  cjs */ 
const { createProxy } = __webpack_require__(21313);
module.exports = createProxy("/home/vagrant/agent/workspace/jira_clone_PR-1/node_modules/next/dist/shared/lib/lazy-dynamic/dynamic-no-ssr.js");
 //# sourceMappingURL=dynamic-no-ssr.js.map


/***/ }),

/***/ 3728:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  cjs */ 
const { createProxy } = __webpack_require__(21313);
module.exports = createProxy("/home/vagrant/agent/workspace/jira_clone_PR-1/node_modules/next/dist/shared/lib/server-inserted-html.js");
 //# sourceMappingURL=server-inserted-html.js.map


/***/ }),

/***/ 78875:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


module.exports = __webpack_require__(11477);


/***/ }),

/***/ 71383:
/***/ ((__unused_webpack_module, exports) => {

var __webpack_unused_export__;

__webpack_unused_export__ = ({
    value: true
});
exports.Bo = __webpack_unused_export__ = __webpack_unused_export__ = __webpack_unused_export__ = __webpack_unused_export__ = __webpack_unused_export__ = __webpack_unused_export__ = void 0;
/**
 * Tokenize input string.
 */ function lexer(str) {
    var tokens = [];
    var i = 0;
    while(i < str.length){
        var char = str[i];
        if (char === "*" || char === "+" || char === "?") {
            tokens.push({
                type: "MODIFIER",
                index: i,
                value: str[i++]
            });
            continue;
        }
        if (char === "\\") {
            tokens.push({
                type: "ESCAPED_CHAR",
                index: i++,
                value: str[i++]
            });
            continue;
        }
        if (char === "{") {
            tokens.push({
                type: "OPEN",
                index: i,
                value: str[i++]
            });
            continue;
        }
        if (char === "}") {
            tokens.push({
                type: "CLOSE",
                index: i,
                value: str[i++]
            });
            continue;
        }
        if (char === ":") {
            var name = "";
            var j = i + 1;
            while(j < str.length){
                var code = str.charCodeAt(j);
                if (// `0-9`
                code >= 48 && code <= 57 || // `A-Z`
                code >= 65 && code <= 90 || // `a-z`
                code >= 97 && code <= 122 || // `_`
                code === 95) {
                    name += str[j++];
                    continue;
                }
                break;
            }
            if (!name) throw new TypeError("Missing parameter name at ".concat(i));
            tokens.push({
                type: "NAME",
                index: i,
                value: name
            });
            i = j;
            continue;
        }
        if (char === "(") {
            var count = 1;
            var pattern = "";
            var j = i + 1;
            if (str[j] === "?") {
                throw new TypeError('Pattern cannot start with "?" at '.concat(j));
            }
            while(j < str.length){
                if (str[j] === "\\") {
                    pattern += str[j++] + str[j++];
                    continue;
                }
                if (str[j] === ")") {
                    count--;
                    if (count === 0) {
                        j++;
                        break;
                    }
                } else if (str[j] === "(") {
                    count++;
                    if (str[j + 1] !== "?") {
                        throw new TypeError("Capturing groups are not allowed at ".concat(j));
                    }
                }
                pattern += str[j++];
            }
            if (count) throw new TypeError("Unbalanced pattern at ".concat(i));
            if (!pattern) throw new TypeError("Missing pattern at ".concat(i));
            tokens.push({
                type: "PATTERN",
                index: i,
                value: pattern
            });
            i = j;
            continue;
        }
        tokens.push({
            type: "CHAR",
            index: i,
            value: str[i++]
        });
    }
    tokens.push({
        type: "END",
        index: i,
        value: ""
    });
    return tokens;
}
/**
 * Parse a string for the raw tokens.
 */ function parse(str, options) {
    if (options === void 0) {
        options = {};
    }
    var tokens = lexer(str);
    var _a = options.prefixes, prefixes = _a === void 0 ? "./" : _a;
    var defaultPattern = "[^".concat(escapeString(options.delimiter || "/#?"), "]+?");
    var result = [];
    var key = 0;
    var i = 0;
    var path = "";
    var tryConsume = function(type) {
        if (i < tokens.length && tokens[i].type === type) return tokens[i++].value;
    };
    var mustConsume = function(type) {
        var value = tryConsume(type);
        if (value !== undefined) return value;
        var _a = tokens[i], nextType = _a.type, index = _a.index;
        throw new TypeError("Unexpected ".concat(nextType, " at ").concat(index, ", expected ").concat(type));
    };
    var consumeText = function() {
        var result = "";
        var value;
        while(value = tryConsume("CHAR") || tryConsume("ESCAPED_CHAR")){
            result += value;
        }
        return result;
    };
    while(i < tokens.length){
        var char = tryConsume("CHAR");
        var name = tryConsume("NAME");
        var pattern = tryConsume("PATTERN");
        if (name || pattern) {
            var prefix = char || "";
            if (prefixes.indexOf(prefix) === -1) {
                path += prefix;
                prefix = "";
            }
            if (path) {
                result.push(path);
                path = "";
            }
            result.push({
                name: name || key++,
                prefix: prefix,
                suffix: "",
                pattern: pattern || defaultPattern,
                modifier: tryConsume("MODIFIER") || ""
            });
            continue;
        }
        var value = char || tryConsume("ESCAPED_CHAR");
        if (value) {
            path += value;
            continue;
        }
        if (path) {
            result.push(path);
            path = "";
        }
        var open = tryConsume("OPEN");
        if (open) {
            var prefix = consumeText();
            var name_1 = tryConsume("NAME") || "";
            var pattern_1 = tryConsume("PATTERN") || "";
            var suffix = consumeText();
            mustConsume("CLOSE");
            result.push({
                name: name_1 || (pattern_1 ? key++ : ""),
                pattern: name_1 && !pattern_1 ? defaultPattern : pattern_1,
                prefix: prefix,
                suffix: suffix,
                modifier: tryConsume("MODIFIER") || ""
            });
            continue;
        }
        mustConsume("END");
    }
    return result;
}
__webpack_unused_export__ = parse;
/**
 * Compile a string to a template function for the path.
 */ function compile(str, options) {
    return tokensToFunction(parse(str, options), options);
}
__webpack_unused_export__ = compile;
/**
 * Expose a method for transforming tokens into the path function.
 */ function tokensToFunction(tokens, options) {
    if (options === void 0) {
        options = {};
    }
    var reFlags = flags(options);
    var _a = options.encode, encode = _a === void 0 ? function(x) {
        return x;
    } : _a, _b = options.validate, validate = _b === void 0 ? true : _b;
    // Compile all the tokens into regexps.
    var matches = tokens.map(function(token) {
        if (typeof token === "object") {
            return new RegExp("^(?:".concat(token.pattern, ")$"), reFlags);
        }
    });
    return function(data) {
        var path = "";
        for(var i = 0; i < tokens.length; i++){
            var token = tokens[i];
            if (typeof token === "string") {
                path += token;
                continue;
            }
            var value = data ? data[token.name] : undefined;
            var optional = token.modifier === "?" || token.modifier === "*";
            var repeat = token.modifier === "*" || token.modifier === "+";
            if (Array.isArray(value)) {
                if (!repeat) {
                    throw new TypeError('Expected "'.concat(token.name, '" to not repeat, but got an array'));
                }
                if (value.length === 0) {
                    if (optional) continue;
                    throw new TypeError('Expected "'.concat(token.name, '" to not be empty'));
                }
                for(var j = 0; j < value.length; j++){
                    var segment = encode(value[j], token);
                    if (validate && !matches[i].test(segment)) {
                        throw new TypeError('Expected all "'.concat(token.name, '" to match "').concat(token.pattern, '", but got "').concat(segment, '"'));
                    }
                    path += token.prefix + segment + token.suffix;
                }
                continue;
            }
            if (typeof value === "string" || typeof value === "number") {
                var segment = encode(String(value), token);
                if (validate && !matches[i].test(segment)) {
                    throw new TypeError('Expected "'.concat(token.name, '" to match "').concat(token.pattern, '", but got "').concat(segment, '"'));
                }
                path += token.prefix + segment + token.suffix;
                continue;
            }
            if (optional) continue;
            var typeOfMessage = repeat ? "an array" : "a string";
            throw new TypeError('Expected "'.concat(token.name, '" to be ').concat(typeOfMessage));
        }
        return path;
    };
}
__webpack_unused_export__ = tokensToFunction;
/**
 * Create path match function from `path-to-regexp` spec.
 */ function match(str, options) {
    var keys = [];
    var re = pathToRegexp(str, keys, options);
    return regexpToFunction(re, keys, options);
}
__webpack_unused_export__ = match;
/**
 * Create a path match function from `path-to-regexp` output.
 */ function regexpToFunction(re, keys, options) {
    if (options === void 0) {
        options = {};
    }
    var _a = options.decode, decode = _a === void 0 ? function(x) {
        return x;
    } : _a;
    return function(pathname) {
        var m = re.exec(pathname);
        if (!m) return false;
        var path = m[0], index = m.index;
        var params = Object.create(null);
        var _loop_1 = function(i) {
            if (m[i] === undefined) return "continue";
            var key = keys[i - 1];
            if (key.modifier === "*" || key.modifier === "+") {
                params[key.name] = m[i].split(key.prefix + key.suffix).map(function(value) {
                    return decode(value, key);
                });
            } else {
                params[key.name] = decode(m[i], key);
            }
        };
        for(var i = 1; i < m.length; i++){
            _loop_1(i);
        }
        return {
            path: path,
            index: index,
            params: params
        };
    };
}
__webpack_unused_export__ = regexpToFunction;
/**
 * Escape a regular expression string.
 */ function escapeString(str) {
    return str.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1");
}
/**
 * Get the flags for a regexp from the options.
 */ function flags(options) {
    return options && options.sensitive ? "" : "i";
}
/**
 * Pull out keys from a regexp.
 */ function regexpToRegexp(path, keys) {
    if (!keys) return path;
    var groupsRegex = /\((?:\?<(.*?)>)?(?!\?)/g;
    var index = 0;
    var execResult = groupsRegex.exec(path.source);
    while(execResult){
        keys.push({
            // Use parenthesized substring match if available, index otherwise
            name: execResult[1] || index++,
            prefix: "",
            suffix: "",
            modifier: "",
            pattern: ""
        });
        execResult = groupsRegex.exec(path.source);
    }
    return path;
}
/**
 * Transform an array into a regexp.
 */ function arrayToRegexp(paths, keys, options) {
    var parts = paths.map(function(path) {
        return pathToRegexp(path, keys, options).source;
    });
    return new RegExp("(?:".concat(parts.join("|"), ")"), flags(options));
}
/**
 * Create a path regexp from string input.
 */ function stringToRegexp(path, keys, options) {
    return tokensToRegexp(parse(path, options), keys, options);
}
/**
 * Expose a function for taking tokens and returning a RegExp.
 */ function tokensToRegexp(tokens, keys, options) {
    if (options === void 0) {
        options = {};
    }
    var _a = options.strict, strict = _a === void 0 ? false : _a, _b = options.start, start = _b === void 0 ? true : _b, _c = options.end, end = _c === void 0 ? true : _c, _d = options.encode, encode = _d === void 0 ? function(x) {
        return x;
    } : _d, _e = options.delimiter, delimiter = _e === void 0 ? "/#?" : _e, _f = options.endsWith, endsWith = _f === void 0 ? "" : _f;
    var endsWithRe = "[".concat(escapeString(endsWith), "]|$");
    var delimiterRe = "[".concat(escapeString(delimiter), "]");
    var route = start ? "^" : "";
    // Iterate over the tokens and create our regexp string.
    for(var _i = 0, tokens_1 = tokens; _i < tokens_1.length; _i++){
        var token = tokens_1[_i];
        if (typeof token === "string") {
            route += escapeString(encode(token));
        } else {
            var prefix = escapeString(encode(token.prefix));
            var suffix = escapeString(encode(token.suffix));
            if (token.pattern) {
                if (keys) keys.push(token);
                if (prefix || suffix) {
                    if (token.modifier === "+" || token.modifier === "*") {
                        var mod = token.modifier === "*" ? "?" : "";
                        route += "(?:".concat(prefix, "((?:").concat(token.pattern, ")(?:").concat(suffix).concat(prefix, "(?:").concat(token.pattern, "))*)").concat(suffix, ")").concat(mod);
                    } else {
                        route += "(?:".concat(prefix, "(").concat(token.pattern, ")").concat(suffix, ")").concat(token.modifier);
                    }
                } else {
                    if (token.modifier === "+" || token.modifier === "*") {
                        route += "((?:".concat(token.pattern, ")").concat(token.modifier, ")");
                    } else {
                        route += "(".concat(token.pattern, ")").concat(token.modifier);
                    }
                }
            } else {
                route += "(?:".concat(prefix).concat(suffix, ")").concat(token.modifier);
            }
        }
    }
    if (end) {
        if (!strict) route += "".concat(delimiterRe, "?");
        route += !options.endsWith ? "$" : "(?=".concat(endsWithRe, ")");
    } else {
        var endToken = tokens[tokens.length - 1];
        var isEndDelimited = typeof endToken === "string" ? delimiterRe.indexOf(endToken[endToken.length - 1]) > -1 : endToken === undefined;
        if (!strict) {
            route += "(?:".concat(delimiterRe, "(?=").concat(endsWithRe, "))?");
        }
        if (!isEndDelimited) {
            route += "(?=".concat(delimiterRe, "|").concat(endsWithRe, ")");
        }
    }
    return new RegExp(route, flags(options));
}
__webpack_unused_export__ = tokensToRegexp;
/**
 * Normalize the given path string, returning a regular expression.
 *
 * An empty array can be passed in for the keys, which will hold the
 * placeholder key descriptions. For example, using `/user/:id`, `keys` will
 * contain `[{ name: 'id', delimiter: '/', optional: false, repeat: false }]`.
 */ function pathToRegexp(path, keys, options) {
    if (path instanceof RegExp) return regexpToRegexp(path, keys);
    if (Array.isArray(path)) return arrayToRegexp(path, keys, options);
    return stringToRegexp(path, keys, options);
}
exports.Bo = pathToRegexp; //# sourceMappingURL=index.js.map


/***/ })

};
;