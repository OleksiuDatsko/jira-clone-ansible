(() => {
var exports = {};
exports.id = 530;
exports.ids = [530];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

"use strict";
module.exports = require("@prisma/client");

/***/ }),

/***/ 97783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 40252:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 97999:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 61090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 78652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 47244:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 21668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 72254:
/***/ ((module) => {

"use strict";
module.exports = require("node:buffer");

/***/ }),

/***/ 6005:
/***/ ((module) => {

"use strict";
module.exports = require("node:crypto");

/***/ }),

/***/ 87561:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ 88849:
/***/ ((module) => {

"use strict";
module.exports = require("node:http");

/***/ }),

/***/ 22286:
/***/ ((module) => {

"use strict";
module.exports = require("node:https");

/***/ }),

/***/ 87503:
/***/ ((module) => {

"use strict";
module.exports = require("node:net");

/***/ }),

/***/ 49411:
/***/ ((module) => {

"use strict";
module.exports = require("node:path");

/***/ }),

/***/ 97742:
/***/ ((module) => {

"use strict";
module.exports = require("node:process");

/***/ }),

/***/ 84492:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream");

/***/ }),

/***/ 72477:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream/web");

/***/ }),

/***/ 41041:
/***/ ((module) => {

"use strict";
module.exports = require("node:url");

/***/ }),

/***/ 47261:
/***/ ((module) => {

"use strict";
module.exports = require("node:util");

/***/ }),

/***/ 65628:
/***/ ((module) => {

"use strict";
module.exports = require("node:zlib");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 71267:
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 15869:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppRouter: () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   LayoutRouter: () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   RenderFromTemplateContext: () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   StaticGenerationSearchParamsBailoutProvider: () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   __next_app_webpack_require__: () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   actionAsyncStorage: () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   createSearchParamsBailoutProxy: () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   decodeAction: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   decodeReply: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   preconnect: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   preloadFont: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   preloadStyle: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   renderToReadableStream: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   requestAsyncStorage: () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   serverHooks: () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   staticGenerationAsyncStorage: () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   staticGenerationBailout: () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(54592);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(76301);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57431);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(30094);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(24437);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(46127);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(45486);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(86404);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(95486);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(63332);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(27902);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(93099);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'project',
        {
        children: [
        'backlog',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 67876)), "/home/vagrant/agent/workspace/jira_clone_PR-1/app/project/backlog/page.tsx"],
          
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 45938)), "/home/vagrant/agent/workspace/jira_clone_PR-1/app/project/backlog/layout.tsx"],
'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 19179)), "/home/vagrant/agent/workspace/jira_clone_PR-1/app/project/backlog/loading.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 10864)), "/home/vagrant/agent/workspace/jira_clone_PR-1/app/project/backlog/not-found.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 86484)), "/home/vagrant/agent/workspace/jira_clone_PR-1/app/project/layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 21701))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76770)), "/home/vagrant/agent/workspace/jira_clone_PR-1/app/layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 21701))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["/home/vagrant/agent/workspace/jira_clone_PR-1/app/project/backlog/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/project/backlog/page"
  

/***/ }),

/***/ 1482:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3280, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 69274, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3349, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 90701, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 38973));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 92557));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 25950));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 95525));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 45008));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 15179));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 19329));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 98417));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 46158));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 15531));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 41757));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 38221));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 33369));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 90078));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3030));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 41380));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83888))

/***/ }),

/***/ 83888:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Backlog: () => (/* binding */ Backlog)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./node_modules/react-split/dist/react-split.js
var react_split = __webpack_require__(49641);
var react_split_default = /*#__PURE__*/__webpack_require__.n(react_split);
// EXTERNAL MODULE: ./hooks/query-hooks/use-issues/index.ts + 4 modules
var use_issues = __webpack_require__(14184);
// EXTERNAL MODULE: ./node_modules/clsx/dist/clsx.js
var clsx = __webpack_require__(14889);
var clsx_default = /*#__PURE__*/__webpack_require__.n(clsx);
// EXTERNAL MODULE: ./node_modules/react-icons/fa/index.esm.js
var index_esm = __webpack_require__(16775);
// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(38546);
// EXTERNAL MODULE: ./node_modules/react-beautiful-dnd/dist/react-beautiful-dnd.cjs.js
var react_beautiful_dnd_cjs = __webpack_require__(85926);
// EXTERNAL MODULE: ./components/ui/accordion.tsx
var accordion = __webpack_require__(74887);
// EXTERNAL MODULE: ./components/backlog/issue.tsx
var backlog_issue = __webpack_require__(20645);
// EXTERNAL MODULE: ./node_modules/react-icons/ai/index.esm.js
var ai_index_esm = __webpack_require__(19722);
// EXTERNAL MODULE: ./components/issue/issue-empty.tsx
var issue_empty = __webpack_require__(74349);
// EXTERNAL MODULE: ./node_modules/@clerk/clerk-react/dist/esm/index.js + 63 modules
var esm = __webpack_require__(48751);
// EXTERNAL MODULE: ./hooks/use-strictmode-droppable.ts
var use_strictmode_droppable = __webpack_require__(83919);
// EXTERNAL MODULE: ./hooks/use-is-authed.ts
var use_is_authed = __webpack_require__(30660);
;// CONCATENATED MODULE: ./components/backlog/issue-list.tsx
/* __next_internal_client_entry_do_not_use__ IssueList auto */ 












const IssueList = ({ sprintId, issues })=>{
    const { createIssue, isCreating } = (0,use_issues/* useIssues */.g)();
    const { user } = (0,esm/* useUser */.aF)();
    const [isEditing, setIsEditing] = (0,react_.useState)(false);
    const [droppableEnabled] = (0,use_strictmode_droppable/* useStrictModeDroppable */.d)();
    const [isAuthenticated, openAuthModal] = (0,use_is_authed/* useIsAuthenticated */.k)();
    if (!droppableEnabled) {
        return null;
    }
    function handleCreateIssue({ name, type }) {
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        if (!name) {
            return;
        }
        createIssue({
            name,
            type,
            parentId: null,
            sprintId,
            reporterId: user?.id ?? null
        }, {
            onSuccess: ()=>{
                setIsEditing(false);
            }
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(accordion/* AccordionContent */.vF, {
        className: "pt-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(react_beautiful_dnd_cjs/* Droppable */.bK, {
                droppableId: sprintId ?? "backlog",
                children: ({ droppableProps, innerRef, placeholder })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        ...droppableProps,
                        ref: innerRef,
                        className: clsx_default()(issues.length == 0 && "min-h-[1px]"),
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: clsx_default()(issues.length && "border-[0.3px]", "divide-y "),
                                children: issues.sort((a, b)=>a.sprintPosition - b.sprintPosition).map((issue, index)=>/*#__PURE__*/ jsx_runtime_.jsx(backlog_issue/* Issue */.$, {
                                        index: index,
                                        issue: issue
                                    }, issue.id))
                            }),
                            placeholder
                        ]
                    })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                onClick: ()=>setIsEditing(true),
                "data-state": isEditing ? "closed" : "open",
                customColors: true,
                className: "my-1 flex w-full bg-transparent hover:bg-gray-200 [&[data-state=closed]]:hidden",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(ai_index_esm/* AiOutlinePlus */.Lfi, {
                        className: "text-sm"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-sm",
                        children: "Create Issue"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(issue_empty/* EmtpyIssue */.z, {
                "data-state": isEditing ? "open" : "closed",
                className: "[&[data-state=closed]]:hidden",
                onCreate: ({ name, type })=>handleCreateIssue({
                        name,
                        type
                    }),
                onCancel: ()=>setIsEditing(false),
                isCreating: isCreating
            })
        ]
    });
};


// EXTERNAL MODULE: ./components/issue/issue-status-count.tsx
var issue_status_count = __webpack_require__(14389);
// EXTERNAL MODULE: ./hooks/query-hooks/use-sprints.ts
var use_sprints = __webpack_require__(75589);
;// CONCATENATED MODULE: ./components/backlog/list-backlog.tsx
/* __next_internal_client_entry_do_not_use__ BacklogList auto */ 








const BacklogList = ({ id, issues })=>{
    const [openAccordion, setOpenAccordion] = (0,react_.useState)("");
    (0,react_.useEffect)(()=>{
        setOpenAccordion(`backlog`); // Open accordion on mount in order for DND to work.
    }, [
        id
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(accordion/* Accordion */.UQ, {
        className: "rounded-md pb-20 pl-2",
        type: "single",
        value: openAccordion,
        onValueChange: setOpenAccordion,
        collapsible: true,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(accordion/* AccordionItem */.Qd, {
            value: `backlog`,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(BacklogListHeader, {
                    issues: issues ?? []
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(IssueList, {
                    sprintId: null,
                    issues: issues ?? []
                })
            ]
        })
    });
};
const BacklogListHeader = ({ issues })=>{
    const { createSprint } = (0,use_sprints/* useSprints */.D)();
    const [isAuthenticated, openAuthModal] = (0,use_is_authed/* useIsAuthenticated */.k)();
    function handleCreateSprint() {
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        createSprint();
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex w-full items-center justify-between text-sm ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(accordion/* AccordionTrigger */.o4, {
                className: "flex w-full items-center p-2 font-medium [&[data-state=open]>svg]:rotate-90",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* FaChevronRight */.Dli, {
                            className: "mr-2 text-xs text-black transition-transform",
                            "aria-hidden": true
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-semibold",
                                    children: "Backlog"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "ml-3 font-normal text-gray-500",
                                    children: [
                                        "(",
                                        issues.length,
                                        " issues)"
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center gap-x-2 py-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(issue_status_count/* IssueStatusCount */._, {
                        issues: issues
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                        onClick: handleCreateSprint,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "whitespace-nowrap",
                            children: "Create Sprint"
                        })
                    })
                ]
            })
        ]
    });
};


// EXTERNAL MODULE: ./node_modules/react-icons/bs/index.esm.js
var bs_index_esm = __webpack_require__(75484);
// EXTERNAL MODULE: ./components/ui/dropdown-menu.tsx
var dropdown_menu = __webpack_require__(41772);
;// CONCATENATED MODULE: ./components/backlog/sprint-menu.tsx




const SprintDropdownMenu = ({ children, setUpdateModalIsOpen, setDeleteModalIsOpen })=>{
    const menuOptions = [
        {
            id: "edit",
            label: "Edit Sprint"
        },
        {
            id: "delete",
            label: "Delete Sprint"
        }
    ];
    const handleSprintAction = (id, e)=>{
        e.stopPropagation();
        if (id == "delete") {
            setDeleteModalIsOpen(true);
        } else if (id == "edit") {
            setUpdateModalIsOpen(true);
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dropdown_menu/* Dropdown */.Lt, {
            modal: false,
            children: [
                children,
                /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu/* DropdownPortal */.nI, {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dropdown_menu/* DropdownContent */.Nv, {
                        side: "top",
                        sideOffset: 5,
                        align: "end",
                        className: "z-10 w-fit rounded-md border border-gray-300 bg-white shadow-md",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu/* DropdownLabel */.HF, {
                                className: "sr-only",
                                children: "ACTIONS"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu/* DropdownGroup */.pb, {
                                children: menuOptions.map((action)=>/*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu/* DropdownItem */.hP, {
                                        onClick: (e)=>handleSprintAction(action.id, e),
                                        textValue: action.label,
                                        className: clsx_default()("border-transparent px-4 py-2 text-sm hover:cursor-default hover:bg-gray-100"),
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: clsx_default()("pr-2 text-sm"),
                                            children: action.label
                                        })
                                    }, action.id))
                            })
                        ]
                    })
                })
            ]
        })
    });
};
SprintDropdownMenu.displayName = "SprintDropdownMenu";


// EXTERNAL MODULE: ./components/ui/modal.tsx
var modal = __webpack_require__(45977);
// EXTERNAL MODULE: ./node_modules/@tanstack/react-query/build/lib/QueryClientProvider.mjs
var QueryClientProvider = __webpack_require__(98417);
// EXTERNAL MODULE: ./node_modules/react-hook-form/dist/index.esm.mjs
var dist_index_esm = __webpack_require__(71031);
;// CONCATENATED MODULE: ./components/form/label.tsx

const Label = ({ text, required = true, ...props })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
        ...props,
        className: "my-1 flex gap-x-1 text-xs font-medium text-gray-500",
        children: [
            text,
            required ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "text-red-600",
                children: "*"
            }) : null
        ]
    });
};


;// CONCATENATED MODULE: ./components/form/error.tsx

const error_Error = ({ message, trigger })=>{
    if (!trigger) return null;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
        role: "alert",
        className: "text-xs text-red-600",
        children: [
            message,
            " *"
        ]
    });
};


;// CONCATENATED MODULE: ./components/modals/start-sprint/form/fields/name.tsx




const NameField = ({ errors, register })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "my-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Label, {
                htmlFor: "name",
                text: "Sprint Name"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                ...register("name", {
                    required: true
                }),
                "aria-invalid": errors.name ? "true" : "false",
                type: "text",
                id: "name",
                className: clsx_default()(errors.name ? "focus:outline-red-500" : "focus:outline-blue-400", " block h-10 w-64 rounded-[3px] border border-gray-300 px-2 text-sm shadow-sm outline-2 transition-all duration-75")
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(error_Error, {
                trigger: errors.name,
                message: "Sprint name is required"
            })
        ]
    });
};


// EXTERNAL MODULE: ./components/ui/select.tsx
var ui_select = __webpack_require__(13785);
;// CONCATENATED MODULE: ./components/modals/start-sprint/form/fields/duration.tsx








const DurationField = ({ control, errors })=>{
    const durationOptions = [
        "1 week",
        "2 weeks",
        "3 weeks",
        "4 weeks",
        "custom"
    ];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Label, {
                htmlFor: "duration",
                text: "Duration"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(dist_index_esm/* Controller */.Qr, {
                control: control,
                name: "duration",
                render: ({ field })=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_select/* Select */.Ph, {
                        onValueChange: field.onChange,
                        defaultValue: field.value,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_select/* SelectTrigger */.i4, {
                                className: "flex h-10 w-64 items-center justify-between rounded-[3px] bg-gray-100 px-2 text-xs font-semibold transition-all duration-200 hover:bg-gray-200 focus:ring-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectValue */.ki, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectIcon */.GV, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* FaChevronDown */.RiI, {
                                            className: "text-gray-500"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectPortal */.ue, {
                                className: "z-50",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectContent */.Bw, {
                                    position: "popper",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectViewport */.Q_, {
                                        className: "w-64 rounded-md border border-gray-300 bg-white py-2 shadow-md",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectGroup */.DI, {
                                            children: durationOptions.map((option)=>/*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectItem */.Ql, {
                                                    value: option,
                                                    className: clsx_default()("border-l-2 border-transparent py-2 pl-3 text-sm hover:cursor-default hover:border-inprogress hover:bg-gray-100 [&[data-state=checked]]:border-inprogress [&[data-state=checked]]:bg-blue-100 [&[data-state=checked]]:text-blue-600"),
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: clsx_default()("px-2 text-xs"),
                                                        children: option
                                                    })
                                                }, option))
                                        })
                                    })
                                })
                            })
                        ]
                    });
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(error_Error, {
                trigger: errors.duration,
                message: "Duration is required"
            })
        ]
    });
};


;// CONCATENATED MODULE: ./components/modals/start-sprint/form/fields/start-date.tsx






const StartDateField = ({ errors, register, control })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "my-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Label, {
                htmlFor: "startDate",
                text: "Start Date"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(dist_index_esm/* Controller */.Qr, {
                control: control,
                name: "startDate",
                render: ({ field: { value, onChange } })=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                htmlFor: "startDate",
                                className: "sr-only",
                                children: "Sprint start date picker"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                ...register("startDate", {
                                    required: true,
                                    valueAsDate: true
                                }),
                                "aria-invalid": errors.startDate ? "true" : "false",
                                type: "date",
                                value: value.toISOString().slice(0, 10),
                                onChange: (e)=>onChange(new Date(e.target.value)),
                                id: "startDate",
                                className: clsx_default()(errors.startDate ? "focus:outline-red-500" : "focus:outline-blue-400", "block h-10 w-64 rounded-[3px] border border-gray-300 px-2 text-sm shadow-sm outline-2 transition-all duration-75")
                            })
                        ]
                    });
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(error_Error, {
                trigger: errors.startDate,
                message: "Start date is required"
            })
        ]
    });
};


;// CONCATENATED MODULE: ./components/modals/start-sprint/form/fields/end-date.tsx






const EndDateField = ({ errors, register, duration, startDate, setValue })=>{
    const [endDate, setEndDate] = (0,react_.useState)(()=>new Date());
    const calculateEndDate = (0,react_.useCallback)((duration, startDate)=>{
        if (duration === "custom") return;
        const milliseconds = calculateMillisecondsFromDuration(duration ?? DEFAULT_DURATION);
        const _startDate = new Date(startDate ?? new Date());
        const _endDate = new Date(_startDate.getTime() + milliseconds);
        setEndDate(_endDate);
        setValue("endDate", _endDate);
    }, [
        setValue
    ]);
    (0,react_.useEffect)(()=>{
        calculateEndDate(duration, startDate);
    }, [
        duration,
        startDate,
        calculateEndDate
    ]);
    function calculateMillisecondsFromDuration(duration) {
        if (!duration || duration === "custom") return 0;
        const numberOfWeeks = parseInt(duration.split(" ")[0]);
        return numberOfWeeks * 7 * 24 * 60 * 60 * 1000;
    }
    function validateEndDate() {
        if (!endDate) return false;
        return new Date(startDate) <= new Date(endDate);
    }
    function handleCustomChange(event) {
        if (!event.target.value) return;
        const newDate = new Date(event.target.value);
        setEndDate(newDate);
        setValue("endDate", newDate);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "my-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Label, {
                htmlFor: "endDate",
                text: "End Date"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                ...register("endDate", {
                    required: duration === "custom" ? true : false,
                    valueAsDate: true,
                    validate: {
                        startDateBeforeEndDate: ()=>validateEndDate()
                    }
                }),
                "aria-invalid": errors.endDate ? "true" : "false",
                type: "date",
                disabled: duration !== "custom",
                value: endDate.toISOString().slice(0, 10),
                onChange: handleCustomChange,
                id: "endDate",
                className: clsx_default()(duration === "custom" ? "" : "bg-gray-200 opacity-50", errors.endDate ? "focus:outline-red-500" : "focus:outline-blue-400", "block h-10 w-64 rounded-[3px] border border-gray-300 px-2 text-sm shadow-sm outline-2 transition-all duration-75")
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(error_Error, {
                trigger: errors.endDate,
                message: "The end date of a sprint must be after the start date."
            })
        ]
    });
};


;// CONCATENATED MODULE: ./components/modals/start-sprint/form/fields/description.tsx


const DescriptionField = ({ register })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "my-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Label, {
                htmlFor: "description",
                text: "Sprint Goal",
                required: false
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                ...register("description"),
                id: "description",
                className: "block h-32 w-[500px] rounded-[3px] border border-gray-300 p-2 text-sm shadow-sm outline-2 transition-all duration-75 focus:outline-blue-400"
            })
        ]
    });
};


// EXTERNAL MODULE: ./components/ui/spinner.tsx
var spinner = __webpack_require__(35215);
;// CONCATENATED MODULE: ./components/form/submit.tsx



const FormSubmit = ({ isLoading, onCancel, submitText, ariaLabel })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "mt-5 flex w-full justify-end",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                customColors: true,
                customPadding: true,
                className: "flex items-center gap-x-2 bg-inprogress px-3 py-1.5 font-medium text-white hover:brightness-110",
                type: "submit",
                name: ariaLabel,
                disabled: isLoading,
                "aria-label": ariaLabel,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: submitText
                    }),
                    isLoading ? /*#__PURE__*/ jsx_runtime_.jsx(spinner/* Spinner */.$, {
                        white: true,
                        size: "sm"
                    }) : null
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                customColors: true,
                customPadding: true,
                onClick: onCancel,
                className: "px-3 py-1.5 font-medium text-inprogress underline-offset-2 hover:underline hover:brightness-110",
                name: "cancel",
                "aria-label": "cancel",
                children: "Cancel"
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/modals/start-sprint/form/index.tsx
/* __next_internal_client_entry_do_not_use__ DEFAULT_DURATION,StartSprintForm auto */ 










const DEFAULT_DURATION = "1 week";
const StartSprintForm = ({ sprint, setModalIsOpen })=>{
    const { handleSubmit, register, formState: { errors }, control, setValue, reset, watch } = (0,dist_index_esm/* useForm */.cI)({
        defaultValues: {
            name: sprint.name,
            duration: sprint.duration ?? DEFAULT_DURATION,
            startDate: sprint.startDate ? new Date(sprint.startDate) : new Date(),
            endDate: sprint.endDate ? new Date(sprint.endDate) : new Date(),
            description: sprint.description ?? ""
        }
    });
    const { updateSprint, isUpdating } = (0,use_sprints/* useSprints */.D)();
    const [isAuthenticated, openAuthModal] = (0,use_is_authed/* useIsAuthenticated */.k)();
    const queryClient = (0,QueryClientProvider.useQueryClient)();
    function handleStartSprint(data) {
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        updateSprint({
            sprintId: sprint.id,
            status: "ACTIVE",
            name: data.name,
            duration: data.duration ?? DEFAULT_DURATION,
            description: data.description,
            startDate: data.startDate.toISOString(),
            endDate: data.endDate.toISOString()
        }, {
            onSuccess: ()=>{
                // eslint-disable-next-line
                queryClient.invalidateQueries([
                    "issues"
                ]);
                handleClose();
            }
        });
    }
    function handleClose() {
        reset();
        setModalIsOpen(false);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
        // eslint-disable-next-line
        onSubmit: handleSubmit(handleStartSprint),
        className: "relative h-full",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(NameField, {
                register: register,
                errors: errors
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(DurationField, {
                control: control,
                errors: errors
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(StartDateField, {
                register: register,
                errors: errors,
                control: control
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(EndDateField, {
                register: register,
                errors: errors,
                duration: watch("duration"),
                startDate: watch("startDate"),
                setValue: setValue
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(DescriptionField, {
                register: register
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(FormSubmit, {
                submitText: "Start",
                ariaLabel: "Start sprint",
                onCancel: handleClose,
                isLoading: isUpdating
            })
        ]
    });
};


;// CONCATENATED MODULE: ./components/modals/start-sprint/index.tsx
/* __next_internal_client_entry_do_not_use__ StartSprintModal auto */ 



const StartSprintModal = ({ children, issueCount, sprint })=>{
    const [isOpen, setIsOpen] = (0,react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(modal/* Modal */.u_, {
        open: isOpen,
        onOpenChange: setIsOpen,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(modal/* ModalTrigger */.iq, {
                asChild: true,
                children: children
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(modal/* ModalPortal */.Hv, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(modal/* ModalOverlay */.ZA, {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(modal/* ModalContent */.hz, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(modal/* ModalTitle */.r6, {
                                children: "Start Sprint"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(modal/* ModalDescription */.k, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-bold text-gray-600",
                                        children: issueCount
                                    }),
                                    issueCount > 1 ? " issues" : " issue",
                                    " will be included in this sprint."
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(StartSprintForm, {
                                sprint: sprint,
                                setModalIsOpen: setIsOpen
                            })
                        ]
                    })
                ]
            })
        ]
    });
};


;// CONCATENATED MODULE: ./components/modals/complete-sprint/form/fields/sprint-dropdown.tsx








const SprintDropdownField = ({ control, errors })=>{
    const { sprints } = (0,use_sprints/* useSprints */.D)();
    const backlog = {
        id: "backlog",
        name: "Backlog",
        status: "PENDING"
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "my-5",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Label, {
                htmlFor: "duration",
                text: "Move open issues to",
                required: false
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(dist_index_esm/* Controller */.Qr, {
                control: control,
                name: "moveToSprintId",
                render: ({ field })=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_select/* Select */.Ph, {
                        onValueChange: field.onChange,
                        defaultValue: field.value,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_select/* SelectTrigger */.i4, {
                                className: "flex h-10 w-full max-w-full items-center justify-between overflow-hidden whitespace-nowrap rounded-[3px] bg-gray-100 px-2 text-xs font-semibold transition-all duration-200 hover:bg-gray-200 focus:ring-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectValue */.ki, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectIcon */.GV, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* FaChevronDown */.RiI, {
                                            className: "text-gray-500"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectPortal */.ue, {
                                className: "z-50",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectContent */.Bw, {
                                    position: "popper",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectViewport */.Q_, {
                                        className: "w-96 min-w-fit rounded-md border border-gray-300 bg-white py-2 shadow-md",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectGroup */.DI, {
                                            children: sprints && [
                                                ...sprints,
                                                backlog
                                            ]?.filter((sprint)=>sprint.status === "PENDING")?.map((sprint)=>/*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectItem */.Ql, {
                                                    value: sprint.id,
                                                    className: clsx_default()("border-l-2 border-transparent py-2 pl-3 text-sm hover:cursor-default hover:border-inprogress hover:bg-gray-100 [&[data-state=checked]]:border-inprogress [&[data-state=checked]]:bg-blue-100 [&[data-state=checked]]:text-blue-600"),
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: clsx_default()("px-2 text-xs"),
                                                        children: sprint.name
                                                    })
                                                }, sprint.id))
                                        })
                                    })
                                })
                            })
                        ]
                    });
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(error_Error, {
                trigger: errors.moveToSprintId,
                message: "New sprint is required"
            })
        ]
    });
};


// EXTERNAL MODULE: ./utils/helpers.ts
var helpers = __webpack_require__(89602);
;// CONCATENATED MODULE: ./components/modals/complete-sprint/form/index.tsx








const CompleteSprintForm = ({ sprint, setModalIsOpen, issues })=>{
    const { handleSubmit, formState: { errors }, control, reset } = (0,dist_index_esm/* useForm */.cI)({
        defaultValues: {
            moveToSprintId: "backlog"
        }
    });
    const { updateSprint, isUpdating } = (0,use_sprints/* useSprints */.D)();
    const [isAuthenticated, openAuthModal] = (0,use_is_authed/* useIsAuthenticated */.k)();
    const { updateIssuesBatch, batchUpdating } = (0,use_issues/* useIssues */.g)();
    function handleCompleteSprint(data) {
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        updateSprint({
            sprintId: sprint.id,
            status: "CLOSED"
        }, {
            onSuccess: ()=>{
                handleClose();
            }
        });
        updateIssuesBatch({
            ids: issues?.filter((issue)=>!(0,helpers/* isDone */._b)(issue)).map((issue)=>issue.id) ?? [],
            sprintId: data.moveToSprintId === "backlog" ? null : data.moveToSprintId
        });
    }
    function handleClose() {
        reset();
        setModalIsOpen(false);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
        // eslint-disable-next-line
        onSubmit: handleSubmit(handleCompleteSprint),
        className: "relative h-full",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(SprintDropdownField, {
                control: control,
                errors: errors
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(FormSubmit, {
                submitText: "Complete",
                ariaLabel: "Complete sprint",
                onCancel: handleClose,
                isLoading: isUpdating || batchUpdating
            })
        ]
    });
};


// EXTERNAL MODULE: ./components/svgs.tsx
var svgs = __webpack_require__(16206);
;// CONCATENATED MODULE: ./components/modals/complete-sprint/index.tsx
/* __next_internal_client_entry_do_not_use__ CompleteSprintModal auto */ 




const CompleteSprintModal = ({ children, issues, sprint })=>{
    const [isOpen, setIsOpen] = (0,react_.useState)(false);
    const completedIssues = issues.filter((issue)=>issue.status === "DONE");
    const openIssues = issues.filter((issue)=>issue.status !== "DONE");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(modal/* Modal */.u_, {
        open: isOpen,
        onOpenChange: setIsOpen,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(modal/* ModalTrigger */.iq, {
                asChild: true,
                children: children
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(modal/* ModalPortal */.Hv, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(modal/* ModalOverlay */.ZA, {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(modal/* ModalContent */.hz, {
                        className: "max-w-[540px]",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(svgs/* SprintTrophy */.SW, {
                                className: "-m-8 mb-8",
                                size: 540
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(modal/* ModalTitle */.r6, {
                                children: [
                                    "Complete ",
                                    sprint.name
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(modal/* ModalDescription */.k, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-gray-600",
                                        children: "This sprint contains:"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "ml-6 mt-2 list-disc text-sm text-gray-900",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: "font-bold",
                                                        children: [
                                                            completedIssues.length,
                                                            " "
                                                        ]
                                                    }),
                                                    "completed issues"
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: "font-bold",
                                                        children: [
                                                            openIssues.length,
                                                            " "
                                                        ]
                                                    }),
                                                    "open issues"
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(CompleteSprintForm, {
                                sprint: sprint,
                                setModalIsOpen: setIsOpen,
                                issues: issues
                            })
                        ]
                    })
                ]
            })
        ]
    });
};


;// CONCATENATED MODULE: ./components/modals/update-sprint/form/fields/name.tsx




const name_NameField = ({ errors, register })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "my-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Label, {
                htmlFor: "name",
                text: "Sprint Name"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                ...register("name", {
                    required: true
                }),
                "aria-invalid": errors.name ? "true" : "false",
                type: "text",
                id: "name",
                className: clsx_default()(errors.name ? "focus:outline-red-500" : "focus:outline-blue-400", "block h-10 w-64 rounded-[3px] border border-gray-300 px-2 text-sm shadow-sm outline-2 ring-0 transition-all duration-75")
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(error_Error, {
                trigger: errors.name,
                message: "Sprint name is required"
            })
        ]
    });
};


;// CONCATENATED MODULE: ./components/modals/update-sprint/form/fields/duration.tsx








const duration_DurationField = ({ control, errors })=>{
    const durationOptions = [
        "1 week",
        "2 weeks",
        "3 weeks",
        "4 weeks",
        "custom"
    ];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Label, {
                htmlFor: "duration",
                text: "Duration"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(dist_index_esm/* Controller */.Qr, {
                control: control,
                name: "duration",
                render: ({ field })=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_select/* Select */.Ph, {
                        onValueChange: field.onChange,
                        defaultValue: field.value,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_select/* SelectTrigger */.i4, {
                                className: "flex h-10 w-64 items-center justify-between rounded-[3px] bg-gray-100 px-2 text-xs font-semibold transition-all duration-200 hover:bg-gray-200 focus:ring-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectValue */.ki, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectIcon */.GV, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* FaChevronDown */.RiI, {
                                            className: "text-gray-500"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectPortal */.ue, {
                                className: "z-50",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectContent */.Bw, {
                                    position: "popper",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectViewport */.Q_, {
                                        className: "w-64 rounded-md border border-gray-300 bg-white py-2 shadow-md",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectGroup */.DI, {
                                            children: durationOptions.map((option)=>/*#__PURE__*/ jsx_runtime_.jsx(ui_select/* SelectItem */.Ql, {
                                                    value: option,
                                                    className: clsx_default()("border-l-2 border-transparent py-2 pl-3 text-sm hover:cursor-default hover:border-inprogress hover:bg-gray-100 [&[data-state=checked]]:border-inprogress [&[data-state=checked]]:bg-blue-100 [&[data-state=checked]]:text-blue-600"),
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: clsx_default()("px-2 text-xs"),
                                                        children: option
                                                    })
                                                }, option))
                                        })
                                    })
                                })
                            })
                        ]
                    });
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(error_Error, {
                trigger: errors.duration,
                message: "Duration is required"
            })
        ]
    });
};


;// CONCATENATED MODULE: ./components/modals/update-sprint/form/fields/start-date.tsx






const start_date_StartDateField = ({ errors, register, control })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "my-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Label, {
                htmlFor: "startDate",
                text: "Start Date"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(dist_index_esm/* Controller */.Qr, {
                control: control,
                name: "startDate",
                render: ({ field: { value, onChange } })=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                htmlFor: "startDate",
                                className: "sr-only",
                                children: "Sprint start date picker"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                ...register("startDate", {
                                    required: true,
                                    valueAsDate: true
                                }),
                                "aria-invalid": errors.startDate ? "true" : "false",
                                type: "date",
                                value: value.toISOString().slice(0, 10),
                                onChange: (e)=>onChange(new Date(e.target.value)),
                                id: "startDate",
                                className: clsx_default()(errors.startDate ? "focus:outline-red-500" : "focus:outline-blue-400", "block h-10 w-64 rounded-[3px] border border-gray-300 px-2 text-sm shadow-sm outline-2 transition-all duration-75")
                            })
                        ]
                    });
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(error_Error, {
                trigger: errors.startDate,
                message: "Start date is required"
            })
        ]
    });
};


;// CONCATENATED MODULE: ./components/modals/update-sprint/form/fields/end-date.tsx






const end_date_EndDateField = ({ errors, register, duration, startDate, setValue })=>{
    const [endDate, setEndDate] = (0,react_.useState)(()=>new Date());
    const calculateEndDate = (0,react_.useCallback)((duration, startDate)=>{
        if (duration === "custom") return;
        const milliseconds = calculateMillisecondsFromDuration(duration ?? form_DEFAULT_DURATION);
        const _startDate = new Date(startDate ?? new Date());
        const _endDate = new Date(_startDate.getTime() + milliseconds);
        setEndDate(_endDate);
        setValue("endDate", _endDate);
    }, [
        setValue
    ]);
    (0,react_.useEffect)(()=>{
        calculateEndDate(duration, startDate);
    }, [
        duration,
        startDate,
        calculateEndDate
    ]);
    function calculateMillisecondsFromDuration(duration) {
        if (!duration || duration === "custom") return 0;
        const numberOfWeeks = parseInt(duration.split(" ")[0]);
        return numberOfWeeks * 7 * 24 * 60 * 60 * 1000;
    }
    function validateEndDate() {
        if (!endDate) return false;
        return new Date(startDate) <= new Date(endDate);
    }
    function handleCustomChange(event) {
        if (!event.target.value) return;
        const newDate = new Date(event.target.value);
        setEndDate(newDate);
        setValue("endDate", newDate);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "my-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Label, {
                htmlFor: "endDate",
                text: "End Date"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                ...register("endDate", {
                    required: duration === "custom" ? true : false,
                    valueAsDate: true,
                    validate: {
                        startDateBeforeEndDate: ()=>validateEndDate()
                    }
                }),
                "aria-invalid": errors.endDate ? "true" : "false",
                type: "date",
                disabled: duration !== "custom",
                value: endDate.toISOString().slice(0, 10),
                onChange: handleCustomChange,
                id: "endDate",
                className: clsx_default()(duration === "custom" ? "" : "bg-gray-200 opacity-50", errors.endDate ? "focus:outline-red-500" : "focus:outline-blue-400", "block h-10 w-64 rounded-[3px] border border-gray-300 px-2 text-sm shadow-sm outline-2 transition-all duration-75")
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(error_Error, {
                trigger: errors.endDate,
                message: "The end date of a sprint must be after the start date."
            })
        ]
    });
};


;// CONCATENATED MODULE: ./components/modals/update-sprint/form/fields/description.tsx


const description_DescriptionField = ({ register })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "my-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Label, {
                htmlFor: "description",
                text: "Sprint Goal",
                required: false
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                ...register("description"),
                id: "description",
                className: "block h-32 w-[500px] rounded-[3px] border border-gray-300 p-2 text-sm shadow-sm outline-2 transition-all duration-75 focus:outline-blue-400"
            })
        ]
    });
};


;// CONCATENATED MODULE: ./components/modals/update-sprint/form/index.tsx
/* __next_internal_client_entry_do_not_use__ DEFAULT_DURATION,UpdateSprintForm auto */ 










const form_DEFAULT_DURATION = "1 week";
const UpdateSprintForm = ({ sprint, setModalIsOpen })=>{
    const { handleSubmit, register, formState: { errors }, control, setValue, reset, watch } = (0,dist_index_esm/* useForm */.cI)({
        defaultValues: {
            name: sprint.name,
            duration: sprint.duration ?? form_DEFAULT_DURATION,
            startDate: sprint.startDate ? new Date(sprint.startDate) : new Date(),
            endDate: sprint.endDate ? new Date(sprint.endDate) : new Date(),
            description: sprint.description ?? ""
        }
    });
    const { updateSprint, isUpdating } = (0,use_sprints/* useSprints */.D)();
    const [isAuthenticated, openAuthModal] = (0,use_is_authed/* useIsAuthenticated */.k)();
    const queryClient = (0,QueryClientProvider.useQueryClient)();
    function handleStartSprint(data) {
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        updateSprint({
            sprintId: sprint.id,
            name: data.name,
            duration: data.duration ?? form_DEFAULT_DURATION,
            description: data.description,
            startDate: data.startDate.toISOString(),
            endDate: data.endDate.toISOString()
        }, {
            onSuccess: ()=>{
                // eslint-disable-next-line
                queryClient.invalidateQueries([
                    "issues"
                ]);
                handleClose();
            }
        });
    }
    function handleClose() {
        reset();
        setModalIsOpen(false);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
        // eslint-disable-next-line
        onSubmit: handleSubmit(handleStartSprint),
        className: "relative h-full",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(name_NameField, {
                register: register,
                errors: errors
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(duration_DurationField, {
                control: control,
                errors: errors
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(start_date_StartDateField, {
                register: register,
                errors: errors,
                control: control
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(end_date_EndDateField, {
                register: register,
                errors: errors,
                duration: watch("duration"),
                startDate: watch("startDate"),
                setValue: setValue
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(description_DescriptionField, {
                register: register
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(FormSubmit, {
                submitText: "Update",
                ariaLabel: "Update sprint",
                onCancel: handleClose,
                isLoading: isUpdating
            })
        ]
    });
};


;// CONCATENATED MODULE: ./components/modals/update-sprint/index.tsx
/* __next_internal_client_entry_do_not_use__ UpdateSprintModal auto */ 


const UpdateSprintModal = ({ sprint, isOpen, setIsOpen })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(modal/* Modal */.u_, {
        open: isOpen,
        onOpenChange: setIsOpen,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(modal/* ModalPortal */.Hv, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(modal/* ModalOverlay */.ZA, {}),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(modal/* ModalContent */.hz, {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(modal/* ModalTitle */.r6, {
                            children: [
                                "Edit Sprint: ",
                                sprint.name
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(UpdateSprintForm, {
                            sprint: sprint,
                            setModalIsOpen: setIsOpen
                        })
                    ]
                })
            ]
        })
    });
};


// EXTERNAL MODULE: ./node_modules/@radix-ui/react-alert-dialog/dist/index.mjs + 4 modules
var dist = __webpack_require__(5970);
;// CONCATENATED MODULE: ./components/ui/alert-modal.tsx




const ModalTrigger = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Trigger */.xz, {
        ref: forwardedRef,
        className: clsx_default()("", className),
        ...props,
        children: children
    }));
ModalTrigger.displayName = "ModalTrigger";
const ModalContent = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Content */.VY, {
        className: clsx_default()("fixed left-1/2 top-20 z-50 -translate-x-1/2 rounded-[3px] bg-white p-8  shadow-md", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ModalContent.displayName = "ModalContent";
const ModalPortal = ({ children, className, ...props })=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Portal */.h_, {
        className: clsx_default()("", className),
        ...props,
        children: children
    });
ModalPortal.displayName = "ModalPortal";
const ModalOverlay = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Overlay */.aV, {
        className: clsx_default()("fixed inset-0 z-50 bg-black bg-opacity-40", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ModalOverlay.displayName = "ModalOverlay";
const ModalTitle = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Title */.Dx, {
        className: clsx_default()("text-2xl", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ModalTitle.displayName = "ModalTitle";
const ModalDescription = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Description */.dk, {
        className: clsx_default()("text-sm text-gray-500", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ModalDescription.displayName = "ModalDescription";
const ModalCancel = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Cancel */.$j, {
        className: clsx_default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ModalCancel.displayName = "ModalCancel";
const ModalAction = /*#__PURE__*/ react_default().forwardRef(({ children, className, ...props }, forwardedRef)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Action */.aU, {
        className: clsx_default()("", className),
        ...props,
        ref: forwardedRef,
        children: children
    }));
ModalAction.displayName = "ModalAction";
const Modal = dist/* Root */.fC;


// EXTERNAL MODULE: ./node_modules/react-icons/io5/index.esm.js
var io5_index_esm = __webpack_require__(45489);
;// CONCATENATED MODULE: ./components/modals/alert/index.tsx




const AlertModal = ({ title, description, actionText, onAction, isOpen, setIsOpen })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(Modal, {
        open: isOpen,
        onOpenChange: setIsOpen,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ModalPortal, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(ModalOverlay, {}),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ModalContent, {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex items-center gap-x-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(io5_index_esm/* IoWarning */.OvZ, {
                                    className: "text-xl text-red-600"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(ModalTitle, {
                                    children: title
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(ModalDescription, {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(BoldDescription, {
                                description: description
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-5 flex items-center justify-end gap-x-3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                    customColors: true,
                                    className: "bg-red-600 text-white hover:bg-red-700",
                                    onClick: onAction,
                                    children: actionText
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(ModalCancel, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                        customColors: true,
                                        className: "transition-all duration-150 hover:bg-gray-200",
                                        children: "Cancel"
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
const BoldDescription = ({ description })=>{
    const parts = description.split("BOLD");
    return /*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: "text-gray-700",
        children: parts.map((part, index)=>{
            if (index % 2 === 1) {
                // This part should be bold
                return /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                    children: part
                }, index);
            } else {
                // This part should not be bold
                return part;
            }
        })
    });
};


// EXTERNAL MODULE: ./components/toast.tsx
var toast = __webpack_require__(34825);
;// CONCATENATED MODULE: ./components/backlog/list-sprint.tsx
/* __next_internal_client_entry_do_not_use__ SprintList auto */ 


















const SprintList = ({ sprint, issues })=>{
    const [openAccordion, setOpenAccordion] = (0,react_.useState)("");
    (0,react_.useEffect)(()=>{
        setOpenAccordion(sprint.id); // Open accordion on mount in order for DND to work.
    }, [
        sprint.id
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(accordion/* Accordion */.UQ, {
        onValueChange: setOpenAccordion,
        value: openAccordion,
        className: "overflow-hidden rounded-lg bg-gray-100 p-2",
        type: "single",
        collapsible: true,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(accordion/* AccordionItem */.Qd, {
            value: sprint.id,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(SprintListHeader, {
                    sprint: sprint,
                    issues: issues
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(IssueList, {
                    sprintId: sprint.id,
                    issues: issues
                })
            ]
        })
    });
};
const SprintListHeader = ({ issues, sprint })=>{
    const [updateModalIsOpen, setUpdateModalIsOpen] = (0,react_.useState)(false);
    const [deleteModalIsOpen, setDeleteModalIsOpen] = (0,react_.useState)(false);
    const queryClient = (0,QueryClientProvider.useQueryClient)();
    const [isAuthenticated, openAuthModal] = (0,use_is_authed/* useIsAuthenticated */.k)();
    const { deleteSprint } = (0,use_sprints/* useSprints */.D)();
    function handleDeleteSprint() {
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        deleteSprint({
            sprintId: sprint.id
        }, {
            onSuccess: ()=>{
                // eslint-disable-next-line @typescript-eslint/no-floating-promises
                queryClient.invalidateQueries([
                    "issues"
                ]);
                toast.toast.success({
                    message: `Deleted sprint ${sprint.name}`,
                    description: "Sprint deleted"
                });
                setDeleteModalIsOpen(false);
            },
            onError: ()=>{
                toast.toast.error({
                    message: `Failed to delete sprint ${sprint.name}`,
                    description: "Something went wrong"
                });
            }
        });
    }
    function getFormattedDateRange(startDate, endDate) {
        if (!startDate || !endDate) {
            return "";
        }
        return `${new Date(startDate).toLocaleDateString("en", {
            day: "numeric",
            month: "short"
        })} - ${new Date(endDate).toLocaleDateString("en", {
            day: "numeric",
            month: "short"
        })}`;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(UpdateSprintModal, {
                isOpen: updateModalIsOpen,
                setIsOpen: setUpdateModalIsOpen,
                sprint: sprint
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(AlertModal, {
                isOpen: deleteModalIsOpen,
                setIsOpen: setDeleteModalIsOpen,
                title: "Delete sprint",
                description: `Are you sure you want to delete sprint BOLD${sprint.name}BOLD?`,
                actionText: "Delete",
                onAction: handleDeleteSprint
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex w-full min-w-max items-center justify-between pl-2 text-sm",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(accordion/* AccordionTrigger */.o4, {
                        className: "flex w-full items-center font-medium [&[data-state=open]>svg]:rotate-90",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* FaChevronRight */.Dli, {
                                    className: "mr-2 text-xs text-black transition-transform",
                                    "aria-hidden": true
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex items-center gap-x-2",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-semibold whitespace-nowrap",
                                            children: sprint.name
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex items-center gap-x-3 whitespace-nowrap font-normal text-gray-500",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: getFormattedDateRange(sprint.startDate, sprint.endDate)
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    children: [
                                                        "(",
                                                        issues.length,
                                                        " issue",
                                                        (0,helpers/* getPluralEnd */.ks)(issues),
                                                        ")"
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center gap-x-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(issue_status_count/* IssueStatusCount */._, {
                                issues: issues
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(SprintActionButton, {
                                sprint: sprint,
                                issues: issues
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(SprintDropdownMenu, {
                                setUpdateModalIsOpen: setUpdateModalIsOpen,
                                setDeleteModalIsOpen: setDeleteModalIsOpen,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu/* DropdownTrigger */.WA, {
                                    asChild: true,
                                    className: "rounded-m flex items-center gap-x-1 px-1.5 py-0.5 text-xs font-semibold focus:ring-2",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "rounded-sm bg-gray-200 px-1.5 py-1.5 text-gray-600 hover:cursor-pointer hover:bg-gray-300 [&[data-state=open]]:bg-gray-700 [&[data-state=open]]:text-white",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(bs_index_esm/* BsThreeDots */.evw, {
                                            className: "sm:text-xl"
                                        })
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
const SprintActionButton = ({ sprint, issues })=>{
    if (sprint.status === "ACTIVE") {
        return /*#__PURE__*/ jsx_runtime_.jsx(CompleteSprintModal, {
            issues: issues,
            sprint: sprint,
            children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "whitespace-nowrap",
                    children: "Complete sprint"
                })
            })
        });
    }
    if (sprint.status === "PENDING") {
        return /*#__PURE__*/ jsx_runtime_.jsx(StartSprintModal, {
            issueCount: issues.length,
            sprint: sprint,
            children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "whitespace-nowrap",
                    children: "Start sprint"
                })
            })
        });
    }
    return null;
};


// EXTERNAL MODULE: ./context/use-filters-context.tsx
var use_filters_context = __webpack_require__(57165);
;// CONCATENATED MODULE: ./components/backlog/list-group.tsx
/* __next_internal_client_entry_do_not_use__ ListGroup auto */ 










const ListGroup = ({ className })=>{
    const { issues, updateIssue } = (0,use_issues/* useIssues */.g)();
    const [isAuthenticated, openAuthModal] = (0,use_is_authed/* useIsAuthenticated */.k)();
    const { search, assignees, issueTypes, epics } = (0,use_filters_context/* useFiltersContext */.P)();
    const { sprints } = (0,use_sprints/* useSprints */.D)();
    const filterIssues = (0,react_.useCallback)((issues, sprintId)=>{
        if (!issues) return [];
        const filteredIssues = issues.filter((issue)=>{
            if (issue.sprintId === sprintId && !(0,helpers/* isEpic */.pQ)(issue) && !(0,helpers/* isSubtask */.UU)(issue)) {
                if ((0,helpers/* issueNotInSearch */.Po)({
                    issue,
                    search
                })) return false;
                if ((0,helpers/* assigneeNotInFilters */.tf)({
                    issue,
                    assignees
                })) return false;
                if ((0,helpers/* epicNotInFilters */.rg)({
                    issue,
                    epics
                })) return false;
                if ((0,helpers/* issueTypeNotInFilters */.x2)({
                    issue,
                    issueTypes
                })) return false;
                return true;
            }
            return false;
        });
        return filteredIssues;
    }, [
        search,
        assignees,
        epics,
        issueTypes
    ]);
    const onDragEnd = (result)=>{
        if (!isAuthenticated) {
            openAuthModal();
            return;
        }
        const { destination, source } = result;
        if ((0,helpers/* isNullish */.Rw)(destination) || (0,helpers/* isNullish */.Rw)(source)) return;
        updateIssue({
            issueId: result.draggableId,
            sprintId: (0,helpers/* sprintId */.I0)(destination.droppableId),
            sprintPosition: calculateIssueSprintPosition({
                activeIssues: issues ?? [],
                destination,
                source,
                droppedIssueId: result.draggableId
            })
        });
    };
    if (!sprints) return /*#__PURE__*/ jsx_runtime_.jsx("div", {});
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: clsx_default()("min-h-full w-full max-w-full overflow-y-auto", className),
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_beautiful_dnd_cjs/* DragDropContext */.Z5, {
            onDragEnd: onDragEnd,
            children: [
                sprints.map((sprint)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "my-3",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SprintList, {
                            sprint: sprint,
                            issues: filterIssues(issues, sprint.id)
                        })
                    }, sprint.id)),
                /*#__PURE__*/ jsx_runtime_.jsx(BacklogList, {
                    id: "backlog",
                    issues: filterIssues(issues, null)
                })
            ]
        })
    });
};
function calculateIssueSprintPosition(props) {
    const { prevIssue, nextIssue } = getAfterDropPrevNextIssue(props);
    let position;
    if ((0,helpers/* isNullish */.Rw)(prevIssue) && (0,helpers/* isNullish */.Rw)(nextIssue)) {
        position = 1;
    } else if ((0,helpers/* isNullish */.Rw)(prevIssue) && nextIssue) {
        position = nextIssue.sprintPosition - 1;
    } else if ((0,helpers/* isNullish */.Rw)(nextIssue) && prevIssue) {
        position = prevIssue.sprintPosition + 1;
    } else if (prevIssue && nextIssue) {
        position = prevIssue.sprintPosition + (nextIssue.sprintPosition - prevIssue.sprintPosition) / 2;
    } else {
        throw new Error("Invalid position");
    }
    return position;
}
function getAfterDropPrevNextIssue(props) {
    const { activeIssues, destination, source, droppedIssueId } = props;
    const beforeDropDestinationIssues = getSortedSprintIssues({
        activeIssues,
        sprintId: destination.droppableId
    });
    const droppedIssue = activeIssues.find((issue)=>issue.id === droppedIssueId);
    if (!droppedIssue) {
        throw new Error("dropped issue not found");
    }
    const isSameList = destination.droppableId === source.droppableId;
    const afterDropDestinationIssues = isSameList ? (0,helpers/* moveItemWithinArray */.F3)(beforeDropDestinationIssues, droppedIssue, destination.index) : (0,helpers/* insertItemIntoArray */.eV)(beforeDropDestinationIssues, droppedIssue, destination.index);
    return {
        prevIssue: afterDropDestinationIssues[destination.index - 1],
        nextIssue: afterDropDestinationIssues[destination.index + 1]
    };
}
function getSortedSprintIssues({ activeIssues, sprintId }) {
    return activeIssues.filter((issue)=>issue.sprintId === sprintId).sort((a, b)=>a.sprintPosition - b.sprintPosition);
}
ListGroup.displayName = "ListGroup";


// EXTERNAL MODULE: ./components/issue/issue-details/index.tsx + 22 modules
var issue_details = __webpack_require__(37151);
// EXTERNAL MODULE: ./context/use-selected-issue-context.tsx
var use_selected_issue_context = __webpack_require__(90779);
// EXTERNAL MODULE: ./styles/split.css
var split = __webpack_require__(19746);
// EXTERNAL MODULE: ./components/filter-epic.tsx
var filter_epic = __webpack_require__(16077);
// EXTERNAL MODULE: ./components/filter-issue-type.tsx
var filter_issue_type = __webpack_require__(36665);
// EXTERNAL MODULE: ./components/filter-search-bar.tsx + 1 modules
var filter_search_bar = __webpack_require__(35608);
// EXTERNAL MODULE: ./components/members.tsx
var members = __webpack_require__(5801);
// EXTERNAL MODULE: ./components/filter-issue-clear.tsx
var filter_issue_clear = __webpack_require__(55403);
// EXTERNAL MODULE: ./components/not-implemented.tsx + 1 modules
var not_implemented = __webpack_require__(14782);
// EXTERNAL MODULE: ./node_modules/react-icons/bi/index.esm.js
var bi_index_esm = __webpack_require__(85228);
;// CONCATENATED MODULE: ./components/backlog/header.tsx
/* __next_internal_client_entry_do_not_use__ BacklogHeader auto */ 










const BacklogHeader = ({ project })=>{
    const { search, setSearch } = (0,use_filters_context/* useFiltersContext */.P)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex h-fit flex-col",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "text-sm text-gray-500",
                children: [
                    "Projects / ",
                    project.name
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                children: "Backlog "
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "my-3 flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center gap-x-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(filter_search_bar/* SearchBar */.E, {
                                search: search,
                                setSearch: setSearch
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(members/* Members */.i, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(filter_epic/* EpicFilter */.M, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(filter_issue_type/* IssueTypeFilter */.k, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(filter_issue_clear/* ClearFilters */.B, {})
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(not_implemented/* NotImplemented */.r, {
                        feature: "insights",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                            className: "flex items-center gap-x-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(bi_index_esm/* BiLineChart */.ok1, {
                                    className: "text-gray-900"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-sm text-gray-900",
                                    children: "Insights"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};


// EXTERNAL MODULE: ./hooks/query-hooks/use-project.ts
var use_project = __webpack_require__(5663);
;// CONCATENATED MODULE: ./components/backlog/index.tsx
/* __next_internal_client_entry_do_not_use__ Backlog auto */ 









const Backlog = ()=>{
    const { project } = (0,use_project/* useProject */.P)();
    const { issueKey, setIssueKey } = (0,use_selected_issue_context.useSelectedIssueContext)();
    const renderContainerRef = react_default().useRef(null);
    (0,react_.useLayoutEffect)(()=>{
        if (!renderContainerRef.current) return;
        const calculatedHeight = renderContainerRef.current.offsetTop;
        renderContainerRef.current.style.height = `calc(100vh - ${calculatedHeight}px)`;
    }, []);
    if (!project) return null;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(BacklogHeader, {
                project: project
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                ref: renderContainerRef,
                className: "min-w-full max-w-max",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((react_split_default()), {
                    sizes: issueKey ? [
                        60,
                        40
                    ] : [
                        100,
                        0
                    ],
                    gutterSize: issueKey ? 2 : 0,
                    className: "flex max-h-full w-full",
                    minSize: issueKey ? 400 : 0,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(ListGroup, {
                            className: clsx_default()(issueKey && "pb-5 pr-4")
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(issue_details/* IssueDetails */.G, {
                            setIssueKey: setIssueKey,
                            issueKey: issueKey
                        })
                    ]
                })
            })
        ]
    });
};



/***/ }),

/***/ 45938:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7431);
/* harmony import */ var _context_use_selected_issue_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(74960);



const BacklogLayout = ({ children })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_container__WEBPACK_IMPORTED_MODULE_1__/* .Container */ .W, {
        className: "h-full",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
            className: "w-full",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context_use_selected_issue_context__WEBPACK_IMPORTED_MODULE_2__/* .SelectedIssueProvider */ .V, {
                children: children
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BacklogLayout);


/***/ }),

/***/ 19179:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_skeletons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57042);


const BacklogSkeleton = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        role: "status",
        className: "flex animate-pulse flex-col gap-y-4",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_skeletons__WEBPACK_IMPORTED_MODULE_1__/* .BreadCrumbSkeleton */ .St, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_skeletons__WEBPACK_IMPORTED_MODULE_1__/* .TitleSkeleton */ .Li, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_skeletons__WEBPACK_IMPORTED_MODULE_1__/* .SprintSearchSkeleton */ .UL, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_skeletons__WEBPACK_IMPORTED_MODULE_1__/* .SprintHeaderSkeleton */ .Xg, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mt-3 flex flex-col gap-y-4 px-8",
                children: [
                    ...Array(10).keys()
                ].map((el, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_skeletons__WEBPACK_IMPORTED_MODULE_1__/* .IssueSkeleton */ .Kl, {
                        size: index % 2 === 0 ? 300 : 400
                    }, index))
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "sr-only",
                children: "Loading..."
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BacklogSkeleton);


/***/ }),

/***/ 10864:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7431);


const BacklogErrorPage = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_container__WEBPACK_IMPORTED_MODULE_1__/* .Container */ .W, {
        screen: true,
        children: "Project Not Found"
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BacklogErrorPage);


/***/ }),

/***/ 67876:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./components/backlog/index.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/home/vagrant/agent/workspace/jira_clone_PR-1/components/backlog/index.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["Backlog"];

// EXTERNAL MODULE: ./utils/get-query-client.tsx
var get_query_client = __webpack_require__(77615);
// EXTERNAL MODULE: ./node_modules/@tanstack/query-core/build/lib/hydration.mjs
var hydration = __webpack_require__(12874);
// EXTERNAL MODULE: ./utils/hydrate.tsx
var hydrate = __webpack_require__(85517);
// EXTERNAL MODULE: ./node_modules/@clerk/nextjs/dist/esm/index.js + 17 modules
var esm = __webpack_require__(36886);
// EXTERNAL MODULE: ./server/functions.ts + 1 modules
var functions = __webpack_require__(84305);
;// CONCATENATED MODULE: ./app/project/backlog/page.tsx







const metadata = {
    title: "Backlog"
};
const BacklogPage = async ()=>{
    const user = await (0,esm/* currentUser */.ar)();
    const queryClient = (0,get_query_client/* getQueryClient */.g)();
    await Promise.all([
        await queryClient.prefetchQuery([
            "issues"
        ], ()=>(0,functions/* getInitialIssuesFromServer */.Xp)(user?.id)),
        await queryClient.prefetchQuery([
            "sprints"
        ], ()=>(0,functions/* getInitialSprintsFromServer */.hq)(user?.id)),
        await queryClient.prefetchQuery([
            "project"
        ], functions/* getInitialProjectFromServer */.v1)
    ]);
    const dehydratedState = (0,hydration/* dehydrate */.D)(queryClient);
    return /*#__PURE__*/ jsx_runtime_.jsx(hydrate/* Hydrate */.p, {
        state: dehydratedState,
        children: /*#__PURE__*/ jsx_runtime_.jsx(e0, {})
    });
};
/* harmony default export */ const page = (BacklogPage);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [870,188,57,906,669,569,210,950,886,518,926,673,952,725,688,533,316], () => (__webpack_exec__(15869)));
module.exports = __webpack_exports__;

})();