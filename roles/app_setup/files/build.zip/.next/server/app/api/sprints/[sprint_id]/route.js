"use strict";
(() => {
var exports = {};
exports.id = 269;
exports.ids = [269];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 97783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 28530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 14300:
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 72254:
/***/ ((module) => {

module.exports = require("node:buffer");

/***/ }),

/***/ 6005:
/***/ ((module) => {

module.exports = require("node:crypto");

/***/ }),

/***/ 87561:
/***/ ((module) => {

module.exports = require("node:fs");

/***/ }),

/***/ 88849:
/***/ ((module) => {

module.exports = require("node:http");

/***/ }),

/***/ 22286:
/***/ ((module) => {

module.exports = require("node:https");

/***/ }),

/***/ 87503:
/***/ ((module) => {

module.exports = require("node:net");

/***/ }),

/***/ 49411:
/***/ ((module) => {

module.exports = require("node:path");

/***/ }),

/***/ 97742:
/***/ ((module) => {

module.exports = require("node:process");

/***/ }),

/***/ 84492:
/***/ ((module) => {

module.exports = require("node:stream");

/***/ }),

/***/ 72477:
/***/ ((module) => {

module.exports = require("node:stream/web");

/***/ }),

/***/ 41041:
/***/ ((module) => {

module.exports = require("node:url");

/***/ }),

/***/ 47261:
/***/ ((module) => {

module.exports = require("node:util");

/***/ }),

/***/ 65628:
/***/ ((module) => {

module.exports = require("node:zlib");

/***/ }),

/***/ 77282:
/***/ ((module) => {

module.exports = require("process");

/***/ }),

/***/ 71267:
/***/ ((module) => {

module.exports = require("worker_threads");

/***/ }),

/***/ 74581:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  headerHooks: () => (/* binding */ headerHooks),
  originalPathname: () => (/* binding */ originalPathname),
  requestAsyncStorage: () => (/* binding */ requestAsyncStorage),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage),
  staticGenerationBailout: () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./app/api/sprints/[sprint_id]/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  DELETE: () => (DELETE),
  PATCH: () => (PATCH)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(35387);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(29267);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(32413);
// EXTERNAL MODULE: ./server/db.ts + 1 modules
var db = __webpack_require__(84952);
// EXTERNAL MODULE: external "@prisma/client"
var client_ = __webpack_require__(53524);
// EXTERNAL MODULE: ./node_modules/zod/lib/index.mjs
var lib = __webpack_require__(83445);
// EXTERNAL MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/createGetAuth.js
var createGetAuth = __webpack_require__(14669);
;// CONCATENATED MODULE: ./app/api/sprints/[sprint_id]/route.ts





const patchSprintBodyValidator = lib.z.object({
    name: lib.z.string().optional(),
    description: lib.z.string().optional(),
    duration: lib.z.string().optional(),
    startDate: lib.z.string().optional(),
    endDate: lib.z.string().optional(),
    status: lib.z.nativeEnum(client_.SprintStatus).optional()
});
async function PATCH(req, { params }) {
    const { userId } = (0,createGetAuth/* getAuth */.v0)(req);
    if (!userId) return new Response("Unauthenticated request", {
        status: 403
    });
    const { success } = await db/* ratelimit */.$.limit(userId);
    if (!success) return new Response("Too many requests", {
        status: 429
    });
    const { sprint_id } = params;
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    const body = await req.json();
    const validated = patchSprintBodyValidator.safeParse(body);
    if (!validated.success) {
        const message = "Invalid body. " + (validated.error.errors[0]?.message ?? "");
        return new Response(message, {
            status: 400
        });
    }
    const { data: valid } = validated;
    const current = await db/* prisma */._.sprint.findUnique({
        where: {
            id: sprint_id
        }
    });
    if (!current) {
        return new Response("Sprint not found", {
            status: 404
        });
    }
    const sprint = await db/* prisma */._.sprint.update({
        where: {
            id: sprint_id
        },
        data: {
            name: valid.name ?? current.name,
            description: valid.description ?? current.description,
            startDate: valid.startDate ?? current.startDate,
            endDate: valid.endDate ?? current.endDate,
            status: valid.status ?? current.status,
            duration: valid.duration ?? current.duration
        }
    });
    // return NextResponse.json<PatchSprintResponse>({ sprint });
    return next_response/* default */.Z.json({
        sprint
    });
}
async function DELETE(req, { params }) {
    const { userId } = (0,createGetAuth/* getAuth */.v0)(req);
    if (!userId) return new Response("Unauthenticated request", {
        status: 403
    });
    const { success } = await db/* ratelimit */.$.limit(userId);
    if (!success) return new Response("Too many requests", {
        status: 429
    });
    const { sprint_id } = params;
    await db/* prisma */._.issue.updateMany({
        where: {
            sprintId: sprint_id
        },
        data: {
            sprintId: null
        }
    });
    const sprint = await db/* prisma */._.sprint.delete({
        where: {
            id: sprint_id
        }
    });
    // return NextResponse.json<PatchSprintResponse>({ sprint });
    return next_response/* default */.Z.json({
        sprint
    });
}

;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fsprints%2F%5Bsprint_id%5D%2Froute&name=app%2Fapi%2Fsprints%2F%5Bsprint_id%5D%2Froute&pagePath=private-next-app-dir%2Fapi%2Fsprints%2F%5Bsprint_id%5D%2Froute.ts&appDir=%2Fhome%2Fvagrant%2Fagent%2Fworkspace%2Fjira_clone_PR-1%2Fapp&appPaths=%2Fapi%2Fsprints%2F%5Bsprint_id%5D%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&preferredRegion=&middlewareConfig=e30%3D!

    

    

    

    const options = {"definition":{"kind":"APP_ROUTE","page":"/api/sprints/[sprint_id]/route","pathname":"/api/sprints/[sprint_id]","filename":"route","bundlePath":"app/api/sprints/[sprint_id]/route"},"resolvedPagePath":"/home/vagrant/agent/workspace/jira_clone_PR-1/app/api/sprints/[sprint_id]/route.ts","nextConfigOutput":"standalone"}
    const routeModule = new (module_default())({
      ...options,
      userland: route_namespaceObject,
    })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/sprints/[sprint_id]/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [870,188,57,906,981,669,952], () => (__webpack_exec__(74581)));
module.exports = __webpack_exports__;

})();