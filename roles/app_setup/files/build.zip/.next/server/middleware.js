// runtime can't be in strict mode because a global variable is assign and maybe created.
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[826],{

/***/ 513:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ next_middleware_loaderabsolutePagePath_private_next_root_dir_2Fmiddleware_ts_page_2Fmiddleware_rootDir_2Fhome_2Fvagrant_2Fagent_2Fworkspace_2Fjira_clone_PR_1_matchers_preferredRegion_middlewareConfig_e30_3D_)
});

// NAMESPACE OBJECT: ./node_modules/@clerk/backend/dist/runtime/browser/fetch.mjs
var fetch_namespaceObject = {};
__webpack_require__.r(fetch_namespaceObject);
__webpack_require__.d(fetch_namespaceObject, {
  RuntimeAbortController: () => (RuntimeAbortController),
  RuntimeBlob: () => (RuntimeBlob),
  RuntimeFetch: () => (RuntimeFetch),
  RuntimeFormData: () => (RuntimeFormData),
  RuntimeHeaders: () => (RuntimeHeaders),
  RuntimeRequest: () => (RuntimeRequest),
  RuntimeResponse: () => (RuntimeResponse)
});

// NAMESPACE OBJECT: ./middleware.ts
var middleware_namespaceObject = {};
__webpack_require__.r(middleware_namespaceObject);
__webpack_require__.d(middleware_namespaceObject, {
  "default": () => (middleware)
});

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/server/web/globals.js
async function registerInstrumentation() {
    if ("_ENTRIES" in globalThis && _ENTRIES.middleware_instrumentation && _ENTRIES.middleware_instrumentation.register) {
        try {
            await _ENTRIES.middleware_instrumentation.register();
        } catch (err) {
            err.message = `An error occurred while loading instrumentation hook: ${err.message}`;
            throw err;
        }
    }
}
let registerInstrumentationPromise = null;
function ensureInstrumentationRegistered() {
    if (!registerInstrumentationPromise) {
        registerInstrumentationPromise = registerInstrumentation();
    }
    return registerInstrumentationPromise;
}
function getUnsupportedModuleErrorMessage(module) {
    // warning: if you change these messages, you must adjust how react-dev-overlay's middleware detects modules not found
    return `The edge runtime does not support Node.js '${module}' module.
Learn More: https://nextjs.org/docs/messages/node-module-in-edge-runtime`;
}
function __import_unsupported(moduleName) {
    const proxy = new Proxy(function() {}, {
        get (_obj, prop) {
            if (prop === "then") {
                return {};
            }
            throw new Error(getUnsupportedModuleErrorMessage(moduleName));
        },
        construct () {
            throw new Error(getUnsupportedModuleErrorMessage(moduleName));
        },
        apply (_target, _this, args) {
            if (typeof args[0] === "function") {
                return args[0](proxy);
            }
            throw new Error(getUnsupportedModuleErrorMessage(moduleName));
        }
    });
    return new Proxy({}, {
        get: ()=>proxy
    });
}
function enhanceGlobals() {
    // The condition is true when the "process" module is provided
    if (process !== __webpack_require__.g.process) {
        // prefer local process but global.process has correct "env"
        process.env = __webpack_require__.g.process.env;
        __webpack_require__.g.process = process;
    }
    // to allow building code that import but does not use node.js modules,
    // webpack will expect this function to exist in global scope
    Object.defineProperty(globalThis, "__import_unsupported", {
        value: __import_unsupported,
        enumerable: false,
        configurable: false
    });
    // Eagerly fire instrumentation hook to make the startup faster.
    void ensureInstrumentationRegistered();
}
enhanceGlobals(); //# sourceMappingURL=globals.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/server/web/error.js
class PageSignatureError extends Error {
    constructor({ page }){
        super(`The middleware "${page}" accepts an async API directly with the form:
  
  export function middleware(request, event) {
    return NextResponse.redirect('/new-location')
  }
  
  Read more: https://nextjs.org/docs/messages/middleware-new-signature
  `);
    }
}
class RemovedPageError extends Error {
    constructor(){
        super(`The request.page has been deprecated in favour of \`URLPattern\`.
  Read more: https://nextjs.org/docs/messages/middleware-request-page
  `);
    }
}
class RemovedUAError extends Error {
    constructor(){
        super(`The request.ua has been removed in favour of \`userAgent\` function.
  Read more: https://nextjs.org/docs/messages/middleware-parse-user-agent
  `);
    }
} //# sourceMappingURL=error.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/server/web/utils.js
/**
 * Converts a Node.js IncomingHttpHeaders object to a Headers object. Any
 * headers with multiple values will be joined with a comma and space. Any
 * headers that have an undefined value will be ignored and others will be
 * coerced to strings.
 *
 * @param nodeHeaders the headers object to convert
 * @returns the converted headers object
 */ function fromNodeOutgoingHttpHeaders(nodeHeaders) {
    const headers = new Headers();
    for (let [key, value] of Object.entries(nodeHeaders)){
        const values = Array.isArray(value) ? value : [
            value
        ];
        for (let v of values){
            if (typeof v === "undefined") continue;
            if (typeof v === "number") {
                v = v.toString();
            }
            headers.append(key, v);
        }
    }
    return headers;
}
/*
  Set-Cookie header field-values are sometimes comma joined in one string. This splits them without choking on commas
  that are within a single set-cookie field-value, such as in the Expires portion.
  This is uncommon, but explicitly allowed - see https://tools.ietf.org/html/rfc2616#section-4.2
  Node.js does this for every header *except* set-cookie - see https://github.com/nodejs/node/blob/d5e363b77ebaf1caf67cd7528224b651c86815c1/lib/_http_incoming.js#L128
  React Native's fetch does this for *every* header, including set-cookie.
  
  Based on: https://github.com/google/j2objc/commit/16820fdbc8f76ca0c33472810ce0cb03d20efe25
  Credits to: https://github.com/tomball for original and https://github.com/chrusart for JavaScript implementation
*/ function splitCookiesString(cookiesString) {
    var cookiesStrings = [];
    var pos = 0;
    var start;
    var ch;
    var lastComma;
    var nextStart;
    var cookiesSeparatorFound;
    function skipWhitespace() {
        while(pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))){
            pos += 1;
        }
        return pos < cookiesString.length;
    }
    function notSpecialChar() {
        ch = cookiesString.charAt(pos);
        return ch !== "=" && ch !== ";" && ch !== ",";
    }
    while(pos < cookiesString.length){
        start = pos;
        cookiesSeparatorFound = false;
        while(skipWhitespace()){
            ch = cookiesString.charAt(pos);
            if (ch === ",") {
                // ',' is a cookie separator if we have later first '=', not ';' or ','
                lastComma = pos;
                pos += 1;
                skipWhitespace();
                nextStart = pos;
                while(pos < cookiesString.length && notSpecialChar()){
                    pos += 1;
                }
                // currently special character
                if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
                    // we found cookies separator
                    cookiesSeparatorFound = true;
                    // pos is inside the next cookie, so back up and return it.
                    pos = nextStart;
                    cookiesStrings.push(cookiesString.substring(start, lastComma));
                    start = pos;
                } else {
                    // in param ',' or param separator ';',
                    // we continue from that comma
                    pos = lastComma + 1;
                }
            } else {
                pos += 1;
            }
        }
        if (!cookiesSeparatorFound || pos >= cookiesString.length) {
            cookiesStrings.push(cookiesString.substring(start, cookiesString.length));
        }
    }
    return cookiesStrings;
}
/**
 * Converts a Headers object to a Node.js OutgoingHttpHeaders object. This is
 * required to support the set-cookie header, which may have multiple values.
 *
 * @param headers the headers object to convert
 * @returns the converted headers object
 */ function toNodeOutgoingHttpHeaders(headers) {
    const nodeHeaders = {};
    const cookies = [];
    if (headers) {
        for (const [key, value] of headers.entries()){
            if (key.toLowerCase() === "set-cookie") {
                // We may have gotten a comma joined string of cookies, or multiple
                // set-cookie headers. We need to merge them into one header array
                // to represent all the cookies.
                cookies.push(...splitCookiesString(value));
                nodeHeaders[key] = cookies.length === 1 ? cookies[0] : cookies;
            } else {
                nodeHeaders[key] = value;
            }
        }
    }
    return nodeHeaders;
}
/**
 * Validate the correctness of a user-provided URL.
 */ function validateURL(url) {
    try {
        return String(new URL(String(url)));
    } catch (error) {
        throw new Error(`URL is malformed "${String(url)}". Please use only absolute URLs - https://nextjs.org/docs/messages/middleware-relative-urls`, {
            cause: error
        });
    }
} //# sourceMappingURL=utils.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/server/web/spec-extension/fetch-event.js

const responseSymbol = Symbol("response");
const passThroughSymbol = Symbol("passThrough");
const waitUntilSymbol = Symbol("waitUntil");
class FetchEvent {
    // eslint-disable-next-line @typescript-eslint/no-useless-constructor
    constructor(_request){
        this[waitUntilSymbol] = [];
        this[passThroughSymbol] = false;
    }
    respondWith(response) {
        if (!this[responseSymbol]) {
            this[responseSymbol] = Promise.resolve(response);
        }
    }
    passThroughOnException() {
        this[passThroughSymbol] = true;
    }
    waitUntil(promise) {
        this[waitUntilSymbol].push(promise);
    }
}
class NextFetchEvent extends FetchEvent {
    constructor(params){
        super(params.request);
        this.sourcePage = params.page;
    }
    /**
   * @deprecated The `request` is now the first parameter and the API is now async.
   *
   * Read more: https://nextjs.org/docs/messages/middleware-new-signature
   */ get request() {
        throw new PageSignatureError({
            page: this.sourcePage
        });
    }
    /**
   * @deprecated Using `respondWith` is no longer needed.
   *
   * Read more: https://nextjs.org/docs/messages/middleware-new-signature
   */ respondWith() {
        throw new PageSignatureError({
            page: this.sourcePage
        });
    }
} //# sourceMappingURL=fetch-event.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/shared/lib/i18n/detect-domain-locale.js
function detectDomainLocale(domainItems, hostname, detectedLocale) {
    if (!domainItems) return;
    if (detectedLocale) {
        detectedLocale = detectedLocale.toLowerCase();
    }
    for (const item of domainItems){
        var _item_domain, _item_locales;
        // remove port if present
        const domainHostname = (_item_domain = item.domain) == null ? void 0 : _item_domain.split(":")[0].toLowerCase();
        if (hostname === domainHostname || detectedLocale === item.defaultLocale.toLowerCase() || ((_item_locales = item.locales) == null ? void 0 : _item_locales.some((locale)=>locale.toLowerCase() === detectedLocale))) {
            return item;
        }
    }
} //# sourceMappingURL=detect-domain-locale.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/shared/lib/router/utils/remove-trailing-slash.js
/**
 * Removes the trailing slash for a given route or page path. Preserves the
 * root page. Examples:
 *   - `/foo/bar/` -> `/foo/bar`
 *   - `/foo/bar` -> `/foo/bar`
 *   - `/` -> `/`
 */ function removeTrailingSlash(route) {
    return route.replace(/\/$/, "") || "/";
} //# sourceMappingURL=remove-trailing-slash.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/shared/lib/router/utils/parse-path.js
/**
 * Given a path this function will find the pathname, query and hash and return
 * them. This is useful to parse full paths on the client side.
 * @param path A path to parse e.g. /foo/bar?id=1#hash
 */ function parsePath(path) {
    const hashIndex = path.indexOf("#");
    const queryIndex = path.indexOf("?");
    const hasQuery = queryIndex > -1 && (hashIndex < 0 || queryIndex < hashIndex);
    if (hasQuery || hashIndex > -1) {
        return {
            pathname: path.substring(0, hasQuery ? queryIndex : hashIndex),
            query: hasQuery ? path.substring(queryIndex, hashIndex > -1 ? hashIndex : undefined) : "",
            hash: hashIndex > -1 ? path.slice(hashIndex) : ""
        };
    }
    return {
        pathname: path,
        query: "",
        hash: ""
    };
} //# sourceMappingURL=parse-path.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/shared/lib/router/utils/add-path-prefix.js

/**
 * Adds the provided prefix to the given path. It first ensures that the path
 * is indeed starting with a slash.
 */ function addPathPrefix(path, prefix) {
    if (!path.startsWith("/") || !prefix) {
        return path;
    }
    const { pathname, query, hash } = parsePath(path);
    return "" + prefix + pathname + query + hash;
} //# sourceMappingURL=add-path-prefix.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/shared/lib/router/utils/add-path-suffix.js

/**
 * Similarly to `addPathPrefix`, this function adds a suffix at the end on the
 * provided path. It also works only for paths ensuring the argument starts
 * with a slash.
 */ function addPathSuffix(path, suffix) {
    if (!path.startsWith("/") || !suffix) {
        return path;
    }
    const { pathname, query, hash } = parsePath(path);
    return "" + pathname + suffix + query + hash;
} //# sourceMappingURL=add-path-suffix.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/shared/lib/router/utils/path-has-prefix.js

/**
 * Checks if a given path starts with a given prefix. It ensures it matches
 * exactly without containing extra chars. e.g. prefix /docs should replace
 * for /docs, /docs/, /docs/a but not /docsss
 * @param path The path to check.
 * @param prefix The prefix to check against.
 */ function pathHasPrefix(path, prefix) {
    if (typeof path !== "string") {
        return false;
    }
    const { pathname } = parsePath(path);
    return pathname === prefix || pathname.startsWith(prefix + "/");
} //# sourceMappingURL=path-has-prefix.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/shared/lib/router/utils/add-locale.js


/**
 * For a given path and a locale, if the locale is given, it will prefix the
 * locale. The path shouldn't be an API path. If a default locale is given the
 * prefix will be omitted if the locale is already the default locale.
 */ function addLocale(path, locale, defaultLocale, ignorePrefix) {
    // If no locale was given or the locale is the default locale, we don't need
    // to prefix the path.
    if (!locale || locale === defaultLocale) return path;
    const lower = path.toLowerCase();
    // If the path is an API path or the path already has the locale prefix, we
    // don't need to prefix the path.
    if (!ignorePrefix) {
        if (pathHasPrefix(lower, "/api")) return path;
        if (pathHasPrefix(lower, "/" + locale.toLowerCase())) return path;
    }
    // Add the locale prefix to the path.
    return addPathPrefix(path, "/" + locale);
} //# sourceMappingURL=add-locale.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/shared/lib/router/utils/format-next-pathname-info.js




function formatNextPathnameInfo(info) {
    let pathname = addLocale(info.pathname, info.locale, info.buildId ? undefined : info.defaultLocale, info.ignorePrefix);
    if (info.buildId || !info.trailingSlash) {
        pathname = removeTrailingSlash(pathname);
    }
    if (info.buildId) {
        pathname = addPathSuffix(addPathPrefix(pathname, "/_next/data/" + info.buildId), info.pathname === "/" ? "index.json" : ".json");
    }
    pathname = addPathPrefix(pathname, info.basePath);
    return !info.buildId && info.trailingSlash ? !pathname.endsWith("/") ? addPathSuffix(pathname, "/") : pathname : removeTrailingSlash(pathname);
} //# sourceMappingURL=format-next-pathname-info.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/shared/lib/get-hostname.js
/**
 * Takes an object with a hostname property (like a parsed URL) and some
 * headers that may contain Host and returns the preferred hostname.
 * @param parsed An object containing a hostname property.
 * @param headers A dictionary with headers containing a `host`.
 */ function getHostname(parsed, headers) {
    // Get the hostname from the headers if it exists, otherwise use the parsed
    // hostname.
    let hostname;
    if ((headers == null ? void 0 : headers.host) && !Array.isArray(headers.host)) {
        hostname = headers.host.toString().split(":")[0];
    } else if (parsed.hostname) {
        hostname = parsed.hostname;
    } else return;
    return hostname.toLowerCase();
} //# sourceMappingURL=get-hostname.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/shared/lib/i18n/normalize-locale-path.js
/**
 * For a pathname that may include a locale from a list of locales, it
 * removes the locale from the pathname returning it alongside with the
 * detected locale.
 *
 * @param pathname A pathname that may include a locale.
 * @param locales A list of locales.
 * @returns The detected locale and pathname without locale
 */ function normalizeLocalePath(pathname, locales) {
    let detectedLocale;
    // first item will be empty string from splitting at first char
    const pathnameParts = pathname.split("/");
    (locales || []).some((locale)=>{
        if (pathnameParts[1] && pathnameParts[1].toLowerCase() === locale.toLowerCase()) {
            detectedLocale = locale;
            pathnameParts.splice(1, 1);
            pathname = pathnameParts.join("/") || "/";
            return true;
        }
        return false;
    });
    return {
        pathname,
        detectedLocale
    };
} //# sourceMappingURL=normalize-locale-path.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/shared/lib/router/utils/remove-path-prefix.js

/**
 * Given a path and a prefix it will remove the prefix when it exists in the
 * given path. It ensures it matches exactly without containing extra chars
 * and if the prefix is not there it will be noop.
 *
 * @param path The path to remove the prefix from.
 * @param prefix The prefix to be removed.
 */ function removePathPrefix(path, prefix) {
    // If the path doesn't start with the prefix we can return it as is. This
    // protects us from situations where the prefix is a substring of the path
    // prefix such as:
    //
    // For prefix: /blog
    //
    //   /blog -> true
    //   /blog/ -> true
    //   /blog/1 -> true
    //   /blogging -> false
    //   /blogging/ -> false
    //   /blogging/1 -> false
    if (!pathHasPrefix(path, prefix)) {
        return path;
    }
    // Remove the prefix from the path via slicing.
    const withoutPrefix = path.slice(prefix.length);
    // If the path without the prefix starts with a `/` we can return it as is.
    if (withoutPrefix.startsWith("/")) {
        return withoutPrefix;
    }
    // If the path without the prefix doesn't start with a `/` we need to add it
    // back to the path to make sure it's a valid path.
    return "/" + withoutPrefix;
} //# sourceMappingURL=remove-path-prefix.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/shared/lib/router/utils/get-next-pathname-info.js



function getNextPathnameInfo(pathname, options) {
    var _options_nextConfig;
    const { basePath, i18n, trailingSlash } = (_options_nextConfig = options.nextConfig) != null ? _options_nextConfig : {};
    const info = {
        pathname: pathname,
        trailingSlash: pathname !== "/" ? pathname.endsWith("/") : trailingSlash
    };
    if (basePath && pathHasPrefix(info.pathname, basePath)) {
        info.pathname = removePathPrefix(info.pathname, basePath);
        info.basePath = basePath;
    }
    if (options.parseData === true && info.pathname.startsWith("/_next/data/") && info.pathname.endsWith(".json")) {
        const paths = info.pathname.replace(/^\/_next\/data\//, "").replace(/\.json$/, "").split("/");
        const buildId = paths[0];
        info.pathname = paths[1] !== "index" ? "/" + paths.slice(1).join("/") : "/";
        info.buildId = buildId;
    }
    // If provided, use the locale route normalizer to detect the locale instead
    // of the function below.
    if (options.i18nProvider) {
        const result = options.i18nProvider.analyze(info.pathname);
        info.locale = result.detectedLocale;
        var _result_pathname;
        info.pathname = (_result_pathname = result.pathname) != null ? _result_pathname : info.pathname;
    } else if (i18n) {
        const pathLocale = normalizeLocalePath(info.pathname, i18n.locales);
        info.locale = pathLocale.detectedLocale;
        var _pathLocale_pathname;
        info.pathname = (_pathLocale_pathname = pathLocale.pathname) != null ? _pathLocale_pathname : info.pathname;
    }
    return info;
} //# sourceMappingURL=get-next-pathname-info.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/server/web/next-url.js




const REGEX_LOCALHOST_HOSTNAME = /(?!^https?:\/\/)(127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}|::1|localhost)/;
function parseURL(url, base) {
    return new URL(String(url).replace(REGEX_LOCALHOST_HOSTNAME, "localhost"), base && String(base).replace(REGEX_LOCALHOST_HOSTNAME, "localhost"));
}
const Internal = Symbol("NextURLInternal");
class NextURL {
    constructor(input, baseOrOpts, opts){
        let base;
        let options;
        if (typeof baseOrOpts === "object" && "pathname" in baseOrOpts || typeof baseOrOpts === "string") {
            base = baseOrOpts;
            options = opts || {};
        } else {
            options = opts || baseOrOpts || {};
        }
        this[Internal] = {
            url: parseURL(input, base ?? options.base),
            options: options,
            basePath: ""
        };
        this.analyze();
    }
    analyze() {
        var _this_Internal_options_nextConfig, _this_Internal_options_nextConfig_i18n, _this_Internal_domainLocale, _this_Internal_options_nextConfig1, _this_Internal_options_nextConfig_i18n1;
        const info = getNextPathnameInfo(this[Internal].url.pathname, {
            nextConfig: this[Internal].options.nextConfig,
            parseData: !undefined,
            i18nProvider: this[Internal].options.i18nProvider
        });
        const hostname = getHostname(this[Internal].url, this[Internal].options.headers);
        this[Internal].domainLocale = this[Internal].options.i18nProvider ? this[Internal].options.i18nProvider.detectDomainLocale(hostname) : detectDomainLocale((_this_Internal_options_nextConfig = this[Internal].options.nextConfig) == null ? void 0 : (_this_Internal_options_nextConfig_i18n = _this_Internal_options_nextConfig.i18n) == null ? void 0 : _this_Internal_options_nextConfig_i18n.domains, hostname);
        const defaultLocale = ((_this_Internal_domainLocale = this[Internal].domainLocale) == null ? void 0 : _this_Internal_domainLocale.defaultLocale) || ((_this_Internal_options_nextConfig1 = this[Internal].options.nextConfig) == null ? void 0 : (_this_Internal_options_nextConfig_i18n1 = _this_Internal_options_nextConfig1.i18n) == null ? void 0 : _this_Internal_options_nextConfig_i18n1.defaultLocale);
        this[Internal].url.pathname = info.pathname;
        this[Internal].defaultLocale = defaultLocale;
        this[Internal].basePath = info.basePath ?? "";
        this[Internal].buildId = info.buildId;
        this[Internal].locale = info.locale ?? defaultLocale;
        this[Internal].trailingSlash = info.trailingSlash;
    }
    formatPathname() {
        return formatNextPathnameInfo({
            basePath: this[Internal].basePath,
            buildId: this[Internal].buildId,
            defaultLocale: !this[Internal].options.forceLocale ? this[Internal].defaultLocale : undefined,
            locale: this[Internal].locale,
            pathname: this[Internal].url.pathname,
            trailingSlash: this[Internal].trailingSlash
        });
    }
    formatSearch() {
        return this[Internal].url.search;
    }
    get buildId() {
        return this[Internal].buildId;
    }
    set buildId(buildId) {
        this[Internal].buildId = buildId;
    }
    get locale() {
        return this[Internal].locale ?? "";
    }
    set locale(locale) {
        var _this_Internal_options_nextConfig, _this_Internal_options_nextConfig_i18n;
        if (!this[Internal].locale || !((_this_Internal_options_nextConfig = this[Internal].options.nextConfig) == null ? void 0 : (_this_Internal_options_nextConfig_i18n = _this_Internal_options_nextConfig.i18n) == null ? void 0 : _this_Internal_options_nextConfig_i18n.locales.includes(locale))) {
            throw new TypeError(`The NextURL configuration includes no locale "${locale}"`);
        }
        this[Internal].locale = locale;
    }
    get defaultLocale() {
        return this[Internal].defaultLocale;
    }
    get domainLocale() {
        return this[Internal].domainLocale;
    }
    get searchParams() {
        return this[Internal].url.searchParams;
    }
    get host() {
        return this[Internal].url.host;
    }
    set host(value) {
        this[Internal].url.host = value;
    }
    get hostname() {
        return this[Internal].url.hostname;
    }
    set hostname(value) {
        this[Internal].url.hostname = value;
    }
    get port() {
        return this[Internal].url.port;
    }
    set port(value) {
        this[Internal].url.port = value;
    }
    get protocol() {
        return this[Internal].url.protocol;
    }
    set protocol(value) {
        this[Internal].url.protocol = value;
    }
    get href() {
        const pathname = this.formatPathname();
        const search = this.formatSearch();
        return `${this.protocol}//${this.host}${pathname}${search}${this.hash}`;
    }
    set href(url) {
        this[Internal].url = parseURL(url);
        this.analyze();
    }
    get origin() {
        return this[Internal].url.origin;
    }
    get pathname() {
        return this[Internal].url.pathname;
    }
    set pathname(value) {
        this[Internal].url.pathname = value;
    }
    get hash() {
        return this[Internal].url.hash;
    }
    set hash(value) {
        this[Internal].url.hash = value;
    }
    get search() {
        return this[Internal].url.search;
    }
    set search(value) {
        this[Internal].url.search = value;
    }
    get password() {
        return this[Internal].url.password;
    }
    set password(value) {
        this[Internal].url.password = value;
    }
    get username() {
        return this[Internal].url.username;
    }
    set username(value) {
        this[Internal].url.username = value;
    }
    get basePath() {
        return this[Internal].basePath;
    }
    set basePath(value) {
        this[Internal].basePath = value.startsWith("/") ? value : `/${value}`;
    }
    toString() {
        return this.href;
    }
    toJSON() {
        return this.href;
    }
    [Symbol.for("edge-runtime.inspect.custom")]() {
        return {
            href: this.href,
            origin: this.origin,
            protocol: this.protocol,
            username: this.username,
            password: this.password,
            host: this.host,
            hostname: this.hostname,
            port: this.port,
            pathname: this.pathname,
            search: this.search,
            searchParams: this.searchParams,
            hash: this.hash
        };
    }
    clone() {
        return new NextURL(String(this), this[Internal].options);
    }
} //# sourceMappingURL=next-url.js.map

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@edge-runtime/cookies/index.js
var cookies = __webpack_require__(668);
;// CONCATENATED MODULE: ./node_modules/next/dist/esm/server/web/spec-extension/cookies.js
 //# sourceMappingURL=cookies.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/server/web/spec-extension/request.js




const INTERNALS = Symbol("internal request");
class NextRequest extends Request {
    constructor(input, init = {}){
        const url = typeof input !== "string" && "url" in input ? input.url : String(input);
        validateURL(url);
        super(url, init);
        const nextUrl = new NextURL(url, {
            headers: toNodeOutgoingHttpHeaders(this.headers),
            nextConfig: init.nextConfig
        });
        this[INTERNALS] = {
            cookies: new cookies.RequestCookies(this.headers),
            geo: init.geo || {},
            ip: init.ip,
            nextUrl,
            url:  false ? 0 : nextUrl.toString()
        };
    }
    [Symbol.for("edge-runtime.inspect.custom")]() {
        return {
            cookies: this.cookies,
            geo: this.geo,
            ip: this.ip,
            nextUrl: this.nextUrl,
            url: this.url,
            // rest of props come from Request
            bodyUsed: this.bodyUsed,
            cache: this.cache,
            credentials: this.credentials,
            destination: this.destination,
            headers: Object.fromEntries(this.headers),
            integrity: this.integrity,
            keepalive: this.keepalive,
            method: this.method,
            mode: this.mode,
            redirect: this.redirect,
            referrer: this.referrer,
            referrerPolicy: this.referrerPolicy,
            signal: this.signal
        };
    }
    get cookies() {
        return this[INTERNALS].cookies;
    }
    get geo() {
        return this[INTERNALS].geo;
    }
    get ip() {
        return this[INTERNALS].ip;
    }
    get nextUrl() {
        return this[INTERNALS].nextUrl;
    }
    /**
   * @deprecated
   * `page` has been deprecated in favour of `URLPattern`.
   * Read more: https://nextjs.org/docs/messages/middleware-request-page
   */ get page() {
        throw new RemovedPageError();
    }
    /**
   * @deprecated
   * `ua` has been removed in favour of \`userAgent\` function.
   * Read more: https://nextjs.org/docs/messages/middleware-parse-user-agent
   */ get ua() {
        throw new RemovedUAError();
    }
    get url() {
        return this[INTERNALS].url;
    }
} //# sourceMappingURL=request.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/server/web/spec-extension/response.js



const response_INTERNALS = Symbol("internal response");
const REDIRECTS = new Set([
    301,
    302,
    303,
    307,
    308
]);
function handleMiddlewareField(init, headers) {
    var _init_request;
    if (init == null ? void 0 : (_init_request = init.request) == null ? void 0 : _init_request.headers) {
        if (!(init.request.headers instanceof Headers)) {
            throw new Error("request.headers must be an instance of Headers");
        }
        const keys = [];
        for (const [key, value] of init.request.headers){
            headers.set("x-middleware-request-" + key, value);
            keys.push(key);
        }
        headers.set("x-middleware-override-headers", keys.join(","));
    }
}
class response_NextResponse extends Response {
    constructor(body, init = {}){
        super(body, init);
        this[response_INTERNALS] = {
            cookies: new cookies.ResponseCookies(this.headers),
            url: init.url ? new NextURL(init.url, {
                headers: toNodeOutgoingHttpHeaders(this.headers),
                nextConfig: init.nextConfig
            }) : undefined
        };
    }
    [Symbol.for("edge-runtime.inspect.custom")]() {
        return {
            cookies: this.cookies,
            url: this.url,
            // rest of props come from Response
            body: this.body,
            bodyUsed: this.bodyUsed,
            headers: Object.fromEntries(this.headers),
            ok: this.ok,
            redirected: this.redirected,
            status: this.status,
            statusText: this.statusText,
            type: this.type
        };
    }
    get cookies() {
        return this[response_INTERNALS].cookies;
    }
    static json(body, init) {
        // @ts-expect-error This is not in lib/dom right now, and we can't augment it.
        const response = Response.json(body, init);
        return new response_NextResponse(response.body, response);
    }
    static redirect(url, init) {
        const status = typeof init === "number" ? init : (init == null ? void 0 : init.status) ?? 307;
        if (!REDIRECTS.has(status)) {
            throw new RangeError('Failed to execute "redirect" on "response": Invalid status code');
        }
        const initObj = typeof init === "object" ? init : {};
        const headers = new Headers(initObj == null ? void 0 : initObj.headers);
        headers.set("Location", validateURL(url));
        return new response_NextResponse(null, {
            ...initObj,
            headers,
            status
        });
    }
    static rewrite(destination, init) {
        const headers = new Headers(init == null ? void 0 : init.headers);
        headers.set("x-middleware-rewrite", validateURL(destination));
        handleMiddlewareField(init, headers);
        return new response_NextResponse(null, {
            ...init,
            headers
        });
    }
    static next(init) {
        const headers = new Headers(init == null ? void 0 : init.headers);
        headers.set("x-middleware-next", "1");
        handleMiddlewareField(init, headers);
        return new response_NextResponse(null, {
            ...init,
            headers
        });
    }
} //# sourceMappingURL=response.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/shared/lib/router/utils/relativize-url.js
/**
 * Given a URL as a string and a base URL it will make the URL relative
 * if the parsed protocol and host is the same as the one in the base
 * URL. Otherwise it returns the same URL string.
 */ function relativizeURL(url, base) {
    const baseURL = typeof base === "string" ? new URL(base) : base;
    const relative = new URL(url, base);
    const origin = baseURL.protocol + "//" + baseURL.host;
    return relative.protocol + "//" + relative.host === origin ? relative.toString().replace(origin, "") : relative.toString();
} //# sourceMappingURL=relativize-url.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/client/components/app-router-headers.js
const RSC = "RSC";
const ACTION = "Next-Action";
const NEXT_ROUTER_STATE_TREE = "Next-Router-State-Tree";
const NEXT_ROUTER_PREFETCH = "Next-Router-Prefetch";
const NEXT_URL = "Next-Url";
const FETCH_CACHE_HEADER = "x-vercel-sc-headers";
const RSC_CONTENT_TYPE_HEADER = "text/x-component";
const RSC_VARY_HEADER = RSC + ", " + NEXT_ROUTER_STATE_TREE + ", " + NEXT_ROUTER_PREFETCH;
const FLIGHT_PARAMETERS = [
    [
        RSC
    ],
    [
        NEXT_ROUTER_STATE_TREE
    ],
    [
        NEXT_ROUTER_PREFETCH
    ]
];
const NEXT_RSC_UNION_QUERY = "_rsc"; //# sourceMappingURL=app-router-headers.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/server/internal-utils.js

const INTERNAL_QUERY_NAMES = [
    "__nextFallback",
    "__nextLocale",
    "__nextInferredLocaleFromDefault",
    "__nextDefaultLocale",
    "__nextIsNotFound",
    NEXT_RSC_UNION_QUERY
];
const EDGE_EXTENDED_INTERNAL_QUERY_NAMES = [
    "__nextDataReq"
];
function stripInternalQueries(query) {
    for (const name of INTERNAL_QUERY_NAMES){
        delete query[name];
    }
}
function stripInternalSearchParams(url, isEdge) {
    const isStringUrl = typeof url === "string";
    const instance = isStringUrl ? new URL(url) : url;
    for (const name of INTERNAL_QUERY_NAMES){
        instance.searchParams.delete(name);
    }
    if (isEdge) {
        for (const name of EDGE_EXTENDED_INTERNAL_QUERY_NAMES){
            instance.searchParams.delete(name);
        }
    }
    return isStringUrl ? instance.toString() : instance;
} //# sourceMappingURL=internal-utils.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/shared/lib/router/utils/app-paths.js

/**
 * Normalizes an app route so it represents the actual request path. Essentially
 * performing the following transformations:
 *
 * - `/(dashboard)/user/[id]/page` to `/user/[id]`
 * - `/(dashboard)/account/page` to `/account`
 * - `/user/[id]/page` to `/user/[id]`
 * - `/account/page` to `/account`
 * - `/page` to `/`
 * - `/(dashboard)/user/[id]/route` to `/user/[id]`
 * - `/(dashboard)/account/route` to `/account`
 * - `/user/[id]/route` to `/user/[id]`
 * - `/account/route` to `/account`
 * - `/route` to `/`
 * - `/` to `/`
 *
 * @param route the app route to normalize
 * @returns the normalized pathname
 */ function normalizeAppPath(route) {
    return ensureLeadingSlash(route.split("/").reduce((pathname, segment, index, segments)=>{
        // Empty segments are ignored.
        if (!segment) {
            return pathname;
        }
        // Groups are ignored.
        if (segment.startsWith("(") && segment.endsWith(")")) {
            return pathname;
        }
        // Parallel segments are ignored.
        if (segment.startsWith("@")) {
            return pathname;
        }
        // The last segment (if it's a leaf) should be ignored.
        if ((segment === "page" || segment === "route") && index === segments.length - 1) {
            return pathname;
        }
        return pathname + "/" + segment;
    }, ""));
}
/**
 * Strips the `.rsc` extension if it's in the pathname.
 * Since this function is used on full urls it checks `?` for searchParams handling.
 */ function normalizeRscPath(pathname, enabled) {
    return enabled ? pathname.replace(/\.rsc($|\?)/, "$1") : pathname;
} //# sourceMappingURL=app-paths.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/lib/constants.js
const NEXT_QUERY_PARAM_PREFIX = "nxtP";
const PRERENDER_REVALIDATE_HEADER = "x-prerender-revalidate";
const PRERENDER_REVALIDATE_ONLY_GENERATED_HEADER = "x-prerender-revalidate-if-generated";
// in seconds
const CACHE_ONE_YEAR = 31536000;
// Patterns to detect middleware files
const MIDDLEWARE_FILENAME = "middleware";
const MIDDLEWARE_LOCATION_REGEXP = (/* unused pure expression or super */ null && (`(?:src/)?${MIDDLEWARE_FILENAME}`));
// Pattern to detect instrumentation hooks file
const INSTRUMENTATION_HOOK_FILENAME = "instrumentation";
const INSTRUMENTATION_HOOKS_LOCATION_REGEXP = (/* unused pure expression or super */ null && (`(?:src/)?${INSTRUMENTATION_HOOK_FILENAME}`));
// Because on Windows absolute paths in the generated code can break because of numbers, eg 1 in the path,
// we have to use a private alias
const PAGES_DIR_ALIAS = "private-next-pages";
const DOT_NEXT_ALIAS = "private-dot-next";
const ROOT_DIR_ALIAS = "private-next-root-dir";
const APP_DIR_ALIAS = "private-next-app-dir";
const RSC_MOD_REF_PROXY_ALIAS = "private-next-rsc-mod-ref-proxy";
const RSC_ACTION_VALIDATE_ALIAS = "private-next-rsc-action-validate";
const RSC_ACTION_PROXY_ALIAS = "private-next-rsc-action-proxy";
const RSC_ACTION_CLIENT_WRAPPER_ALIAS = "private-next-rsc-action-client-wrapper";
const PUBLIC_DIR_MIDDLEWARE_CONFLICT = (/* unused pure expression or super */ null && (`You can not have a '_next' folder inside of your public folder. This conflicts with the internal '/_next' route. https://nextjs.org/docs/messages/public-next-folder-conflict`));
const SSG_GET_INITIAL_PROPS_CONFLICT = (/* unused pure expression or super */ null && (`You can not use getInitialProps with getStaticProps. To use SSG, please remove your getInitialProps`));
const SERVER_PROPS_GET_INIT_PROPS_CONFLICT = (/* unused pure expression or super */ null && (`You can not use getInitialProps with getServerSideProps. Please remove getInitialProps.`));
const SERVER_PROPS_SSG_CONFLICT = (/* unused pure expression or super */ null && (`You can not use getStaticProps or getStaticPaths with getServerSideProps. To use SSG, please remove getServerSideProps`));
const STATIC_STATUS_PAGE_GET_INITIAL_PROPS_ERROR = (/* unused pure expression or super */ null && (`can not have getInitialProps/getServerSideProps, https://nextjs.org/docs/messages/404-get-initial-props`));
const SERVER_PROPS_EXPORT_ERROR = (/* unused pure expression or super */ null && (`pages with \`getServerSideProps\` can not be exported. See more info here: https://nextjs.org/docs/messages/gssp-export`));
const GSP_NO_RETURNED_VALUE = "Your `getStaticProps` function did not return an object. Did you forget to add a `return`?";
const GSSP_NO_RETURNED_VALUE = "Your `getServerSideProps` function did not return an object. Did you forget to add a `return`?";
const UNSTABLE_REVALIDATE_RENAME_ERROR = (/* unused pure expression or super */ null && ("The `unstable_revalidate` property is available for general use.\n" + "Please use `revalidate` instead."));
const GSSP_COMPONENT_MEMBER_ERROR = (/* unused pure expression or super */ null && (`can not be attached to a page's component and must be exported from the page. See more info here: https://nextjs.org/docs/messages/gssp-component-member`));
const NON_STANDARD_NODE_ENV = (/* unused pure expression or super */ null && (`You are using a non-standard "NODE_ENV" value in your environment. This creates inconsistencies in the project and is strongly advised against. Read more: https://nextjs.org/docs/messages/non-standard-node-env`));
const SSG_FALLBACK_EXPORT_ERROR = (/* unused pure expression or super */ null && (`Pages with \`fallback\` enabled in \`getStaticPaths\` can not be exported. See more info here: https://nextjs.org/docs/messages/ssg-fallback-true-export`));
// Consolidate this consts when the `appDir` will be stable.
const ESLINT_DEFAULT_DIRS = [
    "pages",
    "components",
    "lib",
    "src"
];
const ESLINT_DEFAULT_DIRS_WITH_APP = [
    "app",
    ...ESLINT_DEFAULT_DIRS
];
const ESLINT_PROMPT_VALUES = [
    {
        title: "Strict",
        recommended: true,
        config: {
            extends: "next/core-web-vitals"
        }
    },
    {
        title: "Base",
        config: {
            extends: "next"
        }
    },
    {
        title: "Cancel",
        config: null
    }
];
const SERVER_RUNTIME = {
    edge: "edge",
    experimentalEdge: "experimental-edge",
    nodejs: "nodejs"
};
const WEBPACK_LAYERS = {
    shared: "sc_shared",
    server: "sc_server",
    client: "sc_client",
    action: "sc_action",
    api: "api",
    middleware: "middleware",
    edgeAsset: "edge-asset",
    appClient: "app-client"
};
const WEBPACK_RESOURCE_QUERIES = {
    edgeSSREntry: "__next_edge_ssr_entry__",
    metadata: "__next_metadata__"
}; //# sourceMappingURL=constants.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/server/web/adapter.js













class NextRequestHint extends NextRequest {
    constructor(params){
        super(params.input, params.init);
        this.sourcePage = params.page;
    }
    get request() {
        throw new PageSignatureError({
            page: this.sourcePage
        });
    }
    respondWith() {
        throw new PageSignatureError({
            page: this.sourcePage
        });
    }
    waitUntil() {
        throw new PageSignatureError({
            page: this.sourcePage
        });
    }
}
const adapter_FLIGHT_PARAMETERS = [
    [
        RSC
    ],
    [
        NEXT_ROUTER_STATE_TREE
    ],
    [
        NEXT_ROUTER_PREFETCH
    ],
    [
        FETCH_CACHE_HEADER
    ]
];
async function adapter(params) {
    await ensureInstrumentationRegistered();
    // TODO-APP: use explicit marker for this
    const isEdgeRendering = typeof self.__BUILD_MANIFEST !== "undefined";
    params.request.url = normalizeRscPath(params.request.url, true);
    const requestUrl = new NextURL(params.request.url, {
        headers: params.request.headers,
        nextConfig: params.request.nextConfig
    });
    // Iterator uses an index to keep track of the current iteration. Because of deleting and appending below we can't just use the iterator.
    // Instead we use the keys before iteration.
    const keys = [
        ...requestUrl.searchParams.keys()
    ];
    for (const key of keys){
        const value = requestUrl.searchParams.getAll(key);
        if (key !== NEXT_QUERY_PARAM_PREFIX && key.startsWith(NEXT_QUERY_PARAM_PREFIX)) {
            const normalizedKey = key.substring(NEXT_QUERY_PARAM_PREFIX.length);
            requestUrl.searchParams.delete(normalizedKey);
            for (const val of value){
                requestUrl.searchParams.append(normalizedKey, val);
            }
            requestUrl.searchParams.delete(key);
        }
    }
    // Ensure users only see page requests, never data requests.
    const buildId = requestUrl.buildId;
    requestUrl.buildId = "";
    const isDataReq = params.request.headers["x-nextjs-data"];
    if (isDataReq && requestUrl.pathname === "/index") {
        requestUrl.pathname = "/";
    }
    const requestHeaders = fromNodeOutgoingHttpHeaders(params.request.headers);
    const flightHeaders = new Map();
    // Parameters should only be stripped for middleware
    if (!isEdgeRendering) {
        for (const param of adapter_FLIGHT_PARAMETERS){
            const key = param.toString().toLowerCase();
            const value = requestHeaders.get(key);
            if (value) {
                flightHeaders.set(key, requestHeaders.get(key));
                requestHeaders.delete(key);
            }
        }
    }
    const normalizeUrl =  false ? 0 : requestUrl;
    const request = new NextRequestHint({
        page: params.page,
        // Strip internal query parameters off the request.
        input: stripInternalSearchParams(normalizeUrl, true).toString(),
        init: {
            body: params.request.body,
            geo: params.request.geo,
            headers: requestHeaders,
            ip: params.request.ip,
            method: params.request.method,
            nextConfig: params.request.nextConfig
        }
    });
    /**
   * This allows to identify the request as a data request. The user doesn't
   * need to know about this property neither use it. We add it for testing
   * purposes.
   */ if (isDataReq) {
        Object.defineProperty(request, "__isData", {
            enumerable: false,
            value: true
        });
    }
    if (!globalThis.__incrementalCache && params.IncrementalCache) {
        globalThis.__incrementalCache = new params.IncrementalCache({
            appDir: true,
            fetchCache: true,
            minimalMode: "production" !== "development",
            fetchCacheKeyPrefix: undefined,
            dev: "production" === "development",
            requestHeaders: params.request.headers,
            requestProtocol: "https",
            getPrerenderManifest: ()=>{
                return {
                    version: -1,
                    routes: {},
                    dynamicRoutes: {},
                    notFoundRoutes: [],
                    preview: {
                        previewModeId: "development-id"
                    }
                };
            }
        });
    }
    const event = new NextFetchEvent({
        request,
        page: params.page
    });
    let response = await params.handler(request, event);
    // check if response is a Response object
    if (response && !(response instanceof Response)) {
        throw new TypeError("Expected an instance of Response to be returned");
    }
    /**
   * For rewrites we must always include the locale in the final pathname
   * so we re-create the NextURL forcing it to include it when the it is
   * an internal rewrite. Also we make sure the outgoing rewrite URL is
   * a data URL if the request was a data request.
   */ const rewrite = response == null ? void 0 : response.headers.get("x-middleware-rewrite");
    if (response && rewrite) {
        const rewriteUrl = new NextURL(rewrite, {
            forceLocale: true,
            headers: params.request.headers,
            nextConfig: params.request.nextConfig
        });
        if (true) {
            if (rewriteUrl.host === request.nextUrl.host) {
                rewriteUrl.buildId = buildId || rewriteUrl.buildId;
                response.headers.set("x-middleware-rewrite", String(rewriteUrl));
            }
        }
        /**
     * When the request is a data request we must show if there was a rewrite
     * with an internal header so the client knows which component to load
     * from the data request.
     */ const relativizedRewrite = relativizeURL(String(rewriteUrl), String(requestUrl));
        if (isDataReq && // if the rewrite is external and external rewrite
        // resolving config is enabled don't add this header
        // so the upstream app can set it instead
        !(undefined && 0)) {
            response.headers.set("x-nextjs-rewrite", relativizedRewrite);
        }
    }
    /**
   * For redirects we will not include the locale in case when it is the
   * default and we must also make sure the outgoing URL is a data one if
   * the incoming request was a data request.
   */ const redirect = response == null ? void 0 : response.headers.get("Location");
    if (response && redirect && !isEdgeRendering) {
        const redirectURL = new NextURL(redirect, {
            forceLocale: false,
            headers: params.request.headers,
            nextConfig: params.request.nextConfig
        });
        /**
     * Responses created from redirects have immutable headers so we have
     * to clone the response to be able to modify it.
     */ response = new Response(response.body, response);
        if (true) {
            if (redirectURL.host === request.nextUrl.host) {
                redirectURL.buildId = buildId || redirectURL.buildId;
                response.headers.set("Location", String(redirectURL));
            }
        }
        /**
     * When the request is a data request we can't use the location header as
     * it may end up with CORS error. Instead we map to an internal header so
     * the client knows the destination.
     */ if (isDataReq) {
            response.headers.delete("Location");
            response.headers.set("x-nextjs-redirect", relativizeURL(String(redirectURL), String(requestUrl)));
        }
    }
    const finalResponse = response ? response : response_NextResponse.next();
    // Flight headers are not overridable / removable so they are applied at the end.
    const middlewareOverrideHeaders = finalResponse.headers.get("x-middleware-override-headers");
    const overwrittenHeaders = [];
    if (middlewareOverrideHeaders) {
        for (const [key, value] of flightHeaders){
            finalResponse.headers.set(`x-middleware-request-${key}`, value);
            overwrittenHeaders.push(key);
        }
        if (overwrittenHeaders.length > 0) {
            finalResponse.headers.set("x-middleware-override-headers", middlewareOverrideHeaders + "," + overwrittenHeaders.join(","));
        }
    }
    return {
        response: finalResponse,
        waitUntil: Promise.all(event[waitUntilSymbol])
    };
} //# sourceMappingURL=adapter.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/chunk-KJVJ4CFF.mjs
// src/utils/runtimeEnvironment.ts
var isDevelopmentEnvironment = ()=>{
    try {
        return "production" === "development";
    } catch (err) {}
    return false;
};
var isTestEnvironment = ()=>{
    try {
        return "production" === "test";
    } catch (err) {}
    return false;
};
var isProductionEnvironment = ()=>{
    try {
        return "production" === "production";
    } catch (err) {}
    return false;
};
// src/deprecated.ts
var displayedWarnings = /* @__PURE__ */ new Set();
var chunk_KJVJ4CFF_deprecated = (fnName, warning, key)=>{
    const hideWarning = isTestEnvironment() || isProductionEnvironment();
    const messageId = key ?? fnName;
    if (displayedWarnings.has(messageId) || hideWarning) {
        return;
    }
    displayedWarnings.add(messageId);
    console.warn(`Clerk - DEPRECATION WARNING: "${fnName}" is deprecated and will be removed in the next major release.
${warning}`);
};
var deprecatedProperty = (cls, propName, warning, isStatic = false)=>{
    const target = isStatic ? cls : cls.prototype;
    let value = target[propName];
    Object.defineProperty(target, propName, {
        get () {
            chunk_KJVJ4CFF_deprecated(propName, warning, `${cls.name}:${propName}`);
            return value;
        },
        set (v) {
            value = v;
        }
    });
};
var deprecatedObjectProperty = (obj, propName, warning, key)=>{
    let value = obj[propName];
    Object.defineProperty(obj, propName, {
        get () {
            chunk_KJVJ4CFF_deprecated(propName, warning, key);
            return value;
        },
        set (v) {
            value = v;
        }
    });
};
 //# sourceMappingURL=chunk-KJVJ4CFF.mjs.map

;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/chunk-NDCDZYN6.mjs
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __reExport = (target, mod, secondTarget)=>(__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
 //# sourceMappingURL=chunk-NDCDZYN6.mjs.map

;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/deprecated.mjs


 //# sourceMappingURL=deprecated.mjs.map

;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/chunk-5E5NNJ3O.mjs
// src/utils/instance.ts
function isStaging(frontendApi) {
    return frontendApi.endsWith(".lclstage.dev") || frontendApi.endsWith(".stgstage.dev") || frontendApi.endsWith(".clerkstage.dev") || frontendApi.endsWith(".accountsstage.dev");
}
// src/url.ts
function parseSearchParams(queryString = "") {
    if (queryString.startsWith("?")) {
        queryString = queryString.slice(1);
    }
    return new URLSearchParams(queryString);
}
function stripScheme(url = "") {
    return (url || "").replace(/^.+:\/\//, "");
}
function addClerkPrefix(str) {
    if (!str) {
        return "";
    }
    let regex;
    if (str.match(/^(clerk\.)+\w*$/)) {
        regex = /(clerk\.)*(?=clerk\.)/;
    } else if (str.match(/\.clerk.accounts/)) {
        return str;
    } else {
        regex = /^(clerk\.)*/gi;
    }
    const stripped = str.replace(regex, "");
    return `clerk.${stripped}`;
}
var getClerkJsMajorVersionOrTag = (frontendApi, pkgVersion)=>{
    if (!pkgVersion && isStaging(frontendApi)) {
        return "canary";
    }
    if (!pkgVersion) {
        return "latest";
    }
    return pkgVersion.split(".")[0] || "latest";
};
var getScriptUrl = (frontendApi, { pkgVersion = "4.68.2", clerkJSVersion })=>{
    const noSchemeFrontendApi = frontendApi.replace(/http(s)?:\/\//, "");
    const major = getClerkJsMajorVersionOrTag(frontendApi, pkgVersion);
    return `https://${noSchemeFrontendApi}/npm/@clerk/clerk-js@${clerkJSVersion || major}/dist/clerk.browser.js`;
};
 //# sourceMappingURL=chunk-5E5NNJ3O.mjs.map

;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/url.mjs


 //# sourceMappingURL=url.mjs.map

;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/chunk-4PW5MDZA.mjs
// src/callWithRetry.ts
function wait(ms) {
    return new Promise((res)=>setTimeout(res, ms));
}
var MAX_NUMBER_OF_RETRIES = 5;
async function callWithRetry(fn, attempt = 1, maxAttempts = MAX_NUMBER_OF_RETRIES) {
    try {
        return await fn();
    } catch (e) {
        if (attempt >= maxAttempts) {
            throw e;
        }
        await wait(2 ** attempt * 100);
        return callWithRetry(fn, attempt + 1, maxAttempts);
    }
}
 //# sourceMappingURL=chunk-4PW5MDZA.mjs.map

;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/callWithRetry.mjs


 //# sourceMappingURL=callWithRetry.mjs.map

;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/chunk-TETGTEI2.mjs
// src/isomorphicAtob.ts
var isomorphicAtob = (data)=>{
    if (typeof atob !== "undefined" && typeof atob === "function") {
        return atob(data);
    } else if (typeof global !== "undefined" && global.Buffer) {
        return new global.Buffer(data, "base64").toString();
    }
    return data;
};
 //# sourceMappingURL=chunk-TETGTEI2.mjs.map

;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/chunk-IAZRYRAH.mjs

// src/keys.ts
var PUBLISHABLE_KEY_LIVE_PREFIX = "pk_live_";
var PUBLISHABLE_KEY_TEST_PREFIX = "pk_test_";
var PUBLISHABLE_FRONTEND_API_DEV_REGEX = /^(([a-z]+)-){2}([0-9]{1,2})\.clerk\.accounts([a-z.]*)(dev|com)$/i;
function buildPublishableKey(frontendApi) {
    const keyPrefix = PUBLISHABLE_FRONTEND_API_DEV_REGEX.test(frontendApi) ? PUBLISHABLE_KEY_TEST_PREFIX : PUBLISHABLE_KEY_LIVE_PREFIX;
    return `${keyPrefix}${btoa(`${frontendApi}$`)}`;
}
function chunk_IAZRYRAH_parsePublishableKey(key) {
    key = key || "";
    if (!isPublishableKey(key)) {
        return null;
    }
    const instanceType = key.startsWith(PUBLISHABLE_KEY_LIVE_PREFIX) ? "production" : "development";
    let frontendApi = isomorphicAtob(key.split("_")[2]);
    if (!frontendApi.endsWith("$")) {
        return null;
    }
    frontendApi = frontendApi.slice(0, -1);
    return {
        instanceType,
        frontendApi
    };
}
function isPublishableKey(key) {
    key = key || "";
    const hasValidPrefix = key.startsWith(PUBLISHABLE_KEY_LIVE_PREFIX) || key.startsWith(PUBLISHABLE_KEY_TEST_PREFIX);
    const hasValidFrontendApiPostfix = isomorphicAtob(key.split("_")[2] || "").endsWith("$");
    return hasValidPrefix && hasValidFrontendApiPostfix;
}
function isLegacyFrontendApiKey(key) {
    key = key || "";
    return key.startsWith("clerk.");
}
function createDevOrStagingUrlCache() {
    const DEV_OR_STAGING_SUFFIXES = [
        ".lcl.dev",
        ".stg.dev",
        ".lclstage.dev",
        ".stgstage.dev",
        ".dev.lclclerk.com",
        ".stg.lclclerk.com",
        ".accounts.lclclerk.com",
        "accountsstage.dev",
        "accounts.dev"
    ];
    const devOrStagingUrlCache = /* @__PURE__ */ new Map();
    return {
        isDevOrStagingUrl: (url)=>{
            if (!url) {
                return false;
            }
            const hostname = typeof url === "string" ? url : url.hostname;
            let res = devOrStagingUrlCache.get(hostname);
            if (res === void 0) {
                res = DEV_OR_STAGING_SUFFIXES.some((s)=>hostname.endsWith(s));
                devOrStagingUrlCache.set(hostname, res);
            }
            return res;
        }
    };
}
function isDevelopmentFromApiKey(apiKey) {
    return apiKey.startsWith("test_") || apiKey.startsWith("sk_test_");
}
function isProductionFromApiKey(apiKey) {
    return apiKey.startsWith("live_") || apiKey.startsWith("sk_live_");
}
 //# sourceMappingURL=chunk-IAZRYRAH.mjs.map

;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/keys.mjs



 //# sourceMappingURL=keys.mjs.map

;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/chunk-5DRMPUGE.mjs

// src/error.ts
function isUnauthorizedError(e) {
    const status = e?.status;
    const code = e?.errors?.[0]?.code;
    return code === "authentication_invalid" && status === 401;
}
function is4xxError(e) {
    const status = e?.status;
    return !!status && status >= 400 && status < 500;
}
function isNetworkError(e) {
    const message = (`${e.message}${e.name}` || "").toLowerCase().replace(/\s+/g, "");
    return message.includes("networkerror");
}
function isKnownError(error) {
    return isClerkAPIResponseError(error) || isMetamaskError(error) || isClerkRuntimeError(error);
}
function isClerkAPIResponseError(err) {
    return "clerkError" in err;
}
function isClerkRuntimeError(err) {
    return "clerkRuntimeError" in err;
}
function isMetamaskError(err) {
    return "code" in err && [
        4001,
        32602,
        32603
    ].includes(err.code) && "message" in err;
}
function isUserLockedError(err) {
    return isClerkAPIResponseError(err) && err.errors?.[0]?.code === "user_locked";
}
function parseErrors(data = []) {
    return data.length > 0 ? data.map(parseError) : [];
}
function parseError(error) {
    return {
        code: error.code,
        message: error.message,
        longMessage: error.long_message,
        meta: {
            paramName: error?.meta?.param_name,
            sessionId: error?.meta?.session_id,
            emailAddresses: error?.meta?.email_addresses,
            identifiers: error?.meta?.identifiers,
            zxcvbn: error?.meta?.zxcvbn
        }
    };
}
var ClerkAPIResponseError = class _ClerkAPIResponseError extends Error {
    constructor(message, { data, status, clerkTraceId }){
        super(message);
        this.toString = ()=>{
            let message = `[${this.name}]
Message:${this.message}
Status:${this.status}
Serialized errors: ${this.errors.map((e)=>JSON.stringify(e))}`;
            if (this.clerkTraceId) {
                message += `
Clerk Trace ID: ${this.clerkTraceId}`;
            }
            return message;
        };
        Object.setPrototypeOf(this, _ClerkAPIResponseError.prototype);
        this.status = status;
        this.message = message;
        this.clerkTraceId = clerkTraceId;
        this.clerkError = true;
        this.errors = parseErrors(data);
    }
};
var ClerkRuntimeError = class _ClerkRuntimeError extends (/* unused pure expression or super */ null && (Error)) {
    constructor(message, { code }){
        super(message);
        /**
     * Returns a string representation of the error.
     *
     * @returns {string} A formatted string with the error name and message.
     * @memberof ClerkRuntimeError
     */ this.toString = ()=>{
            return `[${this.name}]
Message:${this.message}`;
        };
        Object.setPrototypeOf(this, _ClerkRuntimeError.prototype);
        this.code = code;
        this.message = message;
        this.clerkRuntimeError = true;
    }
};
var MagicLinkError = class _MagicLinkError extends (/* unused pure expression or super */ null && (Error)) {
    constructor(code){
        super(code);
        this.code = code;
        Object.setPrototypeOf(this, _MagicLinkError.prototype);
        deprecated("MagicLinkError", "Use `EmailLinkError` instead.");
    }
};
var EmailLinkError = class _EmailLinkError extends (/* unused pure expression or super */ null && (Error)) {
    constructor(code){
        super(code);
        this.code = code;
        Object.setPrototypeOf(this, _EmailLinkError.prototype);
    }
};
function isMagicLinkError(err) {
    deprecated("isMagicLinkError", "Use `isEmailLinkError` instead.");
    return err instanceof MagicLinkError;
}
function isEmailLinkError(err) {
    return err instanceof EmailLinkError;
}
var _MagicLinkErrorCode = {
    Expired: "expired",
    Failed: "failed"
};
var MagicLinkErrorCode = new Proxy(_MagicLinkErrorCode, {
    get (target, prop, receiver) {
        chunk_KJVJ4CFF_deprecated("MagicLinkErrorCode", "Use `EmailLinkErrorCode` instead.");
        return Reflect.get(target, prop, receiver);
    }
});
var EmailLinkErrorCode = {
    Expired: "expired",
    Failed: "failed"
};
var DefaultMessages = Object.freeze({
    InvalidFrontendApiErrorMessage: `The frontendApi passed to Clerk is invalid. You can get your Frontend API key at https://dashboard.clerk.com/last-active?path=api-keys. (key={{key}})`,
    InvalidProxyUrlErrorMessage: `The proxyUrl passed to Clerk is invalid. The expected value for proxyUrl is an absolute URL or a relative path with a leading '/'. (key={{url}})`,
    InvalidPublishableKeyErrorMessage: `The publishableKey passed to Clerk is invalid. You can get your Publishable key at https://dashboard.clerk.com/last-active?path=api-keys. (key={{key}})`,
    MissingPublishableKeyErrorMessage: `Missing publishableKey. You can get your key at https://dashboard.clerk.com/last-active?path=api-keys.`
});
function buildErrorThrower({ packageName, customMessages }) {
    let pkg = packageName;
    const messages = {
        ...DefaultMessages,
        ...customMessages
    };
    function buildMessage(rawMessage, replacements) {
        if (!replacements) {
            return `${pkg}: ${rawMessage}`;
        }
        let msg = rawMessage;
        const matches = rawMessage.matchAll(/{{([a-zA-Z0-9-_]+)}}/g);
        for (const match of matches){
            const replacement = (replacements[match[1]] || "").toString();
            msg = msg.replace(`{{${match[1]}}}`, replacement);
        }
        return `${pkg}: ${msg}`;
    }
    return {
        setPackageName ({ packageName: packageName2 }) {
            if (typeof packageName2 === "string") {
                pkg = packageName2;
            }
            return this;
        },
        setMessages ({ customMessages: customMessages2 }) {
            Object.assign(messages, customMessages2 || {});
            return this;
        },
        throwInvalidPublishableKeyError (params) {
            throw new Error(buildMessage(messages.InvalidPublishableKeyErrorMessage, params));
        },
        throwInvalidFrontendApiError (params) {
            throw new Error(buildMessage(messages.InvalidFrontendApiErrorMessage, params));
        },
        throwInvalidProxyUrl (params) {
            throw new Error(buildMessage(messages.InvalidProxyUrlErrorMessage, params));
        },
        throwMissingPublishableKeyError () {
            throw new Error(buildMessage(messages.MissingPublishableKeyErrorMessage));
        }
    };
}
 //# sourceMappingURL=chunk-5DRMPUGE.mjs.map

;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/error.mjs



 //# sourceMappingURL=error.mjs.map

;// CONCATENATED MODULE: ./node_modules/@clerk/backend/dist/runtime/browser/crypto.mjs
/* harmony default export */ const browser_crypto = (crypto);

;// CONCATENATED MODULE: ./node_modules/@clerk/backend/dist/runtime/browser/fetch.mjs
/* harmony default export */ const browser_fetch = ((/* unused pure expression or super */ null && (fetch)));
const RuntimeBlob = Blob;
const RuntimeFormData = FormData;
const RuntimeHeaders = Headers;
const RuntimeRequest = Request;
const RuntimeResponse = Response;
const RuntimeAbortController = AbortController;
const RuntimeFetch = fetch;

// EXTERNAL MODULE: ./node_modules/deepmerge/dist/cjs.js
var cjs = __webpack_require__(792);
var cjs_default = /*#__PURE__*/__webpack_require__.n(cjs);
// EXTERNAL MODULE: ./node_modules/snakecase-keys/index.js
var snakecase_keys = __webpack_require__(832);
var snakecase_keys_default = /*#__PURE__*/__webpack_require__.n(snakecase_keys);
// EXTERNAL MODULE: ./node_modules/cookie/index.js
var cookie = __webpack_require__(629);
;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/isomorphicAtob.mjs


 //# sourceMappingURL=isomorphicAtob.mjs.map

;// CONCATENATED MODULE: ./node_modules/@clerk/backend/dist/esm/index.js
// src/index.ts

// src/api/endpoints/AbstractApi.ts
var AbstractAPI = class {
    constructor(request){
        this.request = request;
    }
    requireId(id) {
        if (!id) {
            throw new Error("A valid resource ID is required.");
        }
    }
};
// src/util/path.ts
var SEPARATOR = "/";
var MULTIPLE_SEPARATOR_REGEX = new RegExp(SEPARATOR + "{1,}", "g");
function joinPaths(...args) {
    return args.filter((p)=>p).join(SEPARATOR).replace(MULTIPLE_SEPARATOR_REGEX, SEPARATOR);
}
// src/api/endpoints/AllowlistIdentifierApi.ts
var basePath = "/allowlist_identifiers";
var AllowlistIdentifierAPI = class extends AbstractAPI {
    async getAllowlistIdentifierList() {
        return this.request({
            method: "GET",
            path: basePath
        });
    }
    async createAllowlistIdentifier(params) {
        return this.request({
            method: "POST",
            path: basePath,
            bodyParams: params
        });
    }
    async deleteAllowlistIdentifier(allowlistIdentifierId) {
        this.requireId(allowlistIdentifierId);
        return this.request({
            method: "DELETE",
            path: joinPaths(basePath, allowlistIdentifierId)
        });
    }
};
// src/api/endpoints/ClientApi.ts
var basePath2 = "/clients";
var ClientAPI = class extends AbstractAPI {
    async getClientList() {
        return this.request({
            method: "GET",
            path: basePath2
        });
    }
    async getClient(clientId) {
        this.requireId(clientId);
        return this.request({
            method: "GET",
            path: joinPaths(basePath2, clientId)
        });
    }
    verifyClient(token) {
        return this.request({
            method: "POST",
            path: joinPaths(basePath2, "verify"),
            bodyParams: {
                token
            }
        });
    }
};
// src/api/endpoints/DomainApi.ts
var basePath3 = "/domains";
var DomainAPI = class extends AbstractAPI {
    async deleteDomain(id) {
        return this.request({
            method: "DELETE",
            path: joinPaths(basePath3, id)
        });
    }
};
// src/api/endpoints/EmailAddressApi.ts
var basePath4 = "/email_addresses";
var EmailAddressAPI = class extends AbstractAPI {
    async getEmailAddress(emailAddressId) {
        this.requireId(emailAddressId);
        return this.request({
            method: "GET",
            path: joinPaths(basePath4, emailAddressId)
        });
    }
    async createEmailAddress(params) {
        return this.request({
            method: "POST",
            path: basePath4,
            bodyParams: params
        });
    }
    async updateEmailAddress(emailAddressId, params = {}) {
        this.requireId(emailAddressId);
        return this.request({
            method: "PATCH",
            path: joinPaths(basePath4, emailAddressId),
            bodyParams: params
        });
    }
    async deleteEmailAddress(emailAddressId) {
        this.requireId(emailAddressId);
        return this.request({
            method: "DELETE",
            path: joinPaths(basePath4, emailAddressId)
        });
    }
};
// src/api/endpoints/EmailApi.ts

var basePath5 = "/emails";
var EmailAPI = class extends AbstractAPI {
    /**
   * @deprecated This endpoint is no longer available and the function will be removed in the next major version.
   */ async createEmail(params) {
        chunk_KJVJ4CFF_deprecated("EmailAPI.createEmail", "This endpoint is no longer available and the function will be removed in the next major version.");
        return this.request({
            method: "POST",
            path: basePath5,
            bodyParams: params
        });
    }
};
// src/util/shared.ts






var errorThrower = buildErrorThrower({
    packageName: "@clerk/backend"
});
var { isDevOrStagingUrl } = createDevOrStagingUrlCache();
// src/api/endpoints/InterstitialApi.ts
var InterstitialAPI = class extends AbstractAPI {
    async getInterstitial() {
        chunk_KJVJ4CFF_deprecated("getInterstitial()", 'Switch to `Clerk(...).localInterstitial(...)` from `import { Clerk } from "@clerk/backend"`.');
        return this.request({
            path: "internal/interstitial",
            method: "GET",
            headerParams: {
                "Content-Type": "text/html"
            }
        });
    }
};
// src/api/endpoints/InvitationApi.ts
var basePath6 = "/invitations";
var InvitationAPI = class extends AbstractAPI {
    async getInvitationList(params = {}) {
        return this.request({
            method: "GET",
            path: basePath6,
            queryParams: params
        });
    }
    async createInvitation(params) {
        return this.request({
            method: "POST",
            path: basePath6,
            bodyParams: params
        });
    }
    async revokeInvitation(invitationId) {
        this.requireId(invitationId);
        return this.request({
            method: "POST",
            path: joinPaths(basePath6, invitationId, "revoke")
        });
    }
};
// src/api/endpoints/OrganizationApi.ts

// src/runtime/index.ts


var { RuntimeFetch: esm_RuntimeFetch, RuntimeAbortController: esm_RuntimeAbortController, RuntimeBlob: esm_RuntimeBlob, RuntimeFormData: esm_RuntimeFormData, RuntimeHeaders: esm_RuntimeHeaders, RuntimeRequest: esm_RuntimeRequest, RuntimeResponse: esm_RuntimeResponse } = fetch_namespaceObject;
var globalFetch = esm_RuntimeFetch.bind(globalThis);
var runtime = {
    crypto: browser_crypto,
    fetch: globalFetch,
    AbortController: esm_RuntimeAbortController,
    Blob: esm_RuntimeBlob,
    FormData: esm_RuntimeFormData,
    Headers: esm_RuntimeHeaders,
    Request: esm_RuntimeRequest,
    Response: esm_RuntimeResponse
};
var runtime_default = runtime;
// src/api/endpoints/OrganizationApi.ts
var basePath7 = "/organizations";
var OrganizationAPI = class extends AbstractAPI {
    async getOrganizationList(params) {
        return this.request({
            method: "GET",
            path: basePath7,
            queryParams: params
        });
    }
    async createOrganization(params) {
        return this.request({
            method: "POST",
            path: basePath7,
            bodyParams: params
        });
    }
    async getOrganization(params) {
        const organizationIdOrSlug = "organizationId" in params ? params.organizationId : params.slug;
        this.requireId(organizationIdOrSlug);
        return this.request({
            method: "GET",
            path: joinPaths(basePath7, organizationIdOrSlug)
        });
    }
    async updateOrganization(organizationId, params) {
        this.requireId(organizationId);
        return this.request({
            method: "PATCH",
            path: joinPaths(basePath7, organizationId),
            bodyParams: params
        });
    }
    async updateOrganizationLogo(organizationId, params) {
        this.requireId(organizationId);
        const formData = new runtime_default.FormData();
        formData.append("file", params?.file);
        formData.append("uploader_user_id", params?.uploaderUserId);
        return this.request({
            method: "PUT",
            path: joinPaths(basePath7, organizationId, "logo"),
            formData
        });
    }
    async deleteOrganizationLogo(organizationId) {
        this.requireId(organizationId);
        return this.request({
            method: "DELETE",
            path: joinPaths(basePath7, organizationId, "logo")
        });
    }
    async updateOrganizationMetadata(organizationId, params) {
        this.requireId(organizationId);
        return this.request({
            method: "PATCH",
            path: joinPaths(basePath7, organizationId, "metadata"),
            bodyParams: params
        });
    }
    async deleteOrganization(organizationId) {
        return this.request({
            method: "DELETE",
            path: joinPaths(basePath7, organizationId)
        });
    }
    async getOrganizationMembershipList(params) {
        const { organizationId, limit, offset } = params;
        this.requireId(organizationId);
        return this.request({
            method: "GET",
            path: joinPaths(basePath7, organizationId, "memberships"),
            queryParams: {
                limit,
                offset
            }
        });
    }
    async createOrganizationMembership(params) {
        const { organizationId, userId, role } = params;
        this.requireId(organizationId);
        return this.request({
            method: "POST",
            path: joinPaths(basePath7, organizationId, "memberships"),
            bodyParams: {
                userId,
                role
            }
        });
    }
    async updateOrganizationMembership(params) {
        const { organizationId, userId, role } = params;
        this.requireId(organizationId);
        return this.request({
            method: "PATCH",
            path: joinPaths(basePath7, organizationId, "memberships", userId),
            bodyParams: {
                role
            }
        });
    }
    async updateOrganizationMembershipMetadata(params) {
        const { organizationId, userId, publicMetadata, privateMetadata } = params;
        return this.request({
            method: "PATCH",
            path: joinPaths(basePath7, organizationId, "memberships", userId, "metadata"),
            bodyParams: {
                publicMetadata,
                privateMetadata
            }
        });
    }
    async deleteOrganizationMembership(params) {
        const { organizationId, userId } = params;
        this.requireId(organizationId);
        return this.request({
            method: "DELETE",
            path: joinPaths(basePath7, organizationId, "memberships", userId)
        });
    }
    async getOrganizationInvitationList(params) {
        const { organizationId, status, limit, offset } = params;
        this.requireId(organizationId);
        return this.request({
            method: "GET",
            path: joinPaths(basePath7, organizationId, "invitations"),
            queryParams: {
                status,
                limit,
                offset
            }
        });
    }
    /**
   * @deprecated  Use `getOrganizationInvitationList` instead along with the status parameter.
   */ async getPendingOrganizationInvitationList(params) {
        chunk_KJVJ4CFF_deprecated("getPendingOrganizationInvitationList", "Use `getOrganizationInvitationList` instead.");
        const { organizationId, limit, offset } = params;
        this.requireId(organizationId);
        return this.request({
            method: "GET",
            path: joinPaths(basePath7, organizationId, "invitations", "pending"),
            queryParams: {
                limit,
                offset
            }
        });
    }
    async createOrganizationInvitation(params) {
        const { organizationId, ...bodyParams } = params;
        this.requireId(organizationId);
        return this.request({
            method: "POST",
            path: joinPaths(basePath7, organizationId, "invitations"),
            bodyParams: {
                ...bodyParams
            }
        });
    }
    async getOrganizationInvitation(params) {
        const { organizationId, invitationId } = params;
        this.requireId(organizationId);
        this.requireId(invitationId);
        return this.request({
            method: "GET",
            path: joinPaths(basePath7, organizationId, "invitations", invitationId)
        });
    }
    async revokeOrganizationInvitation(params) {
        const { organizationId, invitationId, requestingUserId } = params;
        this.requireId(organizationId);
        return this.request({
            method: "POST",
            path: joinPaths(basePath7, organizationId, "invitations", invitationId, "revoke"),
            bodyParams: {
                requestingUserId
            }
        });
    }
};
// src/api/endpoints/PhoneNumberApi.ts
var basePath8 = "/phone_numbers";
var PhoneNumberAPI = class extends AbstractAPI {
    async getPhoneNumber(phoneNumberId) {
        this.requireId(phoneNumberId);
        return this.request({
            method: "GET",
            path: joinPaths(basePath8, phoneNumberId)
        });
    }
    async createPhoneNumber(params) {
        return this.request({
            method: "POST",
            path: basePath8,
            bodyParams: params
        });
    }
    async updatePhoneNumber(phoneNumberId, params = {}) {
        this.requireId(phoneNumberId);
        return this.request({
            method: "PATCH",
            path: joinPaths(basePath8, phoneNumberId),
            bodyParams: params
        });
    }
    async deletePhoneNumber(phoneNumberId) {
        this.requireId(phoneNumberId);
        return this.request({
            method: "DELETE",
            path: joinPaths(basePath8, phoneNumberId)
        });
    }
};
// src/api/endpoints/RedirectUrlApi.ts
var basePath9 = "/redirect_urls";
var RedirectUrlAPI = class extends AbstractAPI {
    async getRedirectUrlList() {
        return this.request({
            method: "GET",
            path: basePath9
        });
    }
    async getRedirectUrl(redirectUrlId) {
        this.requireId(redirectUrlId);
        return this.request({
            method: "GET",
            path: joinPaths(basePath9, redirectUrlId)
        });
    }
    async createRedirectUrl(params) {
        return this.request({
            method: "POST",
            path: basePath9,
            bodyParams: params
        });
    }
    async deleteRedirectUrl(redirectUrlId) {
        this.requireId(redirectUrlId);
        return this.request({
            method: "DELETE",
            path: joinPaths(basePath9, redirectUrlId)
        });
    }
};
// src/api/endpoints/SessionApi.ts
var basePath10 = "/sessions";
var SessionAPI = class extends AbstractAPI {
    async getSessionList(queryParams) {
        return this.request({
            method: "GET",
            path: basePath10,
            queryParams
        });
    }
    async getSession(sessionId) {
        this.requireId(sessionId);
        return this.request({
            method: "GET",
            path: joinPaths(basePath10, sessionId)
        });
    }
    async revokeSession(sessionId) {
        this.requireId(sessionId);
        return this.request({
            method: "POST",
            path: joinPaths(basePath10, sessionId, "revoke")
        });
    }
    async verifySession(sessionId, token) {
        this.requireId(sessionId);
        return this.request({
            method: "POST",
            path: joinPaths(basePath10, sessionId, "verify"),
            bodyParams: {
                token
            }
        });
    }
    async getToken(sessionId, template) {
        this.requireId(sessionId);
        return (await this.request({
            method: "POST",
            path: joinPaths(basePath10, sessionId, "tokens", template || "")
        })).jwt;
    }
};
// src/api/endpoints/SignInTokenApi.ts
var basePath11 = "/sign_in_tokens";
var SignInTokenAPI = class extends AbstractAPI {
    async createSignInToken(params) {
        return this.request({
            method: "POST",
            path: basePath11,
            bodyParams: params
        });
    }
    async revokeSignInToken(signInTokenId) {
        this.requireId(signInTokenId);
        return this.request({
            method: "POST",
            path: joinPaths(basePath11, signInTokenId, "revoke")
        });
    }
};
// src/api/endpoints/SMSMessageApi.ts

var basePath12 = "/sms_messages";
var SMSMessageAPI = class extends AbstractAPI {
    /**
   * @deprecated This endpoint is no longer available and the function will be removed in the next major version.
   */ async createSMSMessage(params) {
        chunk_KJVJ4CFF_deprecated("SMSMessageAPI.createSMSMessage", "This endpoint is no longer available and the function will be removed in the next major version.");
        return this.request({
            method: "POST",
            path: basePath12,
            bodyParams: params
        });
    }
};
// src/api/endpoints/UserApi.ts
var basePath13 = "/users";
var UserAPI = class extends AbstractAPI {
    async getUserList(params = {}) {
        return this.request({
            method: "GET",
            path: basePath13,
            queryParams: params
        });
    }
    async getUser(userId) {
        this.requireId(userId);
        return this.request({
            method: "GET",
            path: joinPaths(basePath13, userId)
        });
    }
    async createUser(params) {
        return this.request({
            method: "POST",
            path: basePath13,
            bodyParams: params
        });
    }
    async updateUser(userId, params = {}) {
        this.requireId(userId);
        return this.request({
            method: "PATCH",
            path: joinPaths(basePath13, userId),
            bodyParams: params
        });
    }
    async updateUserProfileImage(userId, params) {
        this.requireId(userId);
        const formData = new runtime_default.FormData();
        formData.append("file", params?.file);
        return this.request({
            method: "POST",
            path: joinPaths(basePath13, userId, "profile_image"),
            formData
        });
    }
    async updateUserMetadata(userId, params) {
        this.requireId(userId);
        return this.request({
            method: "PATCH",
            path: joinPaths(basePath13, userId, "metadata"),
            bodyParams: params
        });
    }
    async deleteUser(userId) {
        this.requireId(userId);
        return this.request({
            method: "DELETE",
            path: joinPaths(basePath13, userId)
        });
    }
    async getCount(params = {}) {
        return this.request({
            method: "GET",
            path: joinPaths(basePath13, "count"),
            queryParams: params
        });
    }
    async getUserOauthAccessToken(userId, provider) {
        this.requireId(userId);
        return this.request({
            method: "GET",
            path: joinPaths(basePath13, userId, "oauth_access_tokens", provider)
        });
    }
    async disableUserMFA(userId) {
        this.requireId(userId);
        return this.request({
            method: "DELETE",
            path: joinPaths(basePath13, userId, "mfa")
        });
    }
    async getOrganizationMembershipList(params) {
        const { userId, limit, offset } = params;
        this.requireId(userId);
        return this.request({
            method: "GET",
            path: joinPaths(basePath13, userId, "organization_memberships"),
            queryParams: {
                limit,
                offset
            }
        });
    }
    async verifyPassword(params) {
        const { userId, password } = params;
        this.requireId(userId);
        return this.request({
            method: "POST",
            path: joinPaths(basePath13, userId, "verify_password"),
            bodyParams: {
                password
            }
        });
    }
    async verifyTOTP(params) {
        const { userId, code } = params;
        this.requireId(userId);
        return this.request({
            method: "POST",
            path: joinPaths(basePath13, userId, "verify_totp"),
            bodyParams: {
                code
            }
        });
    }
};
// src/api/request.ts



// src/constants.ts
var API_URL = "https://api.clerk.dev";
var API_VERSION = "v1";
var USER_AGENT = `${"@clerk/backend"}@${"0.37.3"}`;
var MAX_CACHE_LAST_UPDATED_AT_SECONDS = 5 * 60;
var Attributes = {
    AuthToken: "__clerkAuthToken",
    AuthStatus: "__clerkAuthStatus",
    AuthReason: "__clerkAuthReason",
    AuthMessage: "__clerkAuthMessage"
};
var Cookies = {
    Session: "__session",
    ClientUat: "__client_uat"
};
var esm_Headers = {
    AuthToken: "x-clerk-auth-token",
    AuthStatus: "x-clerk-auth-status",
    AuthReason: "x-clerk-auth-reason",
    AuthMessage: "x-clerk-auth-message",
    EnableDebug: "x-clerk-debug",
    ClerkRedirectTo: "x-clerk-redirect-to",
    CloudFrontForwardedProto: "cloudfront-forwarded-proto",
    Authorization: "authorization",
    ForwardedPort: "x-forwarded-port",
    ForwardedProto: "x-forwarded-proto",
    ForwardedHost: "x-forwarded-host",
    Referrer: "referer",
    UserAgent: "user-agent",
    Origin: "origin",
    Host: "host",
    ContentType: "content-type"
};
var SearchParams = {
    AuthStatus: esm_Headers.AuthStatus,
    AuthToken: esm_Headers.AuthToken
};
var ContentTypes = {
    Json: "application/json"
};
var esm_constants = {
    Attributes,
    Cookies,
    Headers: esm_Headers,
    SearchParams,
    ContentTypes
};
// src/util/assertValidSecretKey.ts
function assertValidSecretKey(val) {
    if (!val || typeof val !== "string") {
        throw Error("Missing Clerk Secret Key or API Key. Go to https://dashboard.clerk.com and get your key for your instance.");
    }
}
// src/api/resources/AllowlistIdentifier.ts
var AllowlistIdentifier = class _AllowlistIdentifier {
    constructor(id, identifier, createdAt, updatedAt, invitationId){
        this.id = id;
        this.identifier = identifier;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.invitationId = invitationId;
    }
    static fromJSON(data) {
        return new _AllowlistIdentifier(data.id, data.identifier, data.created_at, data.updated_at, data.invitation_id);
    }
};
// src/api/resources/Session.ts
var Session = class _Session {
    constructor(id, clientId, userId, status, lastActiveAt, expireAt, abandonAt, createdAt, updatedAt){
        this.id = id;
        this.clientId = clientId;
        this.userId = userId;
        this.status = status;
        this.lastActiveAt = lastActiveAt;
        this.expireAt = expireAt;
        this.abandonAt = abandonAt;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
    static fromJSON(data) {
        return new _Session(data.id, data.client_id, data.user_id, data.status, data.last_active_at, data.expire_at, data.abandon_at, data.created_at, data.updated_at);
    }
};
// src/api/resources/Client.ts
var Client = class _Client {
    constructor(id, sessionIds, sessions, signInId, signUpId, lastActiveSessionId, createdAt, updatedAt){
        this.id = id;
        this.sessionIds = sessionIds;
        this.sessions = sessions;
        this.signInId = signInId;
        this.signUpId = signUpId;
        this.lastActiveSessionId = lastActiveSessionId;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
    static fromJSON(data) {
        return new _Client(data.id, data.session_ids, data.sessions.map((x)=>Session.fromJSON(x)), data.sign_in_id, data.sign_up_id, data.last_active_session_id, data.created_at, data.updated_at);
    }
};
// src/api/resources/DeletedObject.ts
var DeletedObject = class _DeletedObject {
    constructor(object, id, slug, deleted){
        this.object = object;
        this.id = id;
        this.slug = slug;
        this.deleted = deleted;
    }
    static fromJSON(data) {
        return new _DeletedObject(data.object, data.id || null, data.slug || null, data.deleted);
    }
};
// src/api/resources/Email.ts
var Email = class _Email {
    constructor(id, fromEmailName, emailAddressId, toEmailAddress, subject, body, bodyPlain, status, slug, data, deliveredByClerk){
        this.id = id;
        this.fromEmailName = fromEmailName;
        this.emailAddressId = emailAddressId;
        this.toEmailAddress = toEmailAddress;
        this.subject = subject;
        this.body = body;
        this.bodyPlain = bodyPlain;
        this.status = status;
        this.slug = slug;
        this.data = data;
        this.deliveredByClerk = deliveredByClerk;
    }
    static fromJSON(data) {
        return new _Email(data.id, data.from_email_name, data.email_address_id, data.to_email_address, data.subject, data.body, data.body_plain, data.status, data.slug, data.data, data.delivered_by_clerk);
    }
};
// src/api/resources/IdentificationLink.ts
var IdentificationLink = class _IdentificationLink {
    constructor(id, type){
        this.id = id;
        this.type = type;
    }
    static fromJSON(data) {
        return new _IdentificationLink(data.id, data.type);
    }
};
// src/api/resources/Verification.ts
var Verification = class _Verification {
    constructor(status, strategy, externalVerificationRedirectURL = null, attempts = null, expireAt = null, nonce = null){
        this.status = status;
        this.strategy = strategy;
        this.externalVerificationRedirectURL = externalVerificationRedirectURL;
        this.attempts = attempts;
        this.expireAt = expireAt;
        this.nonce = nonce;
    }
    static fromJSON(data) {
        return new _Verification(data.status, data.strategy, data.external_verification_redirect_url ? new URL(data.external_verification_redirect_url) : null, data.attempts, data.expire_at, data.nonce);
    }
};
// src/api/resources/EmailAddress.ts
var EmailAddress = class _EmailAddress {
    constructor(id, emailAddress, verification, linkedTo){
        this.id = id;
        this.emailAddress = emailAddress;
        this.verification = verification;
        this.linkedTo = linkedTo;
    }
    static fromJSON(data) {
        return new _EmailAddress(data.id, data.email_address, data.verification && Verification.fromJSON(data.verification), data.linked_to.map((link)=>IdentificationLink.fromJSON(link)));
    }
};
// src/api/resources/ExternalAccount.ts
var ExternalAccount = class _ExternalAccount {
    constructor(id, provider, identificationId, externalId, approvedScopes, emailAddress, firstName, lastName, picture, imageUrl, username, publicMetadata = {}, label, verification){
        this.id = id;
        this.provider = provider;
        this.identificationId = identificationId;
        this.externalId = externalId;
        this.approvedScopes = approvedScopes;
        this.emailAddress = emailAddress;
        this.firstName = firstName;
        this.lastName = lastName;
        this.picture = picture;
        this.imageUrl = imageUrl;
        this.username = username;
        this.publicMetadata = publicMetadata;
        this.label = label;
        this.verification = verification;
    }
    static fromJSON(data) {
        return new _ExternalAccount(data.id, data.provider, data.identification_id, data.provider_user_id, data.approved_scopes, data.email_address, data.first_name, data.last_name, data.avatar_url, data.image_url, data.username, data.public_metadata, data.label, data.verification && Verification.fromJSON(data.verification));
    }
};
deprecatedProperty(ExternalAccount, "picture", "Use `imageUrl` instead.");
// src/api/resources/Invitation.ts
var Invitation = class _Invitation {
    constructor(id, emailAddress, publicMetadata, createdAt, updatedAt, status, revoked){
        this.id = id;
        this.emailAddress = emailAddress;
        this.publicMetadata = publicMetadata;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.status = status;
        this.revoked = revoked;
    }
    static fromJSON(data) {
        return new _Invitation(data.id, data.email_address, data.public_metadata, data.created_at, data.updated_at, data.status, data.revoked);
    }
};
// src/api/resources/JSON.ts
var ObjectType = /* @__PURE__ */ ((ObjectType2)=>{
    ObjectType2["AllowlistIdentifier"] = "allowlist_identifier";
    ObjectType2["Client"] = "client";
    ObjectType2["Email"] = "email";
    ObjectType2["EmailAddress"] = "email_address";
    ObjectType2["ExternalAccount"] = "external_account";
    ObjectType2["FacebookAccount"] = "facebook_account";
    ObjectType2["GoogleAccount"] = "google_account";
    ObjectType2["Invitation"] = "invitation";
    ObjectType2["OauthAccessToken"] = "oauth_access_token";
    ObjectType2["Organization"] = "organization";
    ObjectType2["OrganizationInvitation"] = "organization_invitation";
    ObjectType2["OrganizationMembership"] = "organization_membership";
    ObjectType2["PhoneNumber"] = "phone_number";
    ObjectType2["RedirectUrl"] = "redirect_url";
    ObjectType2["Session"] = "session";
    ObjectType2["SignInAttempt"] = "sign_in_attempt";
    ObjectType2["SignInToken"] = "sign_in_token";
    ObjectType2["SignUpAttempt"] = "sign_up_attempt";
    ObjectType2["SmsMessage"] = "sms_message";
    ObjectType2["User"] = "user";
    ObjectType2["Web3Wallet"] = "web3_wallet";
    ObjectType2["Token"] = "token";
    ObjectType2["TotalCount"] = "total_count";
    return ObjectType2;
})(ObjectType || {});
// src/api/resources/OauthAccessToken.ts
var OauthAccessToken = class _OauthAccessToken {
    constructor(provider, token, publicMetadata = {}, label, scopes, tokenSecret){
        this.provider = provider;
        this.token = token;
        this.publicMetadata = publicMetadata;
        this.label = label;
        this.scopes = scopes;
        this.tokenSecret = tokenSecret;
    }
    static fromJSON(data) {
        return new _OauthAccessToken(data.provider, data.token, data.public_metadata, data.label, data.scopes, data.token_secret);
    }
};
// src/api/resources/Organization.ts
var Organization = class _Organization {
    constructor(id, name, slug, logoUrl, imageUrl, hasImage, createdBy, createdAt, updatedAt, publicMetadata = {}, privateMetadata = {}, maxAllowedMemberships, adminDeleteEnabled, members_count){
        this.id = id;
        this.name = name;
        this.slug = slug;
        this.logoUrl = logoUrl;
        this.imageUrl = imageUrl;
        this.hasImage = hasImage;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.publicMetadata = publicMetadata;
        this.privateMetadata = privateMetadata;
        this.maxAllowedMemberships = maxAllowedMemberships;
        this.adminDeleteEnabled = adminDeleteEnabled;
        this.members_count = members_count;
    }
    static fromJSON(data) {
        return new _Organization(data.id, data.name, data.slug, data.logo_url, data.image_url, data.has_image, data.created_by, data.created_at, data.updated_at, data.public_metadata, data.private_metadata, data.max_allowed_memberships, data.admin_delete_enabled, data.members_count);
    }
};
deprecatedProperty(Organization, "logoUrl", "Use `imageUrl` instead.");
// src/api/resources/OrganizationInvitation.ts
var OrganizationInvitation = class _OrganizationInvitation {
    constructor(id, emailAddress, role, organizationId, createdAt, updatedAt, status, publicMetadata = {}, privateMetadata = {}){
        this.id = id;
        this.emailAddress = emailAddress;
        this.role = role;
        this.organizationId = organizationId;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.status = status;
        this.publicMetadata = publicMetadata;
        this.privateMetadata = privateMetadata;
    }
    static fromJSON(data) {
        return new _OrganizationInvitation(data.id, data.email_address, data.role, data.organization_id, data.created_at, data.updated_at, data.status, data.public_metadata, data.private_metadata);
    }
};
// src/api/resources/OrganizationMembership.ts
var OrganizationMembership = class _OrganizationMembership {
    constructor(id, role, publicMetadata = {}, privateMetadata = {}, createdAt, updatedAt, organization, publicUserData){
        this.id = id;
        this.role = role;
        this.publicMetadata = publicMetadata;
        this.privateMetadata = privateMetadata;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.organization = organization;
        this.publicUserData = publicUserData;
    }
    static fromJSON(data) {
        return new _OrganizationMembership(data.id, data.role, data.public_metadata, data.private_metadata, data.created_at, data.updated_at, Organization.fromJSON(data.organization), OrganizationMembershipPublicUserData.fromJSON(data.public_user_data));
    }
};
var OrganizationMembershipPublicUserData = class _OrganizationMembershipPublicUserData {
    constructor(identifier, firstName, lastName, profileImageUrl, imageUrl, hasImage, userId){
        this.identifier = identifier;
        this.firstName = firstName;
        this.lastName = lastName;
        this.profileImageUrl = profileImageUrl;
        this.imageUrl = imageUrl;
        this.hasImage = hasImage;
        this.userId = userId;
    }
    static fromJSON(data) {
        return new _OrganizationMembershipPublicUserData(data.identifier, data.first_name, data.last_name, data.profile_image_url, data.image_url, data.has_image, data.user_id);
    }
};
deprecatedProperty(OrganizationMembershipPublicUserData, "profileImageUrl", "Use `imageUrl` instead.");
// src/api/resources/PhoneNumber.ts
var PhoneNumber = class _PhoneNumber {
    constructor(id, phoneNumber, reservedForSecondFactor, defaultSecondFactor, verification, linkedTo){
        this.id = id;
        this.phoneNumber = phoneNumber;
        this.reservedForSecondFactor = reservedForSecondFactor;
        this.defaultSecondFactor = defaultSecondFactor;
        this.verification = verification;
        this.linkedTo = linkedTo;
    }
    static fromJSON(data) {
        return new _PhoneNumber(data.id, data.phone_number, data.reserved_for_second_factor, data.default_second_factor, data.verification && Verification.fromJSON(data.verification), data.linked_to.map((link)=>IdentificationLink.fromJSON(link)));
    }
};
// src/api/resources/RedirectUrl.ts
var RedirectUrl = class _RedirectUrl {
    constructor(id, url, createdAt, updatedAt){
        this.id = id;
        this.url = url;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
    static fromJSON(data) {
        return new _RedirectUrl(data.id, data.url, data.created_at, data.updated_at);
    }
};
// src/api/resources/SignInTokens.ts
var SignInToken = class _SignInToken {
    constructor(id, userId, token, status, url, createdAt, updatedAt){
        this.id = id;
        this.userId = userId;
        this.token = token;
        this.status = status;
        this.url = url;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
    static fromJSON(data) {
        return new _SignInToken(data.id, data.user_id, data.token, data.status, data.url, data.created_at, data.updated_at);
    }
};
// src/api/resources/SMSMessage.ts
var SMSMessage = class _SMSMessage {
    constructor(id, fromPhoneNumber, toPhoneNumber, message, status, phoneNumberId, data){
        this.id = id;
        this.fromPhoneNumber = fromPhoneNumber;
        this.toPhoneNumber = toPhoneNumber;
        this.message = message;
        this.status = status;
        this.phoneNumberId = phoneNumberId;
        this.data = data;
    }
    static fromJSON(data) {
        return new _SMSMessage(data.id, data.from_phone_number, data.to_phone_number, data.message, data.status, data.phone_number_id, data.data);
    }
};
// src/api/resources/Token.ts
var Token = class _Token {
    constructor(jwt){
        this.jwt = jwt;
    }
    static fromJSON(data) {
        return new _Token(data.jwt);
    }
};
// src/api/resources/Web3Wallet.ts
var Web3Wallet = class _Web3Wallet {
    constructor(id, web3Wallet, verification){
        this.id = id;
        this.web3Wallet = web3Wallet;
        this.verification = verification;
    }
    static fromJSON(data) {
        return new _Web3Wallet(data.id, data.web3_wallet, data.verification && Verification.fromJSON(data.verification));
    }
};
// src/api/resources/User.ts
var User = class _User {
    constructor(id, passwordEnabled, totpEnabled, backupCodeEnabled, twoFactorEnabled, banned, createdAt, updatedAt, profileImageUrl, imageUrl, hasImage, gender, birthday, primaryEmailAddressId, primaryPhoneNumberId, primaryWeb3WalletId, lastSignInAt, externalId, username, firstName, lastName, publicMetadata = {}, privateMetadata = {}, unsafeMetadata = {}, emailAddresses = [], phoneNumbers = [], web3Wallets = [], externalAccounts = [], createOrganizationEnabled){
        this.id = id;
        this.passwordEnabled = passwordEnabled;
        this.totpEnabled = totpEnabled;
        this.backupCodeEnabled = backupCodeEnabled;
        this.twoFactorEnabled = twoFactorEnabled;
        this.banned = banned;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.profileImageUrl = profileImageUrl;
        this.imageUrl = imageUrl;
        this.hasImage = hasImage;
        this.gender = gender;
        this.birthday = birthday;
        this.primaryEmailAddressId = primaryEmailAddressId;
        this.primaryPhoneNumberId = primaryPhoneNumberId;
        this.primaryWeb3WalletId = primaryWeb3WalletId;
        this.lastSignInAt = lastSignInAt;
        this.externalId = externalId;
        this.username = username;
        this.firstName = firstName;
        this.lastName = lastName;
        this.publicMetadata = publicMetadata;
        this.privateMetadata = privateMetadata;
        this.unsafeMetadata = unsafeMetadata;
        this.emailAddresses = emailAddresses;
        this.phoneNumbers = phoneNumbers;
        this.web3Wallets = web3Wallets;
        this.externalAccounts = externalAccounts;
        this.createOrganizationEnabled = createOrganizationEnabled;
    }
    static fromJSON(data) {
        return new _User(data.id, data.password_enabled, data.totp_enabled, data.backup_code_enabled, data.two_factor_enabled, data.banned, data.created_at, data.updated_at, data.profile_image_url, data.image_url, data.has_image, data.gender, data.birthday, data.primary_email_address_id, data.primary_phone_number_id, data.primary_web3_wallet_id, data.last_sign_in_at, data.external_id, data.username, data.first_name, data.last_name, data.public_metadata, data.private_metadata, data.unsafe_metadata, (data.email_addresses || []).map((x)=>EmailAddress.fromJSON(x)), (data.phone_numbers || []).map((x)=>PhoneNumber.fromJSON(x)), (data.web3_wallets || []).map((x)=>Web3Wallet.fromJSON(x)), (data.external_accounts || []).map((x)=>ExternalAccount.fromJSON(x)), data.create_organization_enabled);
    }
};
deprecatedProperty(User, "profileImageUrl", "Use `imageUrl` instead.");
// src/api/resources/Deserializer.ts
function deserialize(payload) {
    if (Array.isArray(payload)) {
        return payload.map((item)=>jsonToObject(item));
    } else if (isPaginated(payload)) {
        return payload.data.map((item)=>jsonToObject(item));
    } else {
        return jsonToObject(payload);
    }
}
function isPaginated(payload) {
    return Array.isArray(payload.data) && payload.data !== void 0;
}
function getCount(item) {
    return item.total_count;
}
function jsonToObject(item) {
    if (typeof item !== "string" && "object" in item && "deleted" in item) {
        return DeletedObject.fromJSON(item);
    }
    switch(item.object){
        case "allowlist_identifier" /* AllowlistIdentifier */ :
            return AllowlistIdentifier.fromJSON(item);
        case "client" /* Client */ :
            return Client.fromJSON(item);
        case "email_address" /* EmailAddress */ :
            return EmailAddress.fromJSON(item);
        case "email" /* Email */ :
            return Email.fromJSON(item);
        case "invitation" /* Invitation */ :
            return Invitation.fromJSON(item);
        case "oauth_access_token" /* OauthAccessToken */ :
            return OauthAccessToken.fromJSON(item);
        case "organization" /* Organization */ :
            return Organization.fromJSON(item);
        case "organization_invitation" /* OrganizationInvitation */ :
            return OrganizationInvitation.fromJSON(item);
        case "organization_membership" /* OrganizationMembership */ :
            return OrganizationMembership.fromJSON(item);
        case "phone_number" /* PhoneNumber */ :
            return PhoneNumber.fromJSON(item);
        case "redirect_url" /* RedirectUrl */ :
            return RedirectUrl.fromJSON(item);
        case "sign_in_token" /* SignInToken */ :
            return SignInToken.fromJSON(item);
        case "session" /* Session */ :
            return Session.fromJSON(item);
        case "sms_message" /* SmsMessage */ :
            return SMSMessage.fromJSON(item);
        case "token" /* Token */ :
            return Token.fromJSON(item);
        case "total_count" /* TotalCount */ :
            return getCount(item);
        case "user" /* User */ :
            return User.fromJSON(item);
        default:
            return item;
    }
}
// src/api/request.ts
var withLegacyReturn = (cb)=>async (...args)=>{
        const response = await cb(...args);
        if (response.errors === null) {
            return response.data;
        } else {
            const { errors, clerkTraceId } = response;
            const { status, statusText } = response;
            const error = new ClerkAPIResponseError(statusText || "", {
                data: [],
                status: status || "",
                clerkTraceId
            });
            error.errors = errors;
            throw error;
        }
    };
function buildRequest(options) {
    const request = async (requestOptions)=>{
        const { apiKey, secretKey, httpOptions, apiUrl = API_URL, apiVersion = API_VERSION, userAgent = USER_AGENT } = options;
        if (apiKey) {
            chunk_KJVJ4CFF_deprecated("apiKey", "Use `secretKey` instead.");
        }
        if (httpOptions) {
            chunk_KJVJ4CFF_deprecated("httpOptions", "This option has been deprecated and will be removed with the next major release.\nA RequestInit init object used by the `request` method.");
        }
        const { path, method, queryParams, headerParams, bodyParams, formData } = requestOptions;
        const key = secretKey || apiKey;
        assertValidSecretKey(key);
        const url = joinPaths(apiUrl, apiVersion, path);
        const finalUrl = new URL(url);
        if (queryParams) {
            const snakecasedQueryParams = snakecase_keys_default()({
                ...queryParams
            });
            for (const [key2, val] of Object.entries(snakecasedQueryParams)){
                if (val) {
                    [
                        val
                    ].flat().forEach((v)=>finalUrl.searchParams.append(key2, v));
                }
            }
        }
        const headers = {
            Authorization: `Bearer ${key}`,
            "User-Agent": userAgent,
            ...headerParams
        };
        let res = void 0;
        try {
            if (formData) {
                res = await runtime_default.fetch(finalUrl.href, {
                    ...httpOptions,
                    method,
                    headers,
                    body: formData
                });
            } else {
                headers["Content-Type"] = "application/json";
                const hasBody = method !== "GET" && bodyParams && Object.keys(bodyParams).length > 0;
                const body = hasBody ? {
                    body: JSON.stringify(snakecase_keys_default()(bodyParams, {
                        deep: false
                    }))
                } : null;
                res = await runtime_default.fetch(finalUrl.href, cjs_default()(httpOptions || {}, {
                    method,
                    headers,
                    ...body
                }));
            }
            const isJSONResponse = res?.headers && res.headers?.get(esm_constants.Headers.ContentType) === esm_constants.ContentTypes.Json;
            const data = await (isJSONResponse ? res.json() : res.text());
            if (!res.ok) {
                throw data;
            }
            return {
                data: deserialize(data),
                errors: null
            };
        } catch (err) {
            if (err instanceof Error) {
                return {
                    data: null,
                    errors: [
                        {
                            code: "unexpected_error",
                            message: err.message || "Unexpected error"
                        }
                    ],
                    clerkTraceId: getTraceId(err, res?.headers)
                };
            }
            return {
                data: null,
                errors: esm_parseErrors(err),
                // TODO: To be removed with withLegacyReturn
                // @ts-expect-error
                status: res?.status,
                statusText: res?.statusText,
                clerkTraceId: getTraceId(err, res?.headers)
            };
        }
    };
    return withLegacyReturn(request);
}
function getTraceId(data, headers) {
    if (data && typeof data === "object" && "clerk_trace_id" in data && typeof data.clerk_trace_id === "string") {
        return data.clerk_trace_id;
    }
    const cfRay = headers?.get("cf-ray");
    return cfRay || "";
}
function esm_parseErrors(data) {
    if (!!data && typeof data === "object" && "errors" in data) {
        const errors = data.errors;
        return errors.length > 0 ? errors.map(esm_parseError) : [];
    }
    return [];
}
function esm_parseError(error) {
    return {
        code: error.code,
        message: error.message,
        longMessage: error.long_message,
        meta: {
            paramName: error?.meta?.param_name,
            sessionId: error?.meta?.session_id
        }
    };
}
// src/api/factory.ts
function createBackendApiClient(options) {
    const request = buildRequest(options);
    return {
        allowlistIdentifiers: new AllowlistIdentifierAPI(request),
        clients: new ClientAPI(request),
        emailAddresses: new EmailAddressAPI(request),
        emails: new EmailAPI(request),
        interstitial: new InterstitialAPI(request),
        invitations: new InvitationAPI(request),
        organizations: new OrganizationAPI(request),
        phoneNumbers: new PhoneNumberAPI(request),
        redirectUrls: new RedirectUrlAPI(request),
        sessions: new SessionAPI(request),
        signInTokens: new SignInTokenAPI(request),
        smsMessages: new SMSMessageAPI(request),
        users: new UserAPI(request),
        domains: new DomainAPI(request)
    };
}
// src/tokens/authObjects.ts

var createDebug = (data)=>{
    return ()=>{
        const res = {
            ...data
        };
        res.apiKey = (res.apiKey || "").substring(0, 7);
        res.secretKey = (res.secretKey || "").substring(0, 7);
        res.jwtKey = (res.jwtKey || "").substring(0, 7);
        return {
            ...res
        };
    };
};
function signedInAuthObject(sessionClaims, options, debugData) {
    const { act: actor, sid: sessionId, org_id: orgId, org_role: orgRole, org_slug: orgSlug, org_permissions: orgPermissions, sub: userId } = sessionClaims;
    const { apiKey, secretKey, apiUrl, apiVersion, token, session, user, organization } = options;
    if (apiKey) {
        chunk_KJVJ4CFF_deprecated("apiKey", "Use `secretKey` instead.");
    }
    const { sessions } = createBackendApiClient({
        apiKey,
        secretKey,
        apiUrl,
        apiVersion
    });
    const getToken = createGetToken({
        sessionId,
        sessionToken: token,
        fetcher: (...args)=>sessions.getToken(...args)
    });
    return {
        actor,
        sessionClaims,
        sessionId,
        session,
        userId,
        user,
        orgId,
        orgRole,
        orgSlug,
        orgPermissions,
        organization,
        getToken,
        has: createHasAuthorization({
            orgId,
            orgRole,
            orgPermissions,
            userId
        }),
        debug: createDebug({
            ...options,
            ...debugData
        })
    };
}
function signedOutAuthObject(debugData) {
    if (debugData?.apiKey) {
        chunk_KJVJ4CFF_deprecated("apiKey", "Use `secretKey` instead.");
    }
    return {
        sessionClaims: null,
        sessionId: null,
        session: null,
        userId: null,
        user: null,
        actor: null,
        orgId: null,
        orgRole: null,
        orgSlug: null,
        orgPermissions: null,
        organization: null,
        getToken: ()=>Promise.resolve(null),
        has: ()=>false,
        debug: createDebug(debugData)
    };
}
function prunePrivateMetadata(resource) {
    if (resource) {
        delete resource["privateMetadata"];
        delete resource["private_metadata"];
    }
    return resource;
}
function sanitizeAuthObject(authObject) {
    const user = authObject.user ? {
        ...authObject.user
    } : authObject.user;
    const organization = authObject.organization ? {
        ...authObject.organization
    } : authObject.organization;
    prunePrivateMetadata(user);
    prunePrivateMetadata(organization);
    return {
        ...authObject,
        user,
        organization
    };
}
var makeAuthObjectSerializable = (obj)=>{
    const { debug, getToken, has, ...rest } = obj;
    return rest;
};
var createGetToken = (params)=>{
    const { fetcher, sessionToken, sessionId } = params || {};
    return async (options = {})=>{
        if (!sessionId) {
            return null;
        }
        if (options.template) {
            return fetcher(sessionId, options.template);
        }
        return sessionToken;
    };
};
var createHasAuthorization = ({ orgId, orgRole, userId, orgPermissions })=>(params)=>{
        if (!params?.permission && !params?.role) {
            throw new Error('Missing parameters. `has` from `auth` or `getAuth` requires a permission or role key to be passed. Example usage: `has({permission: "org:posts:edit"`');
        }
        if (!orgId || !userId || !orgRole || !orgPermissions) {
            return false;
        }
        if (params.permission) {
            return orgPermissions.includes(params.permission);
        }
        if (params.role) {
            return orgRole === params.role;
        }
        return false;
    };
// src/tokens/errors.ts
var TokenVerificationError = class _TokenVerificationError extends Error {
    constructor({ action, message, reason }){
        super(message);
        Object.setPrototypeOf(this, _TokenVerificationError.prototype);
        this.reason = reason;
        this.message = message;
        this.action = action;
    }
    getFullMessage() {
        return `${[
            this.message,
            this.action
        ].filter((m)=>m).join(" ")} (reason=${this.reason}, token-carrier=${this.tokenCarrier})`;
    }
};
// src/tokens/interstitial.ts
function loadInterstitialFromLocal(options) {
    if (options.frontendApi) {
        chunk_KJVJ4CFF_deprecated("frontendApi", "Use `publishableKey` instead.");
    }
    if (options.pkgVersion) {
        chunk_KJVJ4CFF_deprecated("pkgVersion", "Use `clerkJSVersion` instead.");
    }
    options.frontendApi = chunk_IAZRYRAH_parsePublishableKey(options.publishableKey)?.frontendApi || options.frontendApi || "";
    const domainOnlyInProd = !isDevOrStagingUrl(options.frontendApi) ? addClerkPrefix(options.domain) : "";
    const { debugData, frontendApi, pkgVersion, clerkJSUrl, clerkJSVersion, publishableKey, proxyUrl, isSatellite = false, domain, signInUrl } = options;
    return `
    <head>
        <meta charset="UTF-8" />
        <style>
          @media (prefers-color-scheme: dark) {
            body {
              background-color: black;
            }
          }
        </style>
    </head>
    <body>
        <script>
            window.__clerk_frontend_api = '${frontendApi}';
            window.__clerk_debug = ${JSON.stringify(debugData || {})};
            ${proxyUrl ? `window.__clerk_proxy_url = '${proxyUrl}'` : ""}
            ${domain ? `window.__clerk_domain = '${domain}'` : ""}
            window.startClerk = async () => {
                function formRedirect(){
                    const form = '<form method="get" action="" name="redirect"></form>';
                    document.body.innerHTML = document.body.innerHTML + form;

                    const searchParams = new URLSearchParams(window.location.search);
                    for (let paramTuple of searchParams) {
                        const input = document.createElement("input");
                        input.type = "hidden";
                        input.name = paramTuple[0];
                        input.value = paramTuple[1];
                        document.forms.redirect.appendChild(input);
                    }
                    const url = new URL(window.location.origin + window.location.pathname + window.location.hash);
                    window.history.pushState({}, '', url);

                    document.forms.redirect.action = window.location.pathname + window.location.hash;
                    document.forms.redirect.submit();
                }

                const Clerk = window.Clerk;
                try {
                    await Clerk.load({
                        isSatellite: ${isSatellite},
                        isInterstitial: ${true},
                        signInUrl: ${signInUrl ? `'${signInUrl}'` : void 0}
                    });
                    if(Clerk.loaded){
                      if(window.location.href.indexOf("#") === -1){
                        window.location.href = window.location.href;
                      } else if (window.navigator.userAgent.toLowerCase().includes("firefox/")){
                          formRedirect();
                      } else {
                          window.location.reload();
                      }
                    }
                } catch (err) {
                    console.error('Clerk: ', err);
                }
            };
            (() => {
                const script = document.createElement('script');
                ${publishableKey ? `script.setAttribute('data-clerk-publishable-key', '${publishableKey}');` : `script.setAttribute('data-clerk-frontend-api', '${frontendApi}');`}

                ${domain ? `script.setAttribute('data-clerk-domain', '${domain}');` : ""}
                ${proxyUrl ? `script.setAttribute('data-clerk-proxy-url', '${proxyUrl}')` : ""};
                script.async = true;
                script.src = '${clerkJSUrl || getScriptUrl(proxyUrl || domainOnlyInProd || frontendApi, {
        pkgVersion,
        clerkJSVersion
    })}';
                script.crossOrigin = 'anonymous';
                script.addEventListener('load', startClerk);
                document.body.appendChild(script);
            })();
        </script>
    </body>
`;
}
async function loadInterstitialFromBAPI(options) {
    if (options.frontendApi) {
        chunk_KJVJ4CFF_deprecated("frontendApi", "Use `publishableKey` instead.");
    }
    if (options.pkgVersion) {
        chunk_KJVJ4CFF_deprecated("pkgVersion", "Use `clerkJSVersion` instead.");
    }
    options.frontendApi = chunk_IAZRYRAH_parsePublishableKey(options.publishableKey)?.frontendApi || options.frontendApi || "";
    const url = buildPublicInterstitialUrl(options);
    const response = await callWithRetry(()=>runtime_default.fetch(buildPublicInterstitialUrl(options), {
            method: "GET",
            headers: {
                "Clerk-Backend-SDK": options.userAgent || USER_AGENT
            }
        }));
    if (!response.ok) {
        throw new TokenVerificationError({
            action: "Contact support@clerk.com" /* ContactSupport */ ,
            message: `Error loading Clerk Interstitial from ${url} with code=${response.status}`,
            reason: "interstitial-remote-failed-to-load" /* RemoteInterstitialFailedToLoad */ 
        });
    }
    return response.text();
}
function buildPublicInterstitialUrl(options) {
    if (options.frontendApi) {
        chunk_KJVJ4CFF_deprecated("frontendApi", "Use `publishableKey` instead.");
    }
    options.frontendApi = chunk_IAZRYRAH_parsePublishableKey(options.publishableKey)?.frontendApi || options.frontendApi || "";
    const { apiUrl, frontendApi, pkgVersion, clerkJSVersion, publishableKey, proxyUrl, isSatellite, domain, signInUrl } = options;
    const url = new URL(apiUrl);
    url.pathname = joinPaths(url.pathname, API_VERSION, "/public/interstitial");
    url.searchParams.append("clerk_js_version", clerkJSVersion || getClerkJsMajorVersionOrTag(frontendApi, pkgVersion));
    if (publishableKey) {
        url.searchParams.append("publishable_key", publishableKey);
    } else {
        url.searchParams.append("frontend_api", frontendApi);
    }
    if (proxyUrl) {
        url.searchParams.append("proxy_url", proxyUrl);
    }
    if (isSatellite) {
        url.searchParams.append("is_satellite", "true");
    }
    url.searchParams.append("sign_in_url", signInUrl || "");
    if (!isDevOrStagingUrl(options.frontendApi)) {
        url.searchParams.append("use_domain_for_script", "true");
    }
    if (domain) {
        url.searchParams.append("domain", domain);
    }
    return url.href;
}
// src/util/IsomorphicRequest.ts

// src/utils.ts
var getHeader = (req, key)=>req.headers.get(key);
var getFirstValueFromHeader = (value)=>value?.split(",")[0];
var buildRequestUrl = (request, path)=>{
    const initialUrl = new URL(request.url);
    const forwardedProto = getHeader(request, esm_constants.Headers.ForwardedProto);
    const forwardedHost = getHeader(request, esm_constants.Headers.ForwardedHost);
    const host = getHeader(request, esm_constants.Headers.Host);
    const protocol = initialUrl.protocol;
    const base = buildOrigin({
        protocol,
        forwardedProto,
        forwardedHost,
        host: host || initialUrl.host
    });
    return new URL(path || initialUrl.pathname, base);
};
var buildOrigin = ({ protocol, forwardedProto, forwardedHost, host })=>{
    const resolvedHost = getFirstValueFromHeader(forwardedHost) ?? host;
    const resolvedProtocol = getFirstValueFromHeader(forwardedProto) ?? protocol?.replace(/[:/]/, "");
    if (!resolvedHost || !resolvedProtocol) {
        return "";
    }
    return `${resolvedProtocol}://${resolvedHost}`;
};
// src/util/IsomorphicRequest.ts
var createIsomorphicRequest = (cb)=>{
    const req = cb(runtime_default.Request, runtime_default.Headers);
    const headersGeneratedURL = buildRequestUrl(req);
    return new runtime_default.Request(headersGeneratedURL, req);
};
var buildRequest2 = (req)=>{
    if (!req) {
        return {};
    }
    const cookies = parseIsomorphicRequestCookies(req);
    const headers = getHeaderFromIsomorphicRequest(req);
    const searchParams = getSearchParamsFromIsomorphicRequest(req);
    return {
        cookies,
        headers,
        searchParams
    };
};
var decode = (str)=>{
    if (!str) {
        return str;
    }
    return str.replace(/(%[0-9A-Z]{2})+/g, decodeURIComponent);
};
var parseIsomorphicRequestCookies = (req)=>{
    const cookies = req.headers && req.headers?.get("cookie") ? (0,cookie/* parse */.Q)(req.headers.get("cookie")) : {};
    return (key)=>{
        const value = cookies?.[key];
        if (value === void 0) {
            return void 0;
        }
        return decode(value);
    };
};
var getHeaderFromIsomorphicRequest = (req)=>(key)=>req?.headers?.get(key) || void 0;
var getSearchParamsFromIsomorphicRequest = (req)=>req?.url ? new URL(req.url)?.searchParams : void 0;
var stripAuthorizationHeader = (authValue)=>{
    return authValue?.replace("Bearer ", "");
};
// src/tokens/authStatus.ts
var AuthStatus = /* @__PURE__ */ ((AuthStatus2)=>{
    AuthStatus2["SignedIn"] = "signed-in";
    AuthStatus2["SignedOut"] = "signed-out";
    AuthStatus2["Interstitial"] = "interstitial";
    AuthStatus2["Unknown"] = "unknown";
    return AuthStatus2;
})(AuthStatus || {});
async function signedIn(options, sessionClaims) {
    const { apiKey, secretKey, apiUrl, apiVersion, cookieToken, frontendApi, proxyUrl, publishableKey, domain, isSatellite, headerToken, loadSession, loadUser, loadOrganization, signInUrl, signUpUrl, afterSignInUrl, afterSignUpUrl, token } = options;
    const { sid: sessionId, org_id: orgId, sub: userId } = sessionClaims;
    const { sessions, users, organizations } = createBackendApiClient({
        apiKey,
        secretKey,
        apiUrl,
        apiVersion
    });
    const [sessionResp, userResp, organizationResp] = await Promise.all([
        loadSession ? sessions.getSession(sessionId) : Promise.resolve(void 0),
        loadUser ? users.getUser(userId) : Promise.resolve(void 0),
        loadOrganization && orgId ? organizations.getOrganization({
            organizationId: orgId
        }) : Promise.resolve(void 0)
    ]);
    const session = sessionResp;
    const user = userResp;
    const organization = organizationResp;
    const authObject = signedInAuthObject(sessionClaims, {
        secretKey,
        apiKey,
        apiUrl,
        apiVersion,
        token: cookieToken || headerToken || "",
        session,
        user,
        organization
    }, {
        ...options,
        status: "signed-in" /* SignedIn */ 
    });
    return {
        status: "signed-in" /* SignedIn */ ,
        reason: null,
        message: null,
        frontendApi,
        proxyUrl,
        publishableKey,
        domain,
        isSatellite,
        signInUrl,
        signUpUrl,
        afterSignInUrl,
        afterSignUpUrl,
        isSignedIn: true,
        isInterstitial: false,
        isUnknown: false,
        toAuth: ()=>authObject,
        token
    };
}
function signedOut(options, reason, message = "") {
    const { frontendApi, publishableKey, proxyUrl, isSatellite, domain, signInUrl, signUpUrl, afterSignInUrl, afterSignUpUrl } = options;
    return {
        status: "signed-out" /* SignedOut */ ,
        reason,
        message,
        frontendApi,
        proxyUrl,
        publishableKey,
        isSatellite,
        domain,
        signInUrl,
        signUpUrl,
        afterSignInUrl,
        afterSignUpUrl,
        isSignedIn: false,
        isInterstitial: false,
        isUnknown: false,
        toAuth: ()=>signedOutAuthObject({
                ...options,
                status: "signed-out" /* SignedOut */ ,
                reason,
                message
            }),
        token: null
    };
}
function interstitial(options, reason, message = "") {
    const { frontendApi, publishableKey, proxyUrl, isSatellite, domain, signInUrl, signUpUrl, afterSignInUrl, afterSignUpUrl } = options;
    return {
        status: "interstitial" /* Interstitial */ ,
        reason,
        message,
        frontendApi,
        publishableKey,
        isSatellite,
        domain,
        proxyUrl,
        signInUrl,
        signUpUrl,
        afterSignInUrl,
        afterSignUpUrl,
        isSignedIn: false,
        isInterstitial: true,
        isUnknown: false,
        toAuth: ()=>null,
        token: null
    };
}
function unknownState(options, reason, message = "") {
    const { frontendApi, publishableKey, isSatellite, domain, signInUrl, signUpUrl, afterSignInUrl, afterSignUpUrl } = options;
    return {
        status: "unknown" /* Unknown */ ,
        reason,
        message,
        frontendApi,
        publishableKey,
        isSatellite,
        domain,
        signInUrl,
        signUpUrl,
        afterSignInUrl,
        afterSignUpUrl,
        isSignedIn: false,
        isInterstitial: false,
        isUnknown: true,
        toAuth: ()=>null,
        token: null
    };
}
// src/util/request.ts
function checkCrossOrigin({ originURL, host, forwardedHost, forwardedProto }) {
    const finalURL = buildOrigin({
        forwardedProto,
        forwardedHost,
        protocol: originURL.protocol,
        host
    });
    return finalURL && new URL(finalURL).origin !== originURL.origin;
}
var getErrorObjectByCode = (errors, code)=>{
    if (!errors) {
        return null;
    }
    return errors.find((err)=>err.code === code);
};
// src/tokens/jwt/verifyJwt.ts

// src/util/rfc4648.ts
var base64url = {
    parse (string, opts) {
        return parse2(string, base64UrlEncoding, opts);
    },
    stringify (data, opts) {
        return stringify(data, base64UrlEncoding, opts);
    }
};
var base64UrlEncoding = {
    chars: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_",
    bits: 6
};
function parse2(string, encoding, opts = {}) {
    if (!encoding.codes) {
        encoding.codes = {};
        for(let i = 0; i < encoding.chars.length; ++i){
            encoding.codes[encoding.chars[i]] = i;
        }
    }
    if (!opts.loose && string.length * encoding.bits & 7) {
        throw new SyntaxError("Invalid padding");
    }
    let end = string.length;
    while(string[end - 1] === "="){
        --end;
        if (!opts.loose && !((string.length - end) * encoding.bits & 7)) {
            throw new SyntaxError("Invalid padding");
        }
    }
    const out = new (opts.out ?? Uint8Array)(end * encoding.bits / 8 | 0);
    let bits = 0;
    let buffer = 0;
    let written = 0;
    for(let i = 0; i < end; ++i){
        const value = encoding.codes[string[i]];
        if (value === void 0) {
            throw new SyntaxError("Invalid character " + string[i]);
        }
        buffer = buffer << encoding.bits | value;
        bits += encoding.bits;
        if (bits >= 8) {
            bits -= 8;
            out[written++] = 255 & buffer >> bits;
        }
    }
    if (bits >= encoding.bits || 255 & buffer << 8 - bits) {
        throw new SyntaxError("Unexpected end of data");
    }
    return out;
}
function stringify(data, encoding, opts = {}) {
    const { pad = true } = opts;
    const mask = (1 << encoding.bits) - 1;
    let out = "";
    let bits = 0;
    let buffer = 0;
    for(let i = 0; i < data.length; ++i){
        buffer = buffer << 8 | 255 & data[i];
        bits += 8;
        while(bits > encoding.bits){
            bits -= encoding.bits;
            out += encoding.chars[mask & buffer >> bits];
        }
    }
    if (bits) {
        out += encoding.chars[mask & buffer << encoding.bits - bits];
    }
    if (pad) {
        while(out.length * encoding.bits & 7){
            out += "=";
        }
    }
    return out;
}
// src/tokens/jwt/algorithms.ts
var algToHash = {
    RS256: "SHA-256",
    RS384: "SHA-384",
    RS512: "SHA-512"
};
var RSA_ALGORITHM_NAME = "RSASSA-PKCS1-v1_5";
var jwksAlgToCryptoAlg = {
    RS256: RSA_ALGORITHM_NAME,
    RS384: RSA_ALGORITHM_NAME,
    RS512: RSA_ALGORITHM_NAME
};
var algs = Object.keys(algToHash);
function getCryptoAlgorithm(algorithmName) {
    const hash = algToHash[algorithmName];
    const name = jwksAlgToCryptoAlg[algorithmName];
    if (!hash || !name) {
        throw new Error(`Unsupported algorithm ${algorithmName}, expected one of ${algs.join(",")}.`);
    }
    return {
        hash: {
            name: algToHash[algorithmName]
        },
        name: jwksAlgToCryptoAlg[algorithmName]
    };
}
// src/tokens/jwt/assertions.ts
var isArrayString = (s)=>{
    return Array.isArray(s) && s.length > 0 && s.every((a)=>typeof a === "string");
};
var assertAudienceClaim = (aud, audience)=>{
    const audienceList = [
        audience
    ].flat().filter((a)=>!!a);
    const audList = [
        aud
    ].flat().filter((a)=>!!a);
    const shouldVerifyAudience = audienceList.length > 0 && audList.length > 0;
    if (!shouldVerifyAudience) {
        return;
    }
    if (typeof aud === "string") {
        if (!audienceList.includes(aud)) {
            throw new TokenVerificationError({
                action: "Make sure that this is a valid Clerk generate JWT." /* EnsureClerkJWT */ ,
                reason: "token-verification-failed" /* TokenVerificationFailed */ ,
                message: `Invalid JWT audience claim (aud) ${JSON.stringify(aud)}. Is not included in "${JSON.stringify(audienceList)}".`
            });
        }
    } else if (isArrayString(aud)) {
        if (!aud.some((a)=>audienceList.includes(a))) {
            throw new TokenVerificationError({
                action: "Make sure that this is a valid Clerk generate JWT." /* EnsureClerkJWT */ ,
                reason: "token-verification-failed" /* TokenVerificationFailed */ ,
                message: `Invalid JWT audience claim array (aud) ${JSON.stringify(aud)}. Is not included in "${JSON.stringify(audienceList)}".`
            });
        }
    }
};
var assertHeaderType = (typ)=>{
    if (typeof typ === "undefined") {
        return;
    }
    if (typ !== "JWT") {
        throw new TokenVerificationError({
            action: "Make sure that this is a valid Clerk generate JWT." /* EnsureClerkJWT */ ,
            reason: "token-invalid" /* TokenInvalid */ ,
            message: `Invalid JWT type ${JSON.stringify(typ)}. Expected "JWT".`
        });
    }
};
var assertHeaderAlgorithm = (alg)=>{
    if (!algs.includes(alg)) {
        throw new TokenVerificationError({
            action: "Make sure that this is a valid Clerk generate JWT." /* EnsureClerkJWT */ ,
            reason: "token-invalid-algorithm" /* TokenInvalidAlgorithm */ ,
            message: `Invalid JWT algorithm ${JSON.stringify(alg)}. Supported: ${algs}.`
        });
    }
};
var assertSubClaim = (sub)=>{
    if (typeof sub !== "string") {
        throw new TokenVerificationError({
            action: "Make sure that this is a valid Clerk generate JWT." /* EnsureClerkJWT */ ,
            reason: "token-verification-failed" /* TokenVerificationFailed */ ,
            message: `Subject claim (sub) is required and must be a string. Received ${JSON.stringify(sub)}.`
        });
    }
};
var assertAuthorizedPartiesClaim = (azp, authorizedParties)=>{
    if (!azp || !authorizedParties || authorizedParties.length === 0) {
        return;
    }
    if (!authorizedParties.includes(azp)) {
        throw new TokenVerificationError({
            reason: "token-invalid-authorized-parties" /* TokenInvalidAuthorizedParties */ ,
            message: `Invalid JWT Authorized party claim (azp) ${JSON.stringify(azp)}. Expected "${authorizedParties}".`
        });
    }
};
var assertIssuerClaim = (iss, issuer)=>{
    if (typeof issuer === "function" && !issuer(iss)) {
        throw new TokenVerificationError({
            reason: "token-invalid-issuer" /* TokenInvalidIssuer */ ,
            message: "Failed JWT issuer resolver. Make sure that the resolver returns a truthy value."
        });
    } else if (typeof issuer === "string" && iss && iss !== issuer) {
        throw new TokenVerificationError({
            reason: "token-invalid-issuer" /* TokenInvalidIssuer */ ,
            message: `Invalid JWT issuer claim (iss) ${JSON.stringify(iss)}. Expected "${issuer}".`
        });
    }
};
var assertExpirationClaim = (exp, clockSkewInMs)=>{
    if (typeof exp !== "number") {
        throw new TokenVerificationError({
            action: "Make sure that this is a valid Clerk generate JWT." /* EnsureClerkJWT */ ,
            reason: "token-verification-failed" /* TokenVerificationFailed */ ,
            message: `Invalid JWT expiry date claim (exp) ${JSON.stringify(exp)}. Expected number.`
        });
    }
    const currentDate = new Date(Date.now());
    const expiryDate = /* @__PURE__ */ new Date(0);
    expiryDate.setUTCSeconds(exp);
    const expired = expiryDate.getTime() <= currentDate.getTime() - clockSkewInMs;
    if (expired) {
        throw new TokenVerificationError({
            reason: "token-expired" /* TokenExpired */ ,
            message: `JWT is expired. Expiry date: ${expiryDate.toUTCString()}, Current date: ${currentDate.toUTCString()}.`
        });
    }
};
var assertActivationClaim = (nbf, clockSkewInMs)=>{
    if (typeof nbf === "undefined") {
        return;
    }
    if (typeof nbf !== "number") {
        throw new TokenVerificationError({
            action: "Make sure that this is a valid Clerk generate JWT." /* EnsureClerkJWT */ ,
            reason: "token-verification-failed" /* TokenVerificationFailed */ ,
            message: `Invalid JWT not before date claim (nbf) ${JSON.stringify(nbf)}. Expected number.`
        });
    }
    const currentDate = new Date(Date.now());
    const notBeforeDate = /* @__PURE__ */ new Date(0);
    notBeforeDate.setUTCSeconds(nbf);
    const early = notBeforeDate.getTime() > currentDate.getTime() + clockSkewInMs;
    if (early) {
        throw new TokenVerificationError({
            reason: "token-not-active-yet" /* TokenNotActiveYet */ ,
            message: `JWT cannot be used prior to not before date claim (nbf). Not before date: ${notBeforeDate.toUTCString()}; Current date: ${currentDate.toUTCString()};`
        });
    }
};
var assertIssuedAtClaim = (iat, clockSkewInMs)=>{
    if (typeof iat === "undefined") {
        return;
    }
    if (typeof iat !== "number") {
        throw new TokenVerificationError({
            action: "Make sure that this is a valid Clerk generate JWT." /* EnsureClerkJWT */ ,
            reason: "token-verification-failed" /* TokenVerificationFailed */ ,
            message: `Invalid JWT issued at date claim (iat) ${JSON.stringify(iat)}. Expected number.`
        });
    }
    const currentDate = new Date(Date.now());
    const issuedAtDate = /* @__PURE__ */ new Date(0);
    issuedAtDate.setUTCSeconds(iat);
    const postIssued = issuedAtDate.getTime() > currentDate.getTime() + clockSkewInMs;
    if (postIssued) {
        throw new TokenVerificationError({
            reason: "token-not-active-yet" /* TokenNotActiveYet */ ,
            message: `JWT issued at date claim (iat) is in the future. Issued at date: ${issuedAtDate.toUTCString()}; Current date: ${currentDate.toUTCString()};`
        });
    }
};
// src/tokens/jwt/cryptoKeys.ts

function pemToBuffer(secret) {
    const trimmed = secret.replace(/-----BEGIN.*?-----/g, "").replace(/-----END.*?-----/g, "").replace(/\s/g, "");
    const decoded = isomorphicAtob(trimmed);
    const buffer = new ArrayBuffer(decoded.length);
    const bufView = new Uint8Array(buffer);
    for(let i = 0, strLen = decoded.length; i < strLen; i++){
        bufView[i] = decoded.charCodeAt(i);
    }
    return bufView;
}
function importKey(key, algorithm, keyUsage) {
    if (typeof key === "object") {
        return runtime_default.crypto.subtle.importKey("jwk", key, algorithm, false, [
            keyUsage
        ]);
    }
    const keyData = pemToBuffer(key);
    const format = keyUsage === "sign" ? "pkcs8" : "spki";
    return runtime_default.crypto.subtle.importKey(format, keyData, algorithm, false, [
        keyUsage
    ]);
}
// src/tokens/jwt/verifyJwt.ts
var DEFAULT_CLOCK_SKEW_IN_SECONDS = 5 * 1e3;
async function hasValidSignature(jwt, key) {
    const { header, signature, raw } = jwt;
    const encoder = new TextEncoder();
    const data = encoder.encode([
        raw.header,
        raw.payload
    ].join("."));
    const algorithm = getCryptoAlgorithm(header.alg);
    const cryptoKey = await importKey(key, algorithm, "verify");
    return runtime_default.crypto.subtle.verify(algorithm.name, cryptoKey, signature, data);
}
function decodeJwt(token) {
    const tokenParts = (token || "").toString().split(".");
    if (tokenParts.length !== 3) {
        throw new TokenVerificationError({
            reason: "token-invalid" /* TokenInvalid */ ,
            message: `Invalid JWT form. A JWT consists of three parts separated by dots.`
        });
    }
    const [rawHeader, rawPayload, rawSignature] = tokenParts;
    const decoder = new TextDecoder();
    const header = JSON.parse(decoder.decode(base64url.parse(rawHeader, {
        loose: true
    })));
    const payload = JSON.parse(decoder.decode(base64url.parse(rawPayload, {
        loose: true
    })));
    const signature = base64url.parse(rawSignature, {
        loose: true
    });
    deprecatedObjectProperty(payload, "orgs", 'Add orgs to your session token using the "user.organizations" shortcode in JWT Templates instead.', "decodeJwt:orgs");
    return {
        header,
        payload,
        signature,
        raw: {
            header: rawHeader,
            payload: rawPayload,
            signature: rawSignature,
            text: token
        }
    };
}
async function verifyJwt(token, { audience, authorizedParties, clockSkewInSeconds, clockSkewInMs, issuer, key }) {
    if (clockSkewInSeconds) {
        chunk_KJVJ4CFF_deprecated("clockSkewInSeconds", "Use `clockSkewInMs` instead.");
    }
    const clockSkew = clockSkewInMs || clockSkewInSeconds || DEFAULT_CLOCK_SKEW_IN_SECONDS;
    const decoded = decodeJwt(token);
    const { header, payload } = decoded;
    const { typ, alg } = header;
    assertHeaderType(typ);
    assertHeaderAlgorithm(alg);
    const { azp, sub, aud, iss, iat, exp, nbf } = payload;
    assertSubClaim(sub);
    assertAudienceClaim([
        aud
    ], [
        audience
    ]);
    assertAuthorizedPartiesClaim(azp, authorizedParties);
    assertIssuerClaim(iss, issuer);
    assertExpirationClaim(exp, clockSkew);
    assertActivationClaim(nbf, clockSkew);
    assertIssuedAtClaim(iat, clockSkew);
    let signatureValid;
    try {
        signatureValid = await hasValidSignature(decoded, key);
    } catch (err) {
        throw new TokenVerificationError({
            action: "Make sure that this is a valid Clerk generate JWT." /* EnsureClerkJWT */ ,
            reason: "token-verification-failed" /* TokenVerificationFailed */ ,
            message: `Error verifying JWT signature. ${err}`
        });
    }
    if (!signatureValid) {
        throw new TokenVerificationError({
            reason: "token-invalid-signature" /* TokenInvalidSignature */ ,
            message: "JWT signature is invalid."
        });
    }
    return payload;
}
// src/tokens/jwt/signJwt.ts
function encodeJwtData(value) {
    const stringified = JSON.stringify(value);
    const encoder = new TextEncoder();
    const encoded = encoder.encode(stringified);
    return base64url.stringify(encoded, {
        pad: false
    });
}
async function signJwt(payload, key, options) {
    if (!options.algorithm) {
        throw new Error("No algorithm specified");
    }
    const encoder = new TextEncoder();
    const algorithm = getCryptoAlgorithm(options.algorithm);
    if (!algorithm) {
        throw new Error(`Unsupported algorithm ${options.algorithm}`);
    }
    const cryptoKey = await importKey(key, algorithm, "sign");
    const header = options.header || {
        typ: "JWT"
    };
    header.alg = options.algorithm;
    payload.iat = Math.floor(Date.now() / 1e3);
    const encodedHeader = encodeJwtData(header);
    const encodedPayload = encodeJwtData(payload);
    const firstPart = `${encodedHeader}.${encodedPayload}`;
    const signature = await runtime_default.crypto.subtle.sign(algorithm, cryptoKey, encoder.encode(firstPart));
    return `${firstPart}.${base64url.stringify(new Uint8Array(signature), {
        pad: false
    })}`;
}
// src/tokens/keys.ts
var cache = {};
var lastUpdatedAt = 0;
function getFromCache(kid) {
    return cache[kid];
}
function getCacheValues() {
    return Object.values(cache);
}
function setInCache(jwk, jwksCacheTtlInMs = 1e3 * 60 * 60) {
    cache[jwk.kid] = jwk;
    lastUpdatedAt = Date.now();
    if (jwksCacheTtlInMs >= 0) {
        setTimeout(()=>{
            if (jwk) {
                delete cache[jwk.kid];
            } else {
                cache = {};
            }
        }, jwksCacheTtlInMs);
    }
}
var LocalJwkKid = "local";
var PEM_HEADER = "-----BEGIN PUBLIC KEY-----";
var PEM_TRAILER = "-----END PUBLIC KEY-----";
var RSA_PREFIX = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA";
var RSA_SUFFIX = "IDAQAB";
function loadClerkJWKFromLocal(localKey) {
    if (!getFromCache(LocalJwkKid)) {
        if (!localKey) {
            throw new TokenVerificationError({
                action: "Set the CLERK_JWT_KEY environment variable." /* SetClerkJWTKey */ ,
                message: "Missing local JWK.",
                reason: "jwk-local-missing" /* LocalJWKMissing */ 
            });
        }
        const modulus = localKey.replace(/(\r\n|\n|\r)/gm, "").replace(PEM_HEADER, "").replace(PEM_TRAILER, "").replace(RSA_PREFIX, "").replace(RSA_SUFFIX, "").replace(/\+/g, "-").replace(/\//g, "_");
        setInCache({
            kid: "local",
            kty: "RSA",
            alg: "RS256",
            n: modulus,
            e: "AQAB"
        }, -1);
    }
    return getFromCache(LocalJwkKid);
}
async function loadClerkJWKFromRemote({ apiKey, secretKey, apiUrl = API_URL, apiVersion = API_VERSION, issuer, kid, jwksCacheTtlInMs = 1e3 * 60 * 60, // 1 hour,
skipJwksCache }) {
    const shouldRefreshCache = !getFromCache(kid) && reachedMaxCacheUpdatedAt();
    if (skipJwksCache || shouldRefreshCache) {
        let fetcher;
        const key = secretKey || apiKey;
        if (key) {
            fetcher = ()=>fetchJWKSFromBAPI(apiUrl, key, apiVersion);
        } else if (issuer) {
            fetcher = ()=>fetchJWKSFromFAPI(issuer);
        } else {
            throw new TokenVerificationError({
                action: "Contact support@clerk.com" /* ContactSupport */ ,
                message: "Failed to load JWKS from Clerk Backend or Frontend API.",
                reason: "jwk-remote-failed-to-load" /* RemoteJWKFailedToLoad */ 
            });
        }
        const { keys } = await callWithRetry(fetcher);
        if (!keys || !keys.length) {
            throw new TokenVerificationError({
                action: "Contact support@clerk.com" /* ContactSupport */ ,
                message: "The JWKS endpoint did not contain any signing keys. Contact support@clerk.com.",
                reason: "jwk-remote-failed-to-load" /* RemoteJWKFailedToLoad */ 
            });
        }
        keys.forEach((key2)=>setInCache(key2, jwksCacheTtlInMs));
    }
    const jwk = getFromCache(kid);
    if (!jwk) {
        const cacheValues = getCacheValues();
        const jwkKeys = cacheValues.map((jwk2)=>jwk2.kid).join(", ");
        throw new TokenVerificationError({
            action: "Contact support@clerk.com" /* ContactSupport */ ,
            message: `Unable to find a signing key in JWKS that matches the kid='${kid}' of the provided session token. Please make sure that the __session cookie or the HTTP authorization header contain a Clerk-generated session JWT.${jwkKeys ? ` The following kid are available: ${jwkKeys}` : ""}`,
            reason: "jwk-remote-missing" /* RemoteJWKMissing */ 
        });
    }
    return jwk;
}
async function fetchJWKSFromFAPI(issuer) {
    const url = new URL(issuer);
    url.pathname = joinPaths(url.pathname, ".well-known/jwks.json");
    const response = await runtime_default.fetch(url.href);
    if (!response.ok) {
        throw new TokenVerificationError({
            action: "Contact support@clerk.com" /* ContactSupport */ ,
            message: `Error loading Clerk JWKS from ${url.href} with code=${response.status}`,
            reason: "jwk-remote-failed-to-load" /* RemoteJWKFailedToLoad */ 
        });
    }
    return response.json();
}
async function fetchJWKSFromBAPI(apiUrl, key, apiVersion) {
    if (!key) {
        throw new TokenVerificationError({
            action: "Set the CLERK_SECRET_KEY or CLERK_API_KEY environment variable." /* SetClerkSecretKeyOrAPIKey */ ,
            message: "Missing Clerk Secret Key or API Key. Go to https://dashboard.clerk.com and get your key for your instance.",
            reason: "jwk-remote-failed-to-load" /* RemoteJWKFailedToLoad */ 
        });
    }
    const url = new URL(apiUrl);
    url.pathname = joinPaths(url.pathname, apiVersion, "/jwks");
    const response = await runtime_default.fetch(url.href, {
        headers: {
            Authorization: `Bearer ${key}`,
            "Content-Type": "application/json"
        }
    });
    if (!response.ok) {
        const json = await response.json();
        const invalidSecretKeyError = getErrorObjectByCode(json?.errors, "clerk_key_invalid" /* InvalidSecretKey */ );
        if (invalidSecretKeyError) {
            const reason = "secret-key-invalid" /* InvalidSecretKey */ ;
            throw new TokenVerificationError({
                action: "Contact support@clerk.com" /* ContactSupport */ ,
                message: invalidSecretKeyError.message,
                reason
            });
        }
        throw new TokenVerificationError({
            action: "Contact support@clerk.com" /* ContactSupport */ ,
            message: `Error loading Clerk JWKS from ${url.href} with code=${response.status}`,
            reason: "jwk-remote-failed-to-load" /* RemoteJWKFailedToLoad */ 
        });
    }
    return response.json();
}
function reachedMaxCacheUpdatedAt() {
    return Date.now() - lastUpdatedAt >= MAX_CACHE_LAST_UPDATED_AT_SECONDS * 1e3;
}
// src/tokens/verify.ts
async function verifyToken(token, options) {
    const { apiKey, secretKey, apiUrl, apiVersion, audience, authorizedParties, clockSkewInSeconds, clockSkewInMs, issuer, jwksCacheTtlInMs, jwtKey, skipJwksCache } = options;
    if (options.apiKey) {
        chunk_KJVJ4CFF_deprecated("apiKey", "Use `secretKey` instead.");
    }
    const { header } = decodeJwt(token);
    const { kid } = header;
    let key;
    if (jwtKey) {
        key = loadClerkJWKFromLocal(jwtKey);
    } else if (typeof issuer === "string") {
        key = await loadClerkJWKFromRemote({
            issuer,
            kid,
            jwksCacheTtlInMs,
            skipJwksCache
        });
    } else if (apiKey || secretKey) {
        key = await loadClerkJWKFromRemote({
            apiKey,
            secretKey,
            apiUrl,
            apiVersion,
            kid,
            jwksCacheTtlInMs,
            skipJwksCache
        });
    } else {
        throw new TokenVerificationError({
            action: "Set the CLERK_JWT_KEY environment variable." /* SetClerkJWTKey */ ,
            message: "Failed to resolve JWK during verification.",
            reason: "jwk-failed-to-resolve" /* JWKFailedToResolve */ 
        });
    }
    return await verifyJwt(token, {
        audience,
        authorizedParties,
        clockSkewInSeconds,
        clockSkewInMs,
        key,
        issuer
    });
}
// src/tokens/interstitialRule.ts
var shouldRedirectToSatelliteUrl = (qp)=>!!qp?.get("__clerk_satellite_url");
var hasJustSynced = (qp)=>qp?.get("__clerk_synced") === "true";
var VALID_USER_AGENTS = /^Mozilla\/|(Amazon CloudFront)/;
var isBrowser = (userAgent)=>VALID_USER_AGENTS.test(userAgent || "");
var nonBrowserRequestInDevRule = (options)=>{
    const { apiKey, secretKey, userAgent } = options;
    const key = secretKey || apiKey || "";
    if (isDevelopmentFromApiKey(key) && !isBrowser(userAgent)) {
        return signedOut(options, "header-missing-non-browser" /* HeaderMissingNonBrowser */ );
    }
    return void 0;
};
var crossOriginRequestWithoutHeader = (options)=>{
    const { origin, host, forwardedHost, forwardedProto } = options;
    const isCrossOrigin = origin && checkCrossOrigin({
        originURL: new URL(origin),
        host,
        forwardedHost,
        forwardedProto
    });
    if (isCrossOrigin) {
        return signedOut(options, "header-missing-cors" /* HeaderMissingCORS */ );
    }
    return void 0;
};
var isPrimaryInDevAndRedirectsToSatellite = (options)=>{
    const { apiKey, secretKey, isSatellite, searchParams } = options;
    const key = secretKey || apiKey || "";
    const isDev = isDevelopmentFromApiKey(key);
    if (isDev && !isSatellite && shouldRedirectToSatelliteUrl(searchParams)) {
        return interstitial(options, "primary-responds-to-syncing" /* PrimaryRespondsToSyncing */ );
    }
    return void 0;
};
var potentialFirstLoadInDevWhenUATMissing = (options)=>{
    const { apiKey, secretKey, clientUat } = options;
    const key = secretKey || apiKey || "";
    const res = isDevelopmentFromApiKey(key);
    if (res && !clientUat) {
        return interstitial(options, "uat-missing" /* CookieUATMissing */ );
    }
    return void 0;
};
var potentialRequestAfterSignInOrOutFromClerkHostedUiInDev = (options)=>{
    const { apiKey, secretKey, referrer, host, forwardedHost, forwardedProto } = options;
    const crossOriginReferrer = referrer && checkCrossOrigin({
        originURL: new URL(referrer),
        host,
        forwardedHost,
        forwardedProto
    });
    const key = secretKey || apiKey || "";
    if (isDevelopmentFromApiKey(key) && crossOriginReferrer) {
        return interstitial(options, "cross-origin-referrer" /* CrossOriginReferrer */ );
    }
    return void 0;
};
var potentialFirstRequestOnProductionEnvironment = (options)=>{
    const { apiKey, secretKey, clientUat, cookieToken } = options;
    const key = secretKey || apiKey || "";
    if (isProductionFromApiKey(key) && !clientUat && !cookieToken) {
        return signedOut(options, "cookie-and-uat-missing" /* CookieAndUATMissing */ );
    }
    return void 0;
};
var isNormalSignedOutState = (options)=>{
    const { clientUat } = options;
    if (clientUat === "0") {
        return signedOut(options, "standard-signed-out" /* StandardSignedOut */ );
    }
    return void 0;
};
var hasPositiveClientUatButCookieIsMissing = (options)=>{
    const { clientUat, cookieToken } = options;
    if (clientUat && Number.parseInt(clientUat) > 0 && !cookieToken) {
        return interstitial(options, "cookie-missing" /* CookieMissing */ );
    }
    return void 0;
};
var hasValidHeaderToken = async (options)=>{
    const { headerToken } = options;
    const sessionClaims = await verifyRequestState(options, headerToken);
    return await signedIn({
        ...options,
        token: headerToken
    }, sessionClaims);
};
var hasValidCookieToken = async (options)=>{
    const { cookieToken, clientUat } = options;
    const sessionClaims = await verifyRequestState(options, cookieToken);
    const state = await signedIn({
        ...options,
        token: cookieToken
    }, sessionClaims);
    const jwt = state.toAuth().sessionClaims;
    const cookieTokenIsOutdated = jwt.iat < Number.parseInt(clientUat);
    if (!clientUat || cookieTokenIsOutdated) {
        return interstitial(options, "cookie-outdated" /* CookieOutDated */ );
    }
    return state;
};
async function runInterstitialRules(opts, rules) {
    for (const rule of rules){
        const res = await rule(opts);
        if (res) {
            return res;
        }
    }
    return signedOut(opts, "unexpected-error" /* UnexpectedError */ );
}
async function verifyRequestState(options, token) {
    const { isSatellite, proxyUrl } = options;
    let issuer;
    if (isSatellite) {
        issuer = null;
    } else if (proxyUrl) {
        issuer = proxyUrl;
    } else {
        issuer = (iss)=>iss.startsWith("https://clerk.") || iss.includes(".clerk.accounts");
    }
    return verifyToken(token, {
        ...options,
        issuer
    });
}
var isSatelliteAndNeedsSyncing = (options)=>{
    const { clientUat, isSatellite, searchParams, userAgent } = options;
    const isSignedOut = !clientUat || clientUat === "0";
    if (isSatellite && isSignedOut && !isBrowser(userAgent)) {
        return signedOut(options, "satellite-needs-syncing" /* SatelliteCookieNeedsSyncing */ );
    }
    if (isSatellite && isSignedOut && !hasJustSynced(searchParams)) {
        return interstitial(options, "satellite-needs-syncing" /* SatelliteCookieNeedsSyncing */ );
    }
    return void 0;
};
// src/tokens/request.ts
function assertSignInUrlExists(signInUrl, key) {
    if (!signInUrl && isDevelopmentFromApiKey(key)) {
        throw new Error(`Missing signInUrl. Pass a signInUrl for dev instances if an app is satellite`);
    }
}
function assertProxyUrlOrDomain(proxyUrlOrDomain) {
    if (!proxyUrlOrDomain) {
        throw new Error(`Missing domain and proxyUrl. A satellite application needs to specify a domain or a proxyUrl`);
    }
}
function assertSignInUrlFormatAndOrigin(_signInUrl, origin) {
    let signInUrl;
    try {
        signInUrl = new URL(_signInUrl);
    } catch  {
        throw new Error(`The signInUrl needs to have a absolute url format.`);
    }
    if (signInUrl.origin === origin) {
        throw new Error(`The signInUrl needs to be on a different origin than your satellite application.`);
    }
}
async function authenticateRequest(options) {
    const { cookies, headers, searchParams } = buildRequest2(options?.request);
    if (options.frontendApi) {
        chunk_KJVJ4CFF_deprecated("frontendApi", "Use `publishableKey` instead.");
    }
    if (options.apiKey) {
        chunk_KJVJ4CFF_deprecated("apiKey", "Use `secretKey` instead.");
    }
    options = {
        ...options,
        ...loadOptionsFromHeaders(options, headers),
        frontendApi: chunk_IAZRYRAH_parsePublishableKey(options.publishableKey)?.frontendApi || options.frontendApi,
        apiUrl: options.apiUrl || API_URL,
        apiVersion: options.apiVersion || API_VERSION,
        cookieToken: options.cookieToken || cookies?.(esm_constants.Cookies.Session),
        clientUat: options.clientUat || cookies?.(esm_constants.Cookies.ClientUat),
        searchParams: options.searchParams || searchParams || void 0
    };
    assertValidSecretKey(options.secretKey || options.apiKey);
    if (options.isSatellite) {
        assertSignInUrlExists(options.signInUrl, options.secretKey || options.apiKey);
        if (options.signInUrl && options.origin) {
            assertSignInUrlFormatAndOrigin(options.signInUrl, options.origin);
        }
        assertProxyUrlOrDomain(options.proxyUrl || options.domain);
    }
    async function authenticateRequestWithTokenInHeader() {
        try {
            const state = await runInterstitialRules(options, [
                hasValidHeaderToken
            ]);
            return state;
        } catch (err) {
            return handleError(err, "header");
        }
    }
    async function authenticateRequestWithTokenInCookie() {
        try {
            const state = await runInterstitialRules(options, [
                crossOriginRequestWithoutHeader,
                nonBrowserRequestInDevRule,
                isSatelliteAndNeedsSyncing,
                isPrimaryInDevAndRedirectsToSatellite,
                potentialFirstRequestOnProductionEnvironment,
                potentialFirstLoadInDevWhenUATMissing,
                potentialRequestAfterSignInOrOutFromClerkHostedUiInDev,
                hasPositiveClientUatButCookieIsMissing,
                isNormalSignedOutState,
                hasValidCookieToken
            ]);
            return state;
        } catch (err) {
            return handleError(err, "cookie");
        }
    }
    function handleError(err, tokenCarrier) {
        if (err instanceof TokenVerificationError) {
            err.tokenCarrier = tokenCarrier;
            const reasonToReturnInterstitial = [
                "token-expired" /* TokenExpired */ ,
                "token-not-active-yet" /* TokenNotActiveYet */ 
            ].includes(err.reason);
            if (reasonToReturnInterstitial) {
                if (tokenCarrier === "header") {
                    return unknownState(options, err.reason, err.getFullMessage());
                }
                return interstitial(options, err.reason, err.getFullMessage());
            }
            return signedOut(options, err.reason, err.getFullMessage());
        }
        return signedOut(options, "unexpected-error" /* UnexpectedError */ , err.message);
    }
    if (options.headerToken) {
        return authenticateRequestWithTokenInHeader();
    }
    return authenticateRequestWithTokenInCookie();
}
var debugRequestState = (params)=>{
    const { frontendApi, isSignedIn, proxyUrl, isInterstitial, reason, message, publishableKey, isSatellite, domain } = params;
    return {
        frontendApi,
        isSignedIn,
        proxyUrl,
        isInterstitial,
        reason,
        message,
        publishableKey,
        isSatellite,
        domain
    };
};
var loadOptionsFromHeaders = (options, headers)=>{
    if (!headers) {
        return {};
    }
    return {
        headerToken: stripAuthorizationHeader(options.headerToken || headers(esm_constants.Headers.Authorization)),
        origin: options.origin || headers(esm_constants.Headers.Origin),
        host: options.host || headers(esm_constants.Headers.Host),
        forwardedHost: options.forwardedHost || headers(esm_constants.Headers.ForwardedHost),
        forwardedPort: options.forwardedPort || headers(esm_constants.Headers.ForwardedPort),
        forwardedProto: options.forwardedProto || headers(esm_constants.Headers.CloudFrontForwardedProto) || headers(esm_constants.Headers.ForwardedProto),
        referrer: options.referrer || headers(esm_constants.Headers.Referrer),
        userAgent: options.userAgent || headers(esm_constants.Headers.UserAgent)
    };
};
// src/tokens/factory.ts
function createAuthenticateRequest(params) {
    const { apiClient } = params;
    const { apiKey: buildtimeApiKey = "", secretKey: buildtimeSecretKey = "", jwtKey: buildtimeJwtKey = "", apiUrl = API_URL, apiVersion = API_VERSION, frontendApi: buildtimeFrontendApi = "", proxyUrl: buildProxyUrl = "", publishableKey: buildtimePublishableKey = "", isSatellite: buildtimeIsSatellite = false, domain: buildtimeDomain = "", audience: buildtimeAudience = "", userAgent: buildUserAgent } = params.options;
    const authenticateRequest2 = ({ apiKey: runtimeApiKey, secretKey: runtimeSecretKey, audience: runtimeAudience, frontendApi: runtimeFrontendApi, proxyUrl: runtimeProxyUrl, publishableKey: runtimePublishableKey, jwtKey: runtimeJwtKey, isSatellite: runtimeIsSatellite, domain: runtimeDomain, searchParams, ...rest })=>{
        return authenticateRequest({
            ...rest,
            apiKey: runtimeApiKey || buildtimeApiKey,
            secretKey: runtimeSecretKey || buildtimeSecretKey,
            audience: runtimeAudience || buildtimeAudience,
            apiUrl,
            apiVersion,
            frontendApi: runtimeFrontendApi || buildtimeFrontendApi,
            proxyUrl: runtimeProxyUrl || buildProxyUrl,
            publishableKey: runtimePublishableKey || buildtimePublishableKey,
            isSatellite: runtimeIsSatellite || buildtimeIsSatellite,
            domain: runtimeDomain || buildtimeDomain,
            jwtKey: runtimeJwtKey || buildtimeJwtKey,
            searchParams
        });
    };
    const localInterstitial = ({ frontendApi: runtimeFrontendApi, publishableKey: runtimePublishableKey, proxyUrl: runtimeProxyUrl, isSatellite: runtimeIsSatellite, domain: runtimeDomain, ...rest })=>loadInterstitialFromLocal({
            ...rest,
            frontendApi: runtimeFrontendApi || buildtimeFrontendApi,
            proxyUrl: runtimeProxyUrl || buildProxyUrl,
            publishableKey: runtimePublishableKey || buildtimePublishableKey,
            isSatellite: runtimeIsSatellite || buildtimeIsSatellite,
            domain: runtimeDomain || buildtimeDomain
        });
    const remotePublicInterstitial = ({ frontendApi: runtimeFrontendApi, publishableKey: runtimePublishableKey, proxyUrl: runtimeProxyUrl, isSatellite: runtimeIsSatellite, domain: runtimeDomain, userAgent: runtimeUserAgent, ...rest })=>{
        return loadInterstitialFromBAPI({
            ...rest,
            apiUrl,
            frontendApi: runtimeFrontendApi || buildtimeFrontendApi,
            publishableKey: runtimePublishableKey || buildtimePublishableKey,
            proxyUrl: runtimeProxyUrl || buildProxyUrl,
            isSatellite: runtimeIsSatellite || buildtimeIsSatellite,
            domain: runtimeDomain || buildtimeDomain,
            userAgent: runtimeUserAgent || buildUserAgent
        });
    };
    const remotePublicInterstitialUrl = buildPublicInterstitialUrl;
    const remotePrivateInterstitial = ()=>apiClient.interstitial.getInterstitial();
    return {
        authenticateRequest: authenticateRequest2,
        localInterstitial,
        remotePublicInterstitial,
        remotePrivateInterstitial,
        remotePublicInterstitialUrl,
        debugRequestState
    };
}
// src/redirections.ts
var buildUrl = (targetUrl, redirectUrl)=>{
    let url;
    if (!targetUrl.startsWith("http")) {
        if (!redirectUrl || !redirectUrl.startsWith("http")) {
            throw new Error("destination url or return back url should be an absolute path url!");
        }
        const baseURL = new URL(redirectUrl);
        url = new URL(targetUrl, baseURL.origin);
    } else {
        url = new URL(targetUrl);
    }
    if (redirectUrl) {
        url.searchParams.set("redirect_url", redirectUrl);
    }
    return url.toString();
};
function redirect({ redirectAdapter, signUpUrl, signInUrl, frontendApi, publishableKey }) {
    if (!frontendApi) {
        frontendApi = parsePublishableKey(publishableKey)?.frontendApi;
    } else {
        deprecated2("frontendApi", "Use `publishableKey` instead.");
    }
    const accountsBaseUrl = buildAccountsBaseUrl(frontendApi);
    const redirectToSignUp = ({ returnBackUrl } = {})=>{
        if (!signUpUrl && !accountsBaseUrl) {
            errorThrower.throwMissingPublishableKeyError();
        }
        const accountsSignUpUrl = `${accountsBaseUrl}/sign-up`;
        return redirectAdapter(buildUrl(signUpUrl || accountsSignUpUrl, returnBackUrl));
    };
    const redirectToSignIn = ({ returnBackUrl } = {})=>{
        if (!signInUrl && !accountsBaseUrl) {
            errorThrower.throwMissingPublishableKeyError();
        }
        const accountsSignInUrl = `${accountsBaseUrl}/sign-in`;
        return redirectAdapter(buildUrl(signInUrl || accountsSignInUrl, returnBackUrl));
    };
    return {
        redirectToSignUp,
        redirectToSignIn
    };
}
function buildAccountsBaseUrl(frontendApi) {
    if (!frontendApi) {
        return "";
    }
    const accountsBaseUrl = frontendApi.replace(/(clerk\.accountsstage\.)/, "accountsstage.").replace(/(clerk\.accounts\.|clerk\.)/, "accounts.");
    return `https://${accountsBaseUrl}`;
}
// src/index.ts
function esm_Clerk(options) {
    const opts = {
        ...options
    };
    const apiClient = createBackendApiClient(opts);
    const requestState = createAuthenticateRequest({
        options: opts,
        apiClient
    });
    const clerkInstance = {
        ...apiClient,
        ...requestState,
        /**
     * @deprecated This prop has been deprecated and will be removed in the next major release.
     */ __unstable_options: opts
    };
    deprecatedObjectProperty(clerkInstance, "__unstable_options", "Use `createClerkClient({...})` to create a new clerk instance instead.");
    return clerkInstance;
}
 //# sourceMappingURL=index.js.map

;// CONCATENATED MODULE: ./node_modules/next/dist/esm/server/web/exports/next-response.js
// This file is for modularized imports for next/server to get fully-treeshaking.
 //# sourceMappingURL=next-response.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/constants.js

const JS_VERSION = process.env.CLERK_JS_VERSION || "";
if (JS_VERSION) {
    chunk_KJVJ4CFF_deprecated("CLERK_JS_VERSION", "Use `NEXT_PUBLIC_CLERK_JS_VERSION` environment variable instead.");
}
const CLERK_JS_VERSION = process.env.NEXT_PUBLIC_CLERK_JS_VERSION || "";
const CLERK_JS_URL = process.env.NEXT_PUBLIC_CLERK_JS || "";
const constants_API_URL = process.env.CLERK_API_URL || "https://api.clerk.dev";
const constants_API_VERSION = process.env.CLERK_API_VERSION || "v1";
const API_KEY = process.env.CLERK_API_KEY || "";
if (API_KEY) {
    chunk_KJVJ4CFF_deprecated("CLERK_API_KEY", "Use `CLERK_SECRET_KEY` environment variable instead.");
}
const SECRET_KEY = process.env.CLERK_SECRET_KEY || "";
const FRONTEND_API = process.env.NEXT_PUBLIC_CLERK_FRONTEND_API || "";
if (FRONTEND_API) {
    chunk_KJVJ4CFF_deprecated("NEXT_PUBLIC_CLERK_FRONTEND_API", "Use `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` environment variable instead.");
}
const PUBLISHABLE_KEY = process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY || "";
const DOMAIN = process.env.NEXT_PUBLIC_CLERK_DOMAIN || "";
const PROXY_URL = process.env.NEXT_PUBLIC_CLERK_PROXY_URL || "";
const IS_SATELLITE = process.env.NEXT_PUBLIC_CLERK_IS_SATELLITE === "true" || false;
const SIGN_IN_URL = process.env.NEXT_PUBLIC_CLERK_SIGN_IN_URL || "";
const SIGN_UP_URL = process.env.NEXT_PUBLIC_CLERK_SIGN_UP_URL || "";
 //# sourceMappingURL=constants.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/clerkClient.js


const clerkClient = esm_Clerk({
    apiKey: API_KEY,
    secretKey: SECRET_KEY,
    apiUrl: constants_API_URL,
    apiVersion: constants_API_VERSION,
    userAgent: `${"@clerk/nextjs"}@${"4.29.5"}`,
    proxyUrl: PROXY_URL,
    domain: DOMAIN,
    isSatellite: IS_SATELLITE
});
const createClerkClient = (/* unused pure expression or super */ null && (Clerk));


 //# sourceMappingURL=clerkClient.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/chunk-TRWMHODU.mjs
// src/handleValueOrFn.ts
function handleValueOrFn(value, url, defaultValue) {
    if (typeof value === "function") {
        return value(url);
    }
    if (typeof value !== "undefined") {
        return value;
    }
    if (typeof defaultValue !== "undefined") {
        return defaultValue;
    }
    return void 0;
}
 //# sourceMappingURL=chunk-TRWMHODU.mjs.map

;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/handleValueOrFn.mjs


 //# sourceMappingURL=handleValueOrFn.mjs.map

;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/chunk-GVKVD773.mjs

// src/proxy.ts
function isValidProxyUrl(key) {
    if (!key) {
        return true;
    }
    return isHttpOrHttps(key) || isProxyUrlRelative(key);
}
function isHttpOrHttps(key) {
    return /^http(s)?:\/\//.test(key || "");
}
function isProxyUrlRelative(key) {
    return key.startsWith("/");
}
function proxyUrlToAbsoluteURL(url) {
    if (!url) {
        return "";
    }
    return isProxyUrlRelative(url) ? new URL(url, window.location.origin).toString() : url;
}
function getRequestUrl({ request, relativePath }) {
    deprecated("getRequestUrl", "Use `buildRequestUrl` from @clerk/backend instead.");
    const { headers, url: initialUrl } = request;
    const url = new URL(initialUrl);
    const host = headers.get("X-Forwarded-Host") ?? headers.get("host") ?? headers["host"] ?? url.host;
    let protocol = (headers.get("X-Forwarded-Proto") ?? headers["X-Forwarded-Proto"])?.split(",")[0] ?? url.protocol;
    protocol = protocol.replace(/[:/]/, "");
    return new URL(relativePath || url.pathname, `${protocol}://${host}`);
}
 //# sourceMappingURL=chunk-GVKVD773.mjs.map

;// CONCATENATED MODULE: ./node_modules/@clerk/shared/dist/proxy.mjs



 //# sourceMappingURL=proxy.mjs.map

;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/constants.js
const constants_Headers = {
    NextRewrite: "x-middleware-rewrite",
    NextResume: "x-middleware-next",
    NextRedirect: "Location"
};
const constants_constants = {
    Headers: constants_Headers
};
 //# sourceMappingURL=constants.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/errors.js
const missingDomainAndProxy = `
Missing domain and proxyUrl. A satellite application needs to specify a domain or a proxyUrl.

1) With middleware
   e.g. export default withClerkMiddleware(req => {...}, {domain:'YOUR_DOMAIN',isSatellite:true});
2) With environment variables e.g.
   NEXT_PUBLIC_CLERK_DOMAIN='YOUR_DOMAIN'
   NEXT_PUBLIC_CLERK_IS_SATELLITE='true'
   `;
const missingSignInUrlInDev = `
Invalid signInUrl. A satellite application requires a signInUrl for development instances.
Check if signInUrl is missing from your configuration or if it is not an absolute URL

1) With middleware
   e.g. export default withClerkMiddleware(req => {...}, {signInUrl:'SOME_URL',isSatellite:true});
2) With environment variables e.g.
   NEXT_PUBLIC_CLERK_SIGN_IN_URL='SOME_URL'
   NEXT_PUBLIC_CLERK_IS_SATELLITE='true'`;
const receivedRequestForIgnoredRoute = (url, matcher)=>`Clerk: The middleware was skipped for this request URL: ${url}. For performance reasons, it's recommended to your middleware matcher to:
export const config = {
  matcher: ${matcher},
};

Alternatively, you can set your own ignoredRoutes. See https://clerk.com/docs/nextjs/middleware
(This log only appears in development mode)
`;
const getAuthAuthHeaderMissing = ()=>authAuthHeaderMissing("getAuth");
const authAuthHeaderMissing = (helperName = "auth")=>`Clerk: ${helperName}() was called but Clerk can't detect usage of authMiddleware(). Please ensure the following:
- authMiddleware() is used in your Next.js Middleware.
- Your Middleware matcher is configured to match this route or page.
- If you are using the src directory, make sure the Middleware file is inside of it.

For more details, see https://clerk.com/docs/quickstarts/nextjs
`;
const clockSkewDetected = (verifyMessage)=>`Clerk: Clock skew detected. This usually means that your system clock is inaccurate. Clerk will continuously try to issue new tokens, as the existing ones will be treated as "expired" due to clock skew.

To resolve this issue, make sure your system's clock is set to the correct time (e.g. turn off and on automatic time synchronization).

---

${verifyMessage}`;
const infiniteRedirectLoopDetected = ()=>`Clerk: Infinite redirect loop detected. That usually means that we were not able to determine the auth state for this request. A list of common causes and solutions follows.

Reason 1:
Your Clerk instance keys are incorrect, or you recently changed keys (Publishable Key, Secret Key).
How to resolve:
-> Make sure you're using the correct keys from the Clerk Dashboard. If you changed keys recently, make sure to clear your browser application data and cookies.

Reason 2:
A bug that may have already been fixed in the latest version of Clerk NextJS package.
How to resolve:
-> Make sure you are using the latest version of '@clerk/nextjs' and 'next'.
`;
const informAboutProtectedRouteInfo = (path, hasPublicRoutes, hasIgnoredRoutes, isApiRoute, defaultIgnoredRoutes)=>{
    const infoText = isApiRoute ? `INFO: Clerk: The request to ${path} is being protected (401) because there is no signed-in user, and the path is included in \`apiRoutes\`. To prevent this behavior, choose one of:` : `INFO: Clerk: The request to ${path} is being redirected because there is no signed-in user, and the path is not included in \`ignoredRoutes\` or \`publicRoutes\`. To prevent this behavior, choose one of:`;
    const apiRoutesText = isApiRoute ? `To prevent Clerk authentication from protecting (401) the api route, remove the rule matching "${path}" from the \`apiRoutes\` array passed to authMiddleware` : void 0;
    const publicRoutesText = hasPublicRoutes ? `To make the route accessible to both signed in and signed out users, add "${path}" to the \`publicRoutes\` array passed to authMiddleware` : `To make the route accessible to both signed in and signed out users, pass \`publicRoutes: ["${path}"]\` to authMiddleware`;
    const ignoredRoutes = [
        ...defaultIgnoredRoutes,
        path
    ].map((r)=>`"${r}"`).join(", ");
    const ignoredRoutesText = hasIgnoredRoutes ? `To prevent Clerk authentication from running at all, add "${path}" to the \`ignoredRoutes\` array passed to authMiddleware` : `To prevent Clerk authentication from running at all, pass \`ignoredRoutes: [${ignoredRoutes}]\` to authMiddleware`;
    const afterAuthText = "Pass a custom `afterAuth` to authMiddleware, and replace Clerk's default behavior of redirecting unless a route is included in publicRoutes";
    return `${infoText}

${[
        apiRoutesText,
        publicRoutesText,
        ignoredRoutesText,
        afterAuthText
    ].filter(Boolean).map((text, index)=>`${index + 1}. ${text}`).join("\n")}

For additional information about middleware, please visit https://clerk.com/docs/nextjs/middleware
(This log only appears in development mode, or if \`debug: true\` is passed to authMiddleware)`;
};
 //# sourceMappingURL=errors.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/utils.js







function setCustomAttributeOnRequest(req, key, value) {
    Object.assign(req, {
        [key]: value
    });
}
function getCustomAttributeFromRequest(req, key) {
    return key in req ? req[key] : void 0;
}
function getAuthKeyFromRequest(req, key) {
    const val = getCustomAttributeFromRequest(req, constants.Attributes[key]) || utils_getHeader(req, constants.Headers[key]);
    if (val) {
        return val;
    }
    if (key === "AuthStatus" || key === "AuthToken") {
        return getQueryParam(req, key) || void 0;
    }
    return void 0;
}
function getAuthStatusFromRequest(req) {
    return getCustomAttributeFromRequest(req, constants.Attributes.AuthStatus) || utils_getHeader(req, constants.Headers.AuthStatus) || getQueryParam(req, constants.SearchParams.AuthStatus);
}
function getQueryParam(req, name) {
    if (isNextRequest(req)) {
        return req.nextUrl.searchParams.get(name);
    }
    let queryParam;
    if ("query" in req) {
        queryParam = req.query[name];
    }
    if (!queryParam) {
        const qs = (req.url || "").split("?")[1];
        queryParam = new URLSearchParams(qs).get(name);
    }
    return queryParam;
}
function utils_getHeader(req, name) {
    if (isNextRequest(req)) {
        return req.headers.get(name);
    }
    return req.headers[name] || req.headers[name.toLowerCase()] || req.socket?._httpMessage?.getHeader(name);
}
function getCookie(req, name) {
    if (isNextRequest(req)) {
        const reqCookieOrString = req.cookies.get(name);
        if (!reqCookieOrString) {
            return void 0;
        }
        return typeof reqCookieOrString === "string" ? reqCookieOrString : reqCookieOrString.value;
    }
    return req.cookies[name];
}
function isNextRequest(val) {
    try {
        const { headers, nextUrl, cookies } = val || {};
        return typeof headers?.get === "function" && typeof nextUrl?.searchParams.get === "function" && typeof cookies?.get === "function";
    } catch (e) {
        return false;
    }
}
const OVERRIDE_HEADERS = "x-middleware-override-headers";
const MIDDLEWARE_HEADER_PREFIX = "x-middleware-request";
const setRequestHeadersOnNextResponse = (res, req, newHeaders)=>{
    if (!res.headers.get(OVERRIDE_HEADERS)) {
        res.headers.set(OVERRIDE_HEADERS, [
            ...req.headers.keys()
        ]);
        req.headers.forEach((val, key)=>{
            res.headers.set(`${MIDDLEWARE_HEADER_PREFIX}-${key}`, val);
        });
    }
    Object.entries(newHeaders).forEach(([key, val])=>{
        res.headers.set(OVERRIDE_HEADERS, `${res.headers.get(OVERRIDE_HEADERS)},${key}`);
        res.headers.set(`${MIDDLEWARE_HEADER_PREFIX}-${key}`, val);
    });
};
const nextJsVersionCanOverrideRequestHeaders = ()=>{
    try {
        const headerKey = "clerkTest";
        const headerKeyInRes = `${MIDDLEWARE_HEADER_PREFIX}-${headerKey}`;
        const res = response_NextResponse.next({
            request: {
                headers: new Headers({
                    [headerKey]: "true"
                })
            }
        });
        return res.headers.has(headerKeyInRes);
    } catch (e) {
        return false;
    }
};
const injectSSRStateIntoObject = (obj, authObject)=>{
    const __clerk_ssr_state =  false ? 0 : {
        ...authObject
    };
    return {
        ...obj,
        __clerk_ssr_state
    };
};
function utils_isDevelopmentFromApiKey(apiKey) {
    return apiKey.startsWith("test_") || apiKey.startsWith("sk_test_");
}
function decorateRequest(req, res, requestState) {
    const { reason, message, status, token } = requestState;
    if (!res) {
        res = response_NextResponse.next();
    }
    if (res.headers.get(constants_constants.Headers.NextRedirect)) {
        return res;
    }
    let rewriteURL;
    if (res.headers.get(constants_constants.Headers.NextResume) === "1") {
        res.headers.delete(constants_constants.Headers.NextResume);
        rewriteURL = new URL(req.url);
    }
    const rewriteURLHeader = res.headers.get(constants_constants.Headers.NextRewrite);
    if (rewriteURLHeader) {
        const reqURL = new URL(req.url);
        rewriteURL = new URL(rewriteURLHeader);
        if (rewriteURL.origin !== reqURL.origin) {
            return res;
        }
    }
    if (rewriteURL) {
        if (nextJsVersionCanOverrideRequestHeaders()) {
            setRequestHeadersOnNextResponse(res, req, {
                [esm_constants.Headers.AuthStatus]: status,
                [esm_constants.Headers.AuthToken]: token || "",
                [esm_constants.Headers.AuthMessage]: message || "",
                [esm_constants.Headers.AuthReason]: reason || ""
            });
        } else {
            res.headers.set(esm_constants.Headers.AuthStatus, status);
            res.headers.set(esm_constants.Headers.AuthToken, token || "");
            res.headers.set(esm_constants.Headers.AuthMessage, message || "");
            res.headers.set(esm_constants.Headers.AuthReason, reason || "");
            rewriteURL.searchParams.set(esm_constants.SearchParams.AuthStatus, status);
            rewriteURL.searchParams.set(esm_constants.SearchParams.AuthToken, token || "");
            rewriteURL.searchParams.set(esm_constants.Headers.AuthMessage, message || "");
            rewriteURL.searchParams.set(esm_constants.Headers.AuthReason, reason || "");
        }
        res.headers.set(constants_constants.Headers.NextRewrite, rewriteURL.href);
    }
    return res;
}
const apiEndpointUnauthorizedNextResponse = ()=>{
    return NextResponse.json(null, {
        status: 401,
        statusText: "Unauthorized"
    });
};
const isCrossOrigin = (from, to)=>{
    const fromUrl = new URL(from);
    const toUrl = new URL(to);
    return fromUrl.origin !== toUrl.origin;
};
const handleMultiDomainAndProxy = (req, opts)=>{
    const requestURL = buildRequestUrl(req);
    const relativeOrAbsoluteProxyUrl = handleValueOrFn(opts?.proxyUrl, requestURL, PROXY_URL);
    let proxyUrl;
    if (!!relativeOrAbsoluteProxyUrl && !isHttpOrHttps(relativeOrAbsoluteProxyUrl)) {
        proxyUrl = new URL(relativeOrAbsoluteProxyUrl, requestURL).toString();
    } else {
        proxyUrl = relativeOrAbsoluteProxyUrl;
    }
    const isSatellite = handleValueOrFn(opts.isSatellite, new URL(req.url), IS_SATELLITE);
    const domain = handleValueOrFn(opts.domain, new URL(req.url), DOMAIN);
    const signInUrl = opts?.signInUrl || SIGN_IN_URL;
    if (isSatellite && !proxyUrl && !domain) {
        throw new Error(missingDomainAndProxy);
    }
    if (isSatellite && !isHttpOrHttps(signInUrl) && utils_isDevelopmentFromApiKey(SECRET_KEY || API_KEY)) {
        throw new Error(missingSignInUrlInDev);
    }
    return {
        proxyUrl,
        isSatellite,
        domain,
        signInUrl
    };
};
 //# sourceMappingURL=utils.js.map

;// CONCATENATED MODULE: ./node_modules/@clerk/nextjs/dist/esm/server/withClerkMiddleware.js





const decorateResponseWithObservabilityHeaders = (res, requestState)=>{
    requestState.message && res.headers.set(esm_constants.Headers.AuthMessage, encodeURIComponent(requestState.message));
    requestState.reason && res.headers.set(esm_constants.Headers.AuthReason, encodeURIComponent(requestState.reason));
    requestState.status && res.headers.set(esm_constants.Headers.AuthStatus, encodeURIComponent(requestState.status));
};
const withClerkMiddleware = (...args)=>{
    const noop = ()=>void 0;
    const [handler = noop, opts = {}] = args;
    chunk_KJVJ4CFF_deprecated("withClerkMiddleware", "Use `authMiddleware` instead.\nFor more details, consult the middleware documentation: https://clerk.com/docs/nextjs/middleware");
    return async (req, event)=>{
        const { isSatellite, domain, signInUrl, proxyUrl } = handleMultiDomainAndProxy(req, opts);
        const requestState = await clerkClient.authenticateRequest({
            ...opts,
            apiKey: opts.apiKey || API_KEY,
            secretKey: opts.secretKey || SECRET_KEY,
            frontendApi: opts.frontendApi || FRONTEND_API,
            publishableKey: opts.publishableKey || PUBLISHABLE_KEY,
            isSatellite,
            domain,
            signInUrl,
            proxyUrl,
            request: req
        });
        if (requestState.isUnknown) {
            const response = new response_NextResponse(null, {
                status: 401,
                headers: {
                    "Content-Type": "text/html"
                }
            });
            decorateResponseWithObservabilityHeaders(response, requestState);
            return response;
        }
        if (requestState.isInterstitial) {
            const response = response_NextResponse.rewrite(clerkClient.remotePublicInterstitialUrl({
                apiUrl: constants_API_URL,
                frontendApi: opts.frontendApi || FRONTEND_API,
                publishableKey: opts.publishableKey || PUBLISHABLE_KEY,
                clerkJSUrl: CLERK_JS_URL,
                clerkJSVersion: CLERK_JS_VERSION,
                proxyUrl: requestState.proxyUrl,
                isSatellite: requestState.isSatellite,
                domain: requestState.domain,
                debugData: debugRequestState(requestState),
                signInUrl: requestState.signInUrl
            }), {
                status: 401
            });
            decorateResponseWithObservabilityHeaders(response, requestState);
            return response;
        }
        setCustomAttributeOnRequest(req, esm_constants.Attributes.AuthStatus, requestState.status);
        setCustomAttributeOnRequest(req, esm_constants.Attributes.AuthToken, requestState.token || "");
        setCustomAttributeOnRequest(req, esm_constants.Attributes.AuthMessage, requestState.message || "");
        setCustomAttributeOnRequest(req, esm_constants.Attributes.AuthReason, requestState.reason || "");
        const res = await handler(req, event);
        return decorateRequest(req, res, requestState);
    };
};
 //# sourceMappingURL=withClerkMiddleware.js.map

;// CONCATENATED MODULE: ./middleware.ts


/* harmony default export */ const middleware = (withClerkMiddleware((req)=>{
    return response_NextResponse.next({
        request: req
    });
}));

;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-middleware-loader.js?absolutePagePath=private-next-root-dir%2Fmiddleware.ts&page=%2Fmiddleware&rootDir=%2Fhome%2Fvagrant%2Fagent%2Fworkspace%2Fjira_clone_PR-1&matchers=&preferredRegion=&middlewareConfig=e30%3D!

        
        
        

        const mod = { ...middleware_namespaceObject }
        const handler = mod.middleware || mod.default

        if (typeof handler !== 'function') {
          throw new Error('The Middleware "pages/middleware" must export a `middleware` or a `default` function');
        }

        /* harmony default export */ function next_middleware_loaderabsolutePagePath_private_next_root_dir_2Fmiddleware_ts_page_2Fmiddleware_rootDir_2Fhome_2Fvagrant_2Fagent_2Fworkspace_2Fjira_clone_PR_1_matchers_preferredRegion_middlewareConfig_e30_3D_(opts) {
          return adapter({
            ...opts,
            page: "/middleware",
            handler,
          })
        }
    

/***/ }),

/***/ 629:
/***/ ((__unused_webpack_module, exports) => {

"use strict";
var __webpack_unused_export__;
/*!
 * cookie
 * Copyright(c) 2012-2014 Roman Shtylman
 * Copyright(c) 2015 Douglas Christopher Wilson
 * MIT Licensed
 */ 
/**
 * Module exports.
 * @public
 */ exports.Q = parse;
__webpack_unused_export__ = serialize;
/**
 * Module variables.
 * @private
 */ var __toString = Object.prototype.toString;
/**
 * RegExp to match field-content in RFC 7230 sec 3.2
 *
 * field-content = field-vchar [ 1*( SP / HTAB ) field-vchar ]
 * field-vchar   = VCHAR / obs-text
 * obs-text      = %x80-FF
 */ var fieldContentRegExp = /^[\u0009\u0020-\u007e\u0080-\u00ff]+$/;
/**
 * Parse a cookie header.
 *
 * Parse the given cookie header string into an object
 * The object has the various cookies as keys(names) => values
 *
 * @param {string} str
 * @param {object} [options]
 * @return {object}
 * @public
 */ function parse(str, options) {
    if (typeof str !== "string") {
        throw new TypeError("argument str must be a string");
    }
    var obj = {};
    var opt = options || {};
    var dec = opt.decode || decode;
    var index = 0;
    while(index < str.length){
        var eqIdx = str.indexOf("=", index);
        // no more cookie pairs
        if (eqIdx === -1) {
            break;
        }
        var endIdx = str.indexOf(";", index);
        if (endIdx === -1) {
            endIdx = str.length;
        } else if (endIdx < eqIdx) {
            // backtrack on prior semicolon
            index = str.lastIndexOf(";", eqIdx - 1) + 1;
            continue;
        }
        var key = str.slice(index, eqIdx).trim();
        // only assign once
        if (undefined === obj[key]) {
            var val = str.slice(eqIdx + 1, endIdx).trim();
            // quoted values
            if (val.charCodeAt(0) === 0x22) {
                val = val.slice(1, -1);
            }
            obj[key] = tryDecode(val, dec);
        }
        index = endIdx + 1;
    }
    return obj;
}
/**
 * Serialize data into a cookie header.
 *
 * Serialize the a name value pair into a cookie string suitable for
 * http headers. An optional options object specified cookie parameters.
 *
 * serialize('foo', 'bar', { httpOnly: true })
 *   => "foo=bar; httpOnly"
 *
 * @param {string} name
 * @param {string} val
 * @param {object} [options]
 * @return {string}
 * @public
 */ function serialize(name, val, options) {
    var opt = options || {};
    var enc = opt.encode || encode;
    if (typeof enc !== "function") {
        throw new TypeError("option encode is invalid");
    }
    if (!fieldContentRegExp.test(name)) {
        throw new TypeError("argument name is invalid");
    }
    var value = enc(val);
    if (value && !fieldContentRegExp.test(value)) {
        throw new TypeError("argument val is invalid");
    }
    var str = name + "=" + value;
    if (null != opt.maxAge) {
        var maxAge = opt.maxAge - 0;
        if (isNaN(maxAge) || !isFinite(maxAge)) {
            throw new TypeError("option maxAge is invalid");
        }
        str += "; Max-Age=" + Math.floor(maxAge);
    }
    if (opt.domain) {
        if (!fieldContentRegExp.test(opt.domain)) {
            throw new TypeError("option domain is invalid");
        }
        str += "; Domain=" + opt.domain;
    }
    if (opt.path) {
        if (!fieldContentRegExp.test(opt.path)) {
            throw new TypeError("option path is invalid");
        }
        str += "; Path=" + opt.path;
    }
    if (opt.expires) {
        var expires = opt.expires;
        if (!isDate(expires) || isNaN(expires.valueOf())) {
            throw new TypeError("option expires is invalid");
        }
        str += "; Expires=" + expires.toUTCString();
    }
    if (opt.httpOnly) {
        str += "; HttpOnly";
    }
    if (opt.secure) {
        str += "; Secure";
    }
    if (opt.priority) {
        var priority = typeof opt.priority === "string" ? opt.priority.toLowerCase() : opt.priority;
        switch(priority){
            case "low":
                str += "; Priority=Low";
                break;
            case "medium":
                str += "; Priority=Medium";
                break;
            case "high":
                str += "; Priority=High";
                break;
            default:
                throw new TypeError("option priority is invalid");
        }
    }
    if (opt.sameSite) {
        var sameSite = typeof opt.sameSite === "string" ? opt.sameSite.toLowerCase() : opt.sameSite;
        switch(sameSite){
            case true:
                str += "; SameSite=Strict";
                break;
            case "lax":
                str += "; SameSite=Lax";
                break;
            case "strict":
                str += "; SameSite=Strict";
                break;
            case "none":
                str += "; SameSite=None";
                break;
            default:
                throw new TypeError("option sameSite is invalid");
        }
    }
    return str;
}
/**
 * URL-decode string value. Optimized to skip native call when no %.
 *
 * @param {string} str
 * @returns {string}
 */ function decode(str) {
    return str.indexOf("%") !== -1 ? decodeURIComponent(str) : str;
}
/**
 * URL-encode value.
 *
 * @param {string} str
 * @returns {string}
 */ function encode(val) {
    return encodeURIComponent(val);
}
/**
 * Determine if value is a Date.
 *
 * @param {*} val
 * @private
 */ function isDate(val) {
    return __toString.call(val) === "[object Date]" || val instanceof Date;
}
/**
 * Try decoding a string using a decoding function.
 *
 * @param {string} str
 * @param {function} decode
 * @private
 */ function tryDecode(str, decode) {
    try {
        return decode(str);
    } catch (e) {
        return str;
    }
}


/***/ }),

/***/ 792:
/***/ ((module) => {

"use strict";

var isMergeableObject = function isMergeableObject(value) {
    return isNonNullObject(value) && !isSpecial(value);
};
function isNonNullObject(value) {
    return !!value && typeof value === "object";
}
function isSpecial(value) {
    var stringValue = Object.prototype.toString.call(value);
    return stringValue === "[object RegExp]" || stringValue === "[object Date]" || isReactElement(value);
}
// see https://github.com/facebook/react/blob/b5ac963fb791d1298e7f396236383bc955f916c1/src/isomorphic/classic/element/ReactElement.js#L21-L25
var canUseSymbol = typeof Symbol === "function" && Symbol.for;
var REACT_ELEMENT_TYPE = canUseSymbol ? Symbol.for("react.element") : 0xeac7;
function isReactElement(value) {
    return value.$$typeof === REACT_ELEMENT_TYPE;
}
function emptyTarget(val) {
    return Array.isArray(val) ? [] : {};
}
function cloneUnlessOtherwiseSpecified(value, options) {
    return options.clone !== false && options.isMergeableObject(value) ? deepmerge(emptyTarget(value), value, options) : value;
}
function defaultArrayMerge(target, source, options) {
    return target.concat(source).map(function(element) {
        return cloneUnlessOtherwiseSpecified(element, options);
    });
}
function getMergeFunction(key, options) {
    if (!options.customMerge) {
        return deepmerge;
    }
    var customMerge = options.customMerge(key);
    return typeof customMerge === "function" ? customMerge : deepmerge;
}
function getEnumerableOwnPropertySymbols(target) {
    return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(target).filter(function(symbol) {
        return target.propertyIsEnumerable(symbol);
    }) : [];
}
function getKeys(target) {
    return Object.keys(target).concat(getEnumerableOwnPropertySymbols(target));
}
function propertyIsOnObject(object, property) {
    try {
        return property in object;
    } catch (_) {
        return false;
    }
}
// Protects from prototype poisoning and unexpected merging up the prototype chain.
function propertyIsUnsafe(target, key) {
    return propertyIsOnObject(target, key) // Properties are safe to merge if they don't exist in the target yet,
     && !(Object.hasOwnProperty.call(target, key) // unsafe if they exist up the prototype chain,
     && Object.propertyIsEnumerable.call(target, key) // and also unsafe if they're nonenumerable.
    );
}
function mergeObject(target, source, options) {
    var destination = {};
    if (options.isMergeableObject(target)) {
        getKeys(target).forEach(function(key) {
            destination[key] = cloneUnlessOtherwiseSpecified(target[key], options);
        });
    }
    getKeys(source).forEach(function(key) {
        if (propertyIsUnsafe(target, key)) {
            return;
        }
        if (propertyIsOnObject(target, key) && options.isMergeableObject(source[key])) {
            destination[key] = getMergeFunction(key, options)(target[key], source[key], options);
        } else {
            destination[key] = cloneUnlessOtherwiseSpecified(source[key], options);
        }
    });
    return destination;
}
function deepmerge(target, source, options) {
    options = options || {};
    options.arrayMerge = options.arrayMerge || defaultArrayMerge;
    options.isMergeableObject = options.isMergeableObject || isMergeableObject;
    // cloneUnlessOtherwiseSpecified is added to `options` so that custom arrayMerge()
    // implementations can use it. The caller may not replace it.
    options.cloneUnlessOtherwiseSpecified = cloneUnlessOtherwiseSpecified;
    var sourceIsArray = Array.isArray(source);
    var targetIsArray = Array.isArray(target);
    var sourceAndTargetTypesMatch = sourceIsArray === targetIsArray;
    if (!sourceAndTargetTypesMatch) {
        return cloneUnlessOtherwiseSpecified(source, options);
    } else if (sourceIsArray) {
        return options.arrayMerge(target, source, options);
    } else {
        return mergeObject(target, source, options);
    }
}
deepmerge.all = function deepmergeAll(array, options) {
    if (!Array.isArray(array)) {
        throw new Error("first argument should be an array");
    }
    return array.reduce(function(prev, next) {
        return deepmerge(prev, next, options);
    }, {});
};
var deepmerge_1 = deepmerge;
module.exports = deepmerge_1;


/***/ }),

/***/ 742:
/***/ ((module) => {

"use strict";

const isObject = (value)=>typeof value === "object" && value !== null;
const mapObjectSkip = Symbol("skip");
// Customized for this use-case
const isObjectCustom = (value)=>isObject(value) && !(value instanceof RegExp) && !(value instanceof Error) && !(value instanceof Date);
const mapObject = (object, mapper, options, isSeen = new WeakMap())=>{
    options = {
        deep: false,
        target: {},
        ...options
    };
    if (isSeen.has(object)) {
        return isSeen.get(object);
    }
    isSeen.set(object, options.target);
    const { target } = options;
    delete options.target;
    const mapArray = (array)=>array.map((element)=>isObjectCustom(element) ? mapObject(element, mapper, options, isSeen) : element);
    if (Array.isArray(object)) {
        return mapArray(object);
    }
    for (const [key, value] of Object.entries(object)){
        const mapResult = mapper(key, value, object);
        if (mapResult === mapObjectSkip) {
            continue;
        }
        let [newKey, newValue, { shouldRecurse = true } = {}] = mapResult;
        // Drop `__proto__` keys.
        if (newKey === "__proto__") {
            continue;
        }
        if (options.deep && shouldRecurse && isObjectCustom(newValue)) {
            newValue = Array.isArray(newValue) ? mapArray(newValue) : mapObject(newValue, mapper, options, isSeen);
        }
        target[newKey] = newValue;
    }
    return target;
};
module.exports = (object, mapper, options)=>{
    if (!isObject(object)) {
        throw new TypeError(`Expected an object, got \`${object}\` (${typeof object})`);
    }
    return mapObject(object, mapper, options);
};
module.exports.mapObjectSkip = mapObjectSkip;


/***/ }),

/***/ 668:
/***/ ((module) => {

"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
// src/index.ts
var src_exports = {};
__export(src_exports, {
    RequestCookies: ()=>RequestCookies,
    ResponseCookies: ()=>ResponseCookies
});
module.exports = __toCommonJS(src_exports);
// src/serialize.ts
function serialize(c) {
    var _a;
    const attrs = [
        "path" in c && c.path && `Path=${c.path}`,
        "expires" in c && (c.expires || c.expires === 0) && `Expires=${(typeof c.expires === "number" ? new Date(c.expires) : c.expires).toUTCString()}`,
        "maxAge" in c && typeof c.maxAge === "number" && `Max-Age=${c.maxAge}`,
        "domain" in c && c.domain && `Domain=${c.domain}`,
        "secure" in c && c.secure && "Secure",
        "httpOnly" in c && c.httpOnly && "HttpOnly",
        "sameSite" in c && c.sameSite && `SameSite=${c.sameSite}`
    ].filter(Boolean);
    return `${c.name}=${encodeURIComponent((_a = c.value) != null ? _a : "")}; ${attrs.join("; ")}`;
}
function parseCookieString(cookie) {
    const map = /* @__PURE__ */ new Map();
    for (const pair of cookie.split(/; */)){
        if (!pair) continue;
        const splitAt = pair.indexOf("=");
        if (splitAt === -1) {
            map.set(pair, "true");
            continue;
        }
        const [key, value] = [
            pair.slice(0, splitAt),
            pair.slice(splitAt + 1)
        ];
        try {
            map.set(key, decodeURIComponent(value != null ? value : "true"));
        } catch  {}
    }
    return map;
}
function parseSetCookieString(setCookie) {
    if (!setCookie) {
        return void 0;
    }
    const [[name, value], ...attributes] = parseCookieString(setCookie);
    const { domain, expires, httponly, maxage, path, samesite, secure } = Object.fromEntries(attributes.map(([key, value2])=>[
            key.toLowerCase(),
            value2
        ]));
    const cookie = {
        name,
        value: decodeURIComponent(value),
        domain,
        ...expires && {
            expires: new Date(expires)
        },
        ...httponly && {
            httpOnly: true
        },
        ...typeof maxage === "string" && {
            maxAge: Number(maxage)
        },
        path,
        ...samesite && {
            sameSite: parseSameSite(samesite)
        },
        ...secure && {
            secure: true
        }
    };
    return compact(cookie);
}
function compact(t) {
    const newT = {};
    for(const key in t){
        if (t[key]) {
            newT[key] = t[key];
        }
    }
    return newT;
}
var SAME_SITE = [
    "strict",
    "lax",
    "none"
];
function parseSameSite(string) {
    string = string.toLowerCase();
    return SAME_SITE.includes(string) ? string : void 0;
}
// src/request-cookies.ts
var RequestCookies = class {
    constructor(requestHeaders){
        /** @internal */ this._parsed = /* @__PURE__ */ new Map();
        this._headers = requestHeaders;
        const header = requestHeaders.get("cookie");
        if (header) {
            const parsed = parseCookieString(header);
            for (const [name, value] of parsed){
                this._parsed.set(name, {
                    name,
                    value
                });
            }
        }
    }
    [Symbol.iterator]() {
        return this._parsed[Symbol.iterator]();
    }
    /**
   * The amount of cookies received from the client
   */ get size() {
        return this._parsed.size;
    }
    get(...args) {
        const name = typeof args[0] === "string" ? args[0] : args[0].name;
        return this._parsed.get(name);
    }
    getAll(...args) {
        var _a;
        const all = Array.from(this._parsed);
        if (!args.length) {
            return all.map(([_, value])=>value);
        }
        const name = typeof args[0] === "string" ? args[0] : (_a = args[0]) == null ? void 0 : _a.name;
        return all.filter(([n])=>n === name).map(([_, value])=>value);
    }
    has(name) {
        return this._parsed.has(name);
    }
    set(...args) {
        const [name, value] = args.length === 1 ? [
            args[0].name,
            args[0].value
        ] : args;
        const map = this._parsed;
        map.set(name, {
            name,
            value
        });
        this._headers.set("cookie", Array.from(map).map(([_, value2])=>serialize(value2)).join("; "));
        return this;
    }
    /**
   * Delete the cookies matching the passed name or names in the request.
   */ delete(names) {
        const map = this._parsed;
        const result = !Array.isArray(names) ? map.delete(names) : names.map((name)=>map.delete(name));
        this._headers.set("cookie", Array.from(map).map(([_, value])=>serialize(value)).join("; "));
        return result;
    }
    /**
   * Delete all the cookies in the cookies in the request.
   */ clear() {
        this.delete(Array.from(this._parsed.keys()));
        return this;
    }
    /**
   * Format the cookies in the request as a string for logging
   */ [Symbol.for("edge-runtime.inspect.custom")]() {
        return `RequestCookies ${JSON.stringify(Object.fromEntries(this._parsed))}`;
    }
    toString() {
        return [
            ...this._parsed.values()
        ].map((v)=>`${v.name}=${encodeURIComponent(v.value)}`).join("; ");
    }
};
// src/response-cookies.ts
var ResponseCookies = class {
    constructor(responseHeaders){
        /** @internal */ this._parsed = /* @__PURE__ */ new Map();
        var _a, _b, _c;
        this._headers = responseHeaders;
        const setCookie = // @ts-expect-error See https://github.com/whatwg/fetch/issues/973
        (_c = (_b = (_a = responseHeaders.getAll) == null ? void 0 : _a.call(responseHeaders, "set-cookie")) != null ? _b : responseHeaders.get("set-cookie")) != null ? _c : [];
        const cookieStrings = Array.isArray(setCookie) ? setCookie : splitCookiesString(setCookie);
        for (const cookieString of cookieStrings){
            const parsed = parseSetCookieString(cookieString);
            if (parsed) this._parsed.set(parsed.name, parsed);
        }
    }
    /**
   * {@link https://wicg.github.io/cookie-store/#CookieStore-get CookieStore#get} without the Promise.
   */ get(...args) {
        const key = typeof args[0] === "string" ? args[0] : args[0].name;
        return this._parsed.get(key);
    }
    /**
   * {@link https://wicg.github.io/cookie-store/#CookieStore-getAll CookieStore#getAll} without the Promise.
   */ getAll(...args) {
        var _a;
        const all = Array.from(this._parsed.values());
        if (!args.length) {
            return all;
        }
        const key = typeof args[0] === "string" ? args[0] : (_a = args[0]) == null ? void 0 : _a.name;
        return all.filter((c)=>c.name === key);
    }
    /**
   * {@link https://wicg.github.io/cookie-store/#CookieStore-set CookieStore#set} without the Promise.
   */ set(...args) {
        const [name, value, cookie] = args.length === 1 ? [
            args[0].name,
            args[0].value,
            args[0]
        ] : args;
        const map = this._parsed;
        map.set(name, normalizeCookie({
            name,
            value,
            ...cookie
        }));
        replace(map, this._headers);
        return this;
    }
    /**
   * {@link https://wicg.github.io/cookie-store/#CookieStore-delete CookieStore#delete} without the Promise.
   */ delete(...args) {
        const name = typeof args[0] === "string" ? args[0] : args[0].name;
        return this.set({
            name,
            value: "",
            expires: /* @__PURE__ */ new Date(0)
        });
    }
    [Symbol.for("edge-runtime.inspect.custom")]() {
        return `ResponseCookies ${JSON.stringify(Object.fromEntries(this._parsed))}`;
    }
    toString() {
        return [
            ...this._parsed.values()
        ].map(serialize).join("; ");
    }
};
function replace(bag, headers) {
    headers.delete("set-cookie");
    for (const [, value] of bag){
        const serialized = serialize(value);
        headers.append("set-cookie", serialized);
    }
}
function normalizeCookie(cookie = {
    name: "",
    value: ""
}) {
    if (typeof cookie.expires === "number") {
        cookie.expires = new Date(cookie.expires);
    }
    if (cookie.maxAge) {
        cookie.expires = new Date(Date.now() + cookie.maxAge * 1e3);
    }
    if (cookie.path === null || cookie.path === void 0) {
        cookie.path = "/";
    }
    return cookie;
}
function splitCookiesString(cookiesString) {
    if (!cookiesString) return [];
    var cookiesStrings = [];
    var pos = 0;
    var start;
    var ch;
    var lastComma;
    var nextStart;
    var cookiesSeparatorFound;
    function skipWhitespace() {
        while(pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))){
            pos += 1;
        }
        return pos < cookiesString.length;
    }
    function notSpecialChar() {
        ch = cookiesString.charAt(pos);
        return ch !== "=" && ch !== ";" && ch !== ",";
    }
    while(pos < cookiesString.length){
        start = pos;
        cookiesSeparatorFound = false;
        while(skipWhitespace()){
            ch = cookiesString.charAt(pos);
            if (ch === ",") {
                lastComma = pos;
                pos += 1;
                skipWhitespace();
                nextStart = pos;
                while(pos < cookiesString.length && notSpecialChar()){
                    pos += 1;
                }
                if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
                    cookiesSeparatorFound = true;
                    pos = nextStart;
                    cookiesStrings.push(cookiesString.substring(start, lastComma));
                    start = pos;
                } else {
                    pos = lastComma + 1;
                }
            } else {
                pos += 1;
            }
        }
        if (!cookiesSeparatorFound || pos >= cookiesString.length) {
            cookiesStrings.push(cookiesString.substring(start, cookiesString.length));
        }
    }
    return cookiesStrings;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (0);


/***/ }),

/***/ 295:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  snakeCase: () => (/* binding */ snakeCase)
});

;// CONCATENATED MODULE: ./node_modules/tslib/tslib.es6.mjs
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */ /* global Reflect, Promise, SuppressedError, Symbol */ var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || ({
        __proto__: []
    }) instanceof Array && function(d, b) {
        d.__proto__ = b;
    } || function(d, b) {
        for(var p in b)if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return extendStatics(d, b);
};
function __extends(d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
        this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
function __rest(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
}
function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function __param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
function __esDecorate(ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) {
        if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected");
        return f;
    }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for(var i = decorators.length - 1; i >= 0; i--){
        var context = {};
        for(var p in contextIn)context[p] = p === "access" ? {} : contextIn[p];
        for(var p in contextIn.access)context.access[p] = contextIn.access[p];
        context.addInitializer = function(f) {
            if (done) throw new TypeError("Cannot add initializers after decoration has completed");
            extraInitializers.push(accept(f || null));
        };
        var result = (0, decorators[i])(kind === "accessor" ? {
            get: descriptor.get,
            set: descriptor.set
        } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        } else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
}
;
function __runInitializers(thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for(var i = 0; i < initializers.length; i++){
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
}
;
function __propKey(x) {
    return typeof x === "symbol" ? x : "".concat(x);
}
;
function __setFunctionName(f, name, prefix) {
    if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
    return Object.defineProperty(f, "name", {
        configurable: true,
        value: prefix ? "".concat(prefix, " ", name) : name
    });
}
;
function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}
function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}
function __generator(thisArg, body) {
    var _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, f, y, t, g;
    return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
    }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}
var __createBinding = Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
};
function __exportStar(m, o) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p)) __createBinding(o, m, p);
}
function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function() {
            if (o && i >= o.length) o = void 0;
            return {
                value: o && o[i++],
                done: !o
            };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while((n === void 0 || n-- > 0) && !(r = i.next()).done)ar.push(r.value);
    } catch (error) {
        e = {
            error: error
        };
    } finally{
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        } finally{
            if (e) throw e.error;
        }
    }
    return ar;
}
/** @deprecated */ function __spread() {
    for(var ar = [], i = 0; i < arguments.length; i++)ar = ar.concat(__read(arguments[i]));
    return ar;
}
/** @deprecated */ function __spreadArrays() {
    for(var s = 0, i = 0, il = arguments.length; i < il; i++)s += arguments[i].length;
    for(var r = Array(s), k = 0, i = 0; i < il; i++)for(var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)r[k] = a[j];
    return r;
}
function __spreadArray(to, from, pack) {
    if (pack || arguments.length === 2) for(var i = 0, l = from.length, ar; i < l; i++){
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
}
function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}
function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i;
    function verb(n) {
        if (g[n]) i[n] = function(v) {
            return new Promise(function(a, b) {
                q.push([
                    n,
                    v,
                    a,
                    b
                ]) > 1 || resume(n, v);
            });
        };
    }
    function resume(n, v) {
        try {
            step(g[n](v));
        } catch (e) {
            settle(q[0][3], e);
        }
    }
    function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
    }
    function fulfill(value) {
        resume("next", value);
    }
    function reject(value) {
        resume("throw", value);
    }
    function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
    }
}
function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function(e) {
        throw e;
    }), verb("return"), i[Symbol.iterator] = function() {
        return this;
    }, i;
    function verb(n, f) {
        i[n] = o[n] ? function(v) {
            return (p = !p) ? {
                value: __await(o[n](v)),
                done: false
            } : f ? f(v) : v;
        } : f;
    }
}
function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i);
    function verb(n) {
        i[n] = o[n] && function(v) {
            return new Promise(function(resolve, reject) {
                v = o[n](v), settle(resolve, reject, v.done, v.value);
            });
        };
    }
    function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function(v) {
            resolve({
                value: v,
                done: d
            });
        }, reject);
    }
}
function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) {
        Object.defineProperty(cooked, "raw", {
            value: raw
        });
    } else {
        cooked.raw = raw;
    }
    return cooked;
}
;
var __setModuleDefault = Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
};
function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
}
function __importDefault(mod) {
    return mod && mod.__esModule ? mod : {
        default: mod
    };
}
function __classPrivateFieldGet(receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
}
function __classPrivateFieldSet(receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
}
function __classPrivateFieldIn(state, receiver) {
    if (receiver === null || typeof receiver !== "object" && typeof receiver !== "function") throw new TypeError("Cannot use 'in' operator on non-object");
    return typeof state === "function" ? receiver === state : state.has(receiver);
}
function __addDisposableResource(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
}
var _SuppressedError = typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};
function __disposeResources(env) {
    function fail(e) {
        env.error = env.hasError ? new _SuppressedError(e, env.error, "An error was suppressed during disposal.") : e;
        env.hasError = true;
    }
    function next() {
        while(env.stack.length){
            var rec = env.stack.pop();
            try {
                var result = rec.dispose && rec.dispose.call(rec.value);
                if (rec.async) return Promise.resolve(result).then(next, function(e) {
                    fail(e);
                    return next();
                });
            } catch (e) {
                fail(e);
            }
        }
        if (env.hasError) throw env.error;
    }
    return next();
}
/* harmony default export */ const tslib_es6 = ({
    __extends,
    __assign,
    __rest,
    __decorate,
    __param,
    __metadata,
    __awaiter,
    __generator,
    __createBinding,
    __exportStar,
    __values,
    __read,
    __spread,
    __spreadArrays,
    __spreadArray,
    __await,
    __asyncGenerator,
    __asyncDelegator,
    __asyncValues,
    __makeTemplateObject,
    __importStar,
    __importDefault,
    __classPrivateFieldGet,
    __classPrivateFieldSet,
    __classPrivateFieldIn,
    __addDisposableResource,
    __disposeResources
});

;// CONCATENATED MODULE: ./node_modules/lower-case/dist.es2015/index.js
/**
 * Source: ftp://ftp.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
 */ var SUPPORTED_LOCALE = {
    tr: {
        regexp: /\u0130|\u0049|\u0049\u0307/g,
        map: {
            İ: "i",
            I: "ı",
            İ: "i"
        }
    },
    az: {
        regexp: /\u0130/g,
        map: {
            İ: "i",
            I: "ı",
            İ: "i"
        }
    },
    lt: {
        regexp: /\u0049|\u004A|\u012E|\u00CC|\u00CD|\u0128/g,
        map: {
            I: "i̇",
            J: "j̇",
            Į: "į̇",
            Ì: "i̇̀",
            Í: "i̇́",
            Ĩ: "i̇̃"
        }
    }
};
/**
 * Localized lower case.
 */ function localeLowerCase(str, locale) {
    var lang = SUPPORTED_LOCALE[locale.toLowerCase()];
    if (lang) return lowerCase(str.replace(lang.regexp, function(m) {
        return lang.map[m];
    }));
    return lowerCase(str);
}
/**
 * Lower case as a function.
 */ function lowerCase(str) {
    return str.toLowerCase();
} //# sourceMappingURL=index.js.map

;// CONCATENATED MODULE: ./node_modules/no-case/dist.es2015/index.js

// Support camel case ("camelCase" -> "camel Case" and "CAMELCase" -> "CAMEL Case").
var DEFAULT_SPLIT_REGEXP = [
    /([a-z0-9])([A-Z])/g,
    /([A-Z])([A-Z][a-z])/g
];
// Remove all non-word characters.
var DEFAULT_STRIP_REGEXP = /[^A-Z0-9]+/gi;
/**
 * Normalize the string into something other libraries can manipulate easier.
 */ function noCase(input, options) {
    if (options === void 0) {
        options = {};
    }
    var _a = options.splitRegexp, splitRegexp = _a === void 0 ? DEFAULT_SPLIT_REGEXP : _a, _b = options.stripRegexp, stripRegexp = _b === void 0 ? DEFAULT_STRIP_REGEXP : _b, _c = options.transform, transform = _c === void 0 ? lowerCase : _c, _d = options.delimiter, delimiter = _d === void 0 ? " " : _d;
    var result = replace(replace(input, splitRegexp, "$1\x00$2"), stripRegexp, "\x00");
    var start = 0;
    var end = result.length;
    // Trim the delimiter from around the output string.
    while(result.charAt(start) === "\x00")start++;
    while(result.charAt(end - 1) === "\x00")end--;
    // Transform each token independently.
    return result.slice(start, end).split("\x00").map(transform).join(delimiter);
}
/**
 * Replace `re` in the input string with the replacement value.
 */ function replace(input, re, value) {
    if (re instanceof RegExp) return input.replace(re, value);
    return re.reduce(function(input, re) {
        return input.replace(re, value);
    }, input);
} //# sourceMappingURL=index.js.map

;// CONCATENATED MODULE: ./node_modules/dot-case/dist.es2015/index.js


function dotCase(input, options) {
    if (options === void 0) {
        options = {};
    }
    return noCase(input, __assign({
        delimiter: "."
    }, options));
} //# sourceMappingURL=index.js.map

;// CONCATENATED MODULE: ./node_modules/snake-case/dist.es2015/index.js


function snakeCase(input, options) {
    if (options === void 0) {
        options = {};
    }
    return dotCase(input, __assign({
        delimiter: "_"
    }, options));
} //# sourceMappingURL=index.js.map


/***/ }),

/***/ 832:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

const map = __webpack_require__(742);
const { snakeCase } = __webpack_require__(295);
module.exports = function(obj, options) {
    options = Object.assign({
        deep: true,
        exclude: [],
        parsingOptions: {}
    }, options);
    return map(obj, function(key, val) {
        return [
            matches(options.exclude, key) ? key : snakeCase(key, options.parsingOptions),
            val
        ];
    }, options);
};
function matches(patterns, value) {
    return patterns.some(function(pattern) {
        return typeof pattern === "string" ? pattern === value : pattern.test(value);
    });
}


/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ var __webpack_exports__ = (__webpack_exec__(513));
/******/ (_ENTRIES = typeof _ENTRIES === "undefined" ? {} : _ENTRIES).middleware_middleware = __webpack_exports__;
/******/ }
]);
//# sourceMappingURL=middleware.js.map